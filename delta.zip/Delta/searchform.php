<form class="b-search" role="search" method="GET" action="<?php echo esc_url(home_url( '/' )) ?>">
	<div class="input-group">
		<input type="text" name="s" class="form-control" placeholder="<?php _e('Search for a product, category or brand', 'delta'); ?>" value="<?php echo get_search_query() ?>">
		<span class="input-group-btn">
			<button class="btn btn-default" type="submit">
				<span class="b-social-icon-search"></span>
			</button>
		</span>
	</div>
</form>