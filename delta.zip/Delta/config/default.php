<?php
$url = get_template_directory_uri() . '/public/images/';

return array(
    // Header image
    'header_image' => $url . 'header_img.jpg',

    // background
    'background_color' => '',

    // Header text color
    'header_textcolor' => '000000',
);