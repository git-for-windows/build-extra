<?phpinclude( __DIR__ . '/inc/update.php' );
include( __DIR__ . '/inc/customization/init.php' );
include( __DIR__ . '/inc/seo.php' );
include( __DIR__ . '/inc/breadcrumbs.php' );
include( __DIR__ . '/inc/delta/init.php' );
include( __DIR__ . '/inc/blog.php' );
require_once get_template_directory() . '/config/libs/GhostCategory.php';

if ( defined( 'ALI_ERROR' ) && ! ALI_ERROR ) {
	include( __DIR__ . '/inc/aliplugin.php' );
}
add_action('created_category', 'no_category_base_refresh_rules');add_action('edited_category', 'no_category_base_refresh_rules');add_action('delete_category', 'no_category_base_refresh_rules');function no_category_base_refresh_rules() {	global $wp_rewrite;	$wp_rewrite -> flush_rules();}register_deactivation_hook(__FILE__, 'no_category_base_deactivate');function no_category_base_deactivate() {	remove_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');	// We don't want to insert our custom rules again	no_category_base_refresh_rules();}// Remove category baseadd_action('init', 'no_category_base_permastruct');function no_category_base_permastruct() {	global $wp_rewrite, $wp_version;	if (version_compare($wp_version, '3.4', '<')) {		// For pre-3.4 support		$wp_rewrite -> extra_permastructs['category'][0] = '%category%';	} else {		$wp_rewrite -> extra_permastructs['category']['struct'] = '%category%';	}}// Add our custom category rewrite rulesadd_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');function no_category_base_rewrite_rules($category_rewrite) {	//var_dump($category_rewrite); // For Debugging	$category_rewrite = array();	$categories = get_categories(array('hide_empty' => false));	foreach ($categories as $category) {		$category_nicename = $category -> slug;		if ($category -> parent == $category -> cat_ID)// recursive recursion			$category -> parent = 0;		elseif ($category -> parent != 0)			$category_nicename = get_category_parents($category -> parent, false, '/', true) . $category_nicename;		$category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';		$category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';		$category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';	}	// Redirect support from Old Category Base	global $wp_rewrite;	$old_category_base = get_option('category_base') ? get_option('category_base') : 'category';	$old_category_base = trim($old_category_base, '/');	$category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';	//var_dump($category_rewrite); // For Debugging	return $category_rewrite;}// For Debugging//add_filter('rewrite_rules_array', 'no_category_base_rewrite_rules_array');//function no_category_base_rewrite_rules_array($category_rewrite) {//	var_dump($category_rewrite); // For Debugging//}// Add 'category_redirect' query variableadd_filter('query_vars', 'no_category_base_query_vars');function no_category_base_query_vars($public_query_vars) {	$public_query_vars[] = 'category_redirect';	return $public_query_vars;}// Redirect if 'category_redirect' is setadd_filter('request', 'no_category_base_request');function no_category_base_request($query_vars) {	//print_r($query_vars); // For Debugging	if (isset($query_vars['category_redirect'])) {		$catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');		status_header(301);		header("Location: $catlink");		exit();	}	return $query_vars;}
/**
 * Remove adminbar for subscribers
 */
if ( is_user_logged_in() && ! current_user_can( "level_2" ) ) {
	add_filter( 'show_admin_bar', '__return_false' );
}
function blog_creation(){
 $blog  = new GhostCategory();    if($blog->findById(1)) {        $blog->setName(__('Blog', 'delta'))->setSlug('blog')->save();    } else {        $blog->setName(__('Blog', 'delta'))->save();    }}	add_action('init', 'blog_creation');
/**
 * Enable responsive video (bootstrap only)
 *
 * @param $html
 * @param $url
 * @param $attr
 * @param $post_ID
 *
 * @return string
 */
function adstm_oembed_filter( $html, $url, $attr, $post_ID ) {
	return '<div class="embed-responsive embed-responsive-16by9">' . $html . '</div>';
}

add_filter( 'embed_oembed_html', 'adstm_oembed_filter', 10, 4 );


/**
 * Convert post_content \n
 *
 * @param $content
 *
 * @return mixed
 */
if ( ! function_exists( 'nl2br_content' ) ) {
	function nl2br_content( $content ) {
		$content = apply_filters( 'the_content', $content );

		return str_replace( ']]>', ']]>', $content );
	}
}

/**
 * @return bool
 */
function adstm_is_home() {
	return is_front_page() || is_home();
}

add_filter( 'get_the_archive_title', function ( $title ) {
	if ( is_category() || is_tax() ) {
		$title = single_cat_title( '', false );
	} elseif ( is_search() ) {
		$title = sprintf( '%1$s: "%2$s"', __( 'Search' ), get_search_query() );
	} elseif ( is_post_type_archive() ) {
		$title = post_type_archive_title( '', false );
	} elseif ( is_tag() ) {
		$title = single_tag_title( '', false );
	} elseif ( is_author() ) {
		$title = sprintf( '<span class="vcard">%s</span>', get_the_author() );
	}

	return $title;
} );

function adstm_single_term() {

	$title = single_term_title( '', false );

	$other_title = get_query_var( 'other_title', false );

	return ( $other_title ) ? $other_title : $title;
}



//add_filter( 'body_class', 'adstm_body_classes' );


function is_enableSocial(){
	if(cz('s_link_fb') ||
	   cz('s_link_fb')||
	   cz('s_link_in')||
	   cz('s_link_tw')||
	   cz('s_link_tw')||
	   cz('s_link_gl')||
	   cz('s_link_pt')||
	   cz('s_link_yt')){
		return true;
	}
	return false;
}

//Delta
add_filter( 'wp_mail_content_type', 'set_html_content_type' );
function set_html_content_type() {
    return 'text/html';
}
function mail_letter(){
	if( !isset($_POST['contact_us']) || $_POST['contact_us']!='2'  ){
		return false;
	}
	else{
		$site_owner_email = cz( 's_mail' );
		if( !$site_owner_email ) return;

		$errors = array();
		if( isset($_POST['subject']) && strlen($_POST['subject']) > 3 ){
			$author_subject = strip_tags($_POST['subject']);
			$author_subject = htmlspecialchars($author_subject);
		} else {
			array_push($errors, "subject error");
		}
		if( isset($_POST['full_name']) && strlen($_POST['full_name']) > 3 ){
			$author_name = strip_tags($_POST['full_name']);
			$author_name = htmlspecialchars($author_name);
		} else {
			array_push($errors, "name error");
		}

		if( isset($_POST['email_main']) && strlen($_POST['email_main']) > 5 ){
			$author_email = strip_tags($_POST['email_main']);
			$author_email = htmlspecialchars($author_email);
		} else {
			array_push($errors, "email error");
		}

		if( isset($_POST['message']) && strlen($_POST['message']) > 7 ){
			$author_comment = strip_tags($_POST['message']);
			$author_comment = htmlspecialchars($author_comment);
		} else {
			array_push($errors, "message error");
		}
		
		$result = array();
		 if( !count($errors) ) {
		$to = $site_owner_email;
		$subject = __('An email message from your site', 'alpha' );
		$message =
		 __( 'Subject', 'alpha' ) . " - " . $author_subject . "
" .
		 __( 'Author', 'alpha' ) . " - " . $author_name . "
" .
         __( 'Email of author', 'alpha' ) . " - " . $author_email . "
" .
         __( 'Message', 'alpha' ) . " - " . $author_comment . "
" ;
		 $result = array('result' => 'success');
			wp_mail( $to, $subject, $message, $headers = '', $attachments = array() );
		 } else {

        $result = array('result' => 'error');

		}
		 echo '<div class="message_contact">'.json_encode($result['result']).'</div>';

		//wp_die();
	}
}
function the_term_link($id, $taxonomy = 'product_cat')
{
    $term_link = get_term_link( intval($id), $taxonomy );
    if( !is_wp_error( $term_link ) )
        echo $term_link;
}
function the_term_title($id, $taxonomy = 'product_cat')
{
    $term = get_term_by('id', intval($id), $taxonomy);

    if($term)
        echo $term->name;
}
function ssdma_is_var_in_get($name, $var = false, $default = false, $valid = array())
{
    $error = false;

    if(isset($_GET[$name])) {

        if(count($valid)) {
            if($valid[0] == 'number' && ssdma_valid_number($_GET[$name], $valid[1])) {
                $error = true;
            } elseif($valid[0] == 'string' && ssdma_valid_string($_GET[$name], $valid[1])) {
                $error = true;
            }
        } else {
            $error = true;
        }

        if($var === false) {
            if($error) {
                return $_GET[$name];
            } else {
                return $valid[2];
            }
        } elseif($var == $_GET[$name]) {
            if($error) {
                return $_GET[$name];
            } else {
                return $valid[2];
            }
        }
    }

    return $default;
}

function ssdma_valid_number($num, $is = array())
{
    if(!count($is)) { return false; }

    if(isset($is['min'])) { $min = intval($is['min']); }
    if(isset($is['max'])) { $max = intval($is['max']); }

    if(isset($min) && isset($max)) {
        if($min < $num && $max > $num) {
            return true;
        }
    } elseif(isset($min)) {
        if($min < $num) {
            return true;
        }
    } elseif(isset($max)) {
        if($max > $num) {
            return true;
        }
    }

    return false;
}

function ssdma_valid_string($str, $is = array())
{
    if(!count($is)) { return false; }

    if(in_array($str, $is)) {
        return true;
    }

    return false;
}
function ssdma_get_term_ids($flug = false)
{
    $ids = ssdma_is_var_in_get('ids', true);

    if(!empty($ids)) {
        $ids = explode('-', $ids);
    }

    if(is_array($ids) && count($ids) && $flug) {
        $ids = current($ids);
    }

    return $ids;
}
function ssdma_categories_menu($id = 0, $tax = 'product_cat') {
    $terms = get_terms($tax, array('parent' => $id));

    $categories_menu = array();
    if( count($terms) ) {
        foreach( $terms as $term ) {
            $categories_menu[] = array(
                'id'    => $term->term_id,
                'link'  => get_term_link( $term, $tax ),
                'name'  => $term->name,
                'count' => $term->count,
            );
        }
    }

    return $categories_menu;
}
function ssdma_get_to_string(array $var = array())
{
    return (count($_GET) || count($var)) ? '?' . http_build_query(array_merge($_GET, $var)) : '';
}
function ssdma_sort_array($first = false, $key = false)
{
    $arr = array(
        'orders' => array(
            'name' => __('Best sellers', 'delta'),
            'sort' => true,
        ),
        'newest' => array(
            'name' => __('Latest', 'delta'),
            'sort' => true,
        ),
        'price' => array(
            'name' => __('Price', 'delta'),
            'sort' => true,
        ),
    );

    if($key) { $arr = array_keys($arr); }
    if($first) { $arr = current($arr);  }

    return $arr;
}
class wp_bootstrap_navwalker extends Walker_Nav_Menu {

	/**
	 * @see Walker::start_lvl()
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param int $depth Depth of page. Used for padding.
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat( "", $depth );
		$output .= "$indent<ul role=\"menu\" class=\" dropdown-menu\">";
	}

	/**
	 * @see Walker::start_el()
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param object $item Menu item data object.
	 * @param int $depth Depth of menu item. Used for padding.
	 * @param int $current_page Menu item ID.
	 * @param object $args
	 */
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		$indent = ( $depth ) ? str_repeat( "", $depth ) : '';

		/**
		 * Dividers, Headers or Disabled
		 * =============================
		 * Determine whether the item is a Divider, Header, Disabled or regular
		 * menu item. To prevent errors we use the strcasecmp() function to so a
		 * comparison that is not case sensitive. The strcasecmp() function returns
		 * a 0 if the strings are equal.
		 */
		if ( strcasecmp( $item->attr_title, 'divider' ) == 0 && $depth === 1 ) {
			$output .= $indent . '<li role="presentation" class="divider">';
		} else if ( strcasecmp( $item->title, 'divider') == 0 && $depth === 1 ) {
			$output .= $indent . '<li role="presentation" class="divider">';
		} else if ( strcasecmp( $item->attr_title, 'dropdown-header') == 0 && $depth === 1 ) {
			$output .= $indent . '<li role="presentation" class="dropdown-header">' . esc_attr( $item->title );
		} else if ( strcasecmp($item->attr_title, 'disabled' ) == 0 ) {
			$output .= $indent . '<li role="presentation" class="disabled"><a href="#">' . esc_attr( $item->title ) . '</a>';
		} else {

			$class_names = $value = '';

			$classes = empty( $item->classes ) ? array() : (array) $item->classes;
			$classes[] = 'menu-item-' . $item->ID;

			$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );

			if ( $args->has_children )
				$class_names .= ' dropdown';

			if ( in_array( 'current-menu-item', $classes ) )
				$class_names .= ' active';

			$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

			$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
			$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

			$output .= $indent . '<li' . $id . $value . $class_names .'>';

			$atts = array();
			$atts['title']  = ! empty( $item->title )	? $item->title	: '';
			$atts['target'] = ! empty( $item->target )	? $item->target	: '';
			$atts['rel']    = ! empty( $item->xfn )		? $item->xfn	: '';

			// If item has_children add atts to a.
			if ( $args->has_children && $depth === 0 ) {
				$atts['href']   		= '#';
				$atts['data-toggle']	= 'dropdown';
				$atts['class']			= 'dropdown-toggle';
				$atts['aria-haspopup']	= 'true';
			} else {
				$atts['href'] = ! empty( $item->url ) ? $item->url : '';
			}

			$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

			$attributes = '';
			foreach ( $atts as $attr => $value ) {
				if ( ! empty( $value ) ) {
					$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
					$attributes .= ' ' . $attr . '="' . $value . '"';
				}
			}

			$item_output = $args->before;

			/*
			 * Glyphicons
			 * ===========
			 * Since the the menu item is NOT a Divider or Header we check the see
			 * if there is a value in the attr_title property. If the attr_title
			 * property is NOT null we apply it as the class name for the glyphicon.
			 */
			if ( ! empty( $item->attr_title ) ) {
                $attributes .= ' class="' . $item->attr_title . '"';
            }

            $item_output .= '<a'. $attributes .'>';

			$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
			$item_output .= ( $args->has_children && 0 === $depth ) ? ' <span class="caret"></span></a>' : '</a>';
			$item_output .= $args->after;

			$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
		}
	}

	/**
	 * Traverse elements to create list from elements.
	 *
	 * Display one element if the element doesn't have any children otherwise,
	 * display the element and its children. Will only traverse up to the max
	 * depth and no ignore elements under that depth.
	 *
	 * This method shouldn't be called directly, use the walk() method instead.
	 *
	 * @see Walker::start_el()
	 * @since 2.5.0
	 *
	 * @param object $element Data object
	 * @param array $children_elements List of elements to continue traversing.
	 * @param int $max_depth Max depth to traverse.
	 * @param int $depth Depth of current element.
	 * @param array $args
	 * @param string $output Passed by reference. Used to append additional content.
	 * @return null Null on failure with no changes to parameters.
	 */
	public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
        if ( ! $element )
            return;

        $id_field = $this->db_fields['id'];

        // Display this element.
        if ( is_object( $args[0] ) )
           $args[0]->has_children = ! empty( $children_elements[ $element->$id_field ] );

        parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
    }

	/**
	 * Menu Fallback
	 * =============
	 * If this function is assigned to the wp_nav_menu's fallback_cb variable
	 * and a manu has not been assigned to the theme location in the WordPress
	 * menu manager the function with display nothing to a non-logged in user,
	 * and will add a link to the WordPress menu manager if logged in as an admin.
	 *
	 * @param array $args passed from the wp_nav_menu function.
	 *
	 */
	public static function fallback( $args ) {
		if ( current_user_can( 'manage_options' ) ) {

			extract( $args );

			$fb_output = null;

			if ( $container ) {
				$fb_output = '<' . $container;

				if ( $container_id )
					$fb_output .= ' id="' . $container_id . '"';

				if ( $container_class )
					$fb_output .= ' class="' . $container_class . '"';

				$fb_output .= '>';
			}

			$fb_output .= '<ul';

			if ( $menu_id )
				$fb_output .= ' id="' . $menu_id . '"';

			if ( $menu_class )
				$fb_output .= ' class="' . $menu_class . '"';

			$fb_output .= '>';
			$fb_output .= '<li><a href="' . admin_url( 'nav-menus.php' ) . '">Add a menu</a></li>';
			$fb_output .= '</ul>';

			if ( $container )
				$fb_output .= '</' . $container . '>';

			echo $fb_output;
		}
	}
}
class wp_bootstrap_comments_walker extends Walker_Comment 
{
	/**
     * Start the list before the elements are added.
     *
     * @see Walker::start_lvl()
     *
     * @since 1.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param int $depth Depth of comment.
     * @param array $args Uses 'style' argument for type of HTML list.
     */
    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $GLOBALS['comment_depth'] = $depth + 1;
        switch ( $args['style'] ) {
            case 'div':
                    break;
            case 'ol':
                    $output .= '<ol class="media children">' . "\n";
                    break;
            default:
            case 'ul':
                    $output .= '<ul class="media children">' . "\n";
                    break;
        }
    }

    /**
    * Output a single comment.
    *
    * @access protected
    * @since 3.6.0
    *
    * @param object $comment Comment to display.
    * @param int    $depth   Depth of comment.
    * @param array  $args    An array of arguments. @see wp_list_comments()
    */
    protected function comment( $comment, $depth, $args ) {
        if ( 'div' == $args['style'] ) {
                $tag = 'div';
                $add_below = 'comment';
        } else {
                $tag = 'li';
                $add_below = 'div-comment';
        }

        $class = empty( $args['has_children'] ) ? '' : 'parent';
        ?>

        <<?php echo $tag; ?> <?php comment_class( array($class, 'media') ); ?> id="comment-<?php comment_ID(); ?>">
        
            <a class="pull-left" href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
                <?php if ($args['avatar_size'] != 0) echo get_avatar( $comment, $args['avatar_size'] ); ?>
            </a>

            <?php if ( 'div' != $args['style'] ) : ?>
                <div class="media-body">
            <?php endif; ?>

            <h4 class="media-heading">
                <?php printf(__('<cite class="fn">%s</cite>'), get_comment_author_link()) ?>                
                <span class="says">says:</span>
            </h4>

            <span>
                <?php printf( __('%1$s at %2$s', 'delta'), get_comment_date(),  get_comment_time()); ?>
                <?php edit_comment_link(__('(Edit)', 'delta'),'  ','' ); ?>
            </span>

            <?php if ($comment->comment_approved == '0') : ?>
                <em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.', 'delta') ?></em>
            <?php endif; ?>

            <div class="reply">
                <?php comment_reply_link(array_merge( $args, array('add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
            </div>

            <p><?php comment_text() ?></p>

            <?php if ( 'div' != $args['style'] ) : ?>
                </div>
            <?php endif; ?>

        <?php
    }

}
function ssdma_comment_form($args = array(), $post_id = null)
{
    if (null === $post_id) {
        $post_id = get_the_ID();
    } else {
        $id = $post_id;
    }

    $commenter = wp_get_current_commenter();
    $user = wp_get_current_user();
    $user_identity = $user->exists() ? $user->display_name : '';

    $args = wp_parse_args($args);
    if (!isset($args['format'])) {
        $args['format'] = current_theme_supports('html5', 'comment-form') ? 'html5' : 'xhtml';
    }

    $req = get_option('require_name_email');
    $aria_req = ($req ? " aria-required='true'" : '');
    $html5 = 'html5' === $args['format'];
    $fields = array(
        'author' => '<p class="comment-form-author">' . '<label for="author">' . __('Name', 'delta') . ($req ? ' <span class="required">*</span>' : '') . '</label> ' .
            '<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' /></p>',
        'email' => '<p class="comment-form-email"><label for="email">' . __('Email', 'delta') . ($req ? ' <span class="required">*</span>' : '') . '</label> ' .
            '<input id="email" name="email" ' . ($html5 ? 'type="email"' : 'type="text"') . ' value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' /></p>',
        'url' => '<p class="comment-form-url"><label for="url">' . __('Website', 'delta') . '</label> ' .
            '<input id="url" name="url" ' . ($html5 ? 'type="url"' : 'type="text"') . ' value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></p>',
    );

    $required_text = sprintf(' ' . __('Required fields are marked %s', 'delta'), '<span class="required">*</span>');

    /**
     * Filter the default comment form fields.
     *
     * @since 3.0.0
     *
     * @param array $fields The default comment fields.
     */
    $fields = apply_filters('comment_form_default_fields', $fields);
    $defaults = array(
        'fields' => $fields,
        'comment_field' => '<p class="comment-form-comment"><label for="comment">' . __('Comment', 'delta') . '</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>',
        'must_log_in' => '<p class="must-log-in">' . sprintf(__('You must be <a href="%s">logged in</a> to post a comment.', 'delta'), wp_login_url(apply_filters('the_permalink', get_permalink($post_id)))) . '</p>',
        'logged_in_as' => '<p class="logged-in-as">' . sprintf(__('Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'delta'), get_edit_user_link(), $user_identity, wp_logout_url(apply_filters('the_permalink', get_permalink($post_id)))) . '</p>',
        'comment_notes_before' => '<p class="comment-notes">' . __('Your email address will not be published.', 'delta') . ($req ? $required_text : '') . '</p>',
        'comment_notes_after' => '<p class="form-allowed-tags">' . sprintf(__('You may use these <abbr title="HyperText Markup Language">HTML</abbr> tags and attributes: %s', 'delta'), ' <code>' . allowed_tags() . '</code>') . '</p>',
        'id_form' => 'commentform',
        'id_submit' => 'submit',
        'title_reply' => __('Leave a Reply', 'delta'),
        'title_reply_to' => __('Leave a Reply to %s', 'delta'),
        'cancel_reply_link' => __('Cancel reply', 'delta'),
        'label_submit' => __('Post Comment', 'delta'),
        'format' => 'xhtml',
    );

    /**
     * Filter the comment form default arguments.
     *
     * Use 'comment_form_default_fields' to filter the comment fields.
     *
     * @since 3.0.0
     *
     * @param array $defaults The default comment form arguments.
     */
    $args = wp_parse_args($args, apply_filters('comment_form_defaults', $defaults));

    include get_template_directory() . '/templates/comments.php';
}