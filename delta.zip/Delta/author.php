<?php get_header(); ?>
<div class="container">
	<?php get_template_part( 'templates/breadcrumbs' ); ?>
	<h1 class="page-title b-margin-base">
		<?php the_post(); printf( __( 'All posts by %s', 'delta' ), get_the_author() ); ?>
	</h1>
	<?php get_template_part( 'templates/catalog' ); ?>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>