<?php get_header(); ?>

    <?php
      global $reviews;
$reviews = new aliFeedBackTM( $post->ID );

$info = new aliProductTM( array(
	'attributes' => true,
	'alimeta'    => true
) );
$info->setData( $post );

global $product;
$product = $info->singleProduct();


$product_redirect_link = "ali-move";

if( isset($product['service']) && $product['service'] == 'amazon' ) {
    $product_redirect_link = "move";
}

function sp( $name ) {
	global $product;
	if ( isset( $product[ $name ] ) ) {
		printf( '%s', $product[ $name ] );
	}
}
    ?>

    <div class="container b-product b-margin-base">

        <?php get_template_part('templates/breadcrumbs'); ?>

        <div class="col-lg-8">
            <div class="col-lg-24">
                <div class="col-lg-24">
                    <?php mic_theGallery( $product[ 'gallery' ] ) ?>
				</div>
			</div>
        </div>
        <div class="col-lg-11 col-lg-offset-1 wrap-meta single-center-block">
            <h1><?php the_title(); ?></h1>

            <div class="b-product_rate">
				<?php $reviews->renderStarRating( $reviews->averageStar() ); 
                    $quantity = ( $product['quantity'] > 0 ) ?
                        sprintf('<div style="color:green">%s</div>', __('Availability: in stock', 'delta')) :
                        sprintf('<div style="color:red">%s</div>', __('Availability: out of stock', 'delta'));
				echo $info->ratingPercentage() . ' % ';
               
                    _e('of buyers enjoyed this product!', 'delta');
                echo $quantity;
				?>
            </div>

			
            <div class="sku-listing">
                <?php
			if ( ! empty( $product[ 'sku' ] ) ) {
				mic_showSKU( $product[ 'sku' ], $product[ 'skuAttr' ], get_the_title() );
			}
			?>
            </div>

            <div class="b-grid-content">
                <div class="effect2 b-product_price">
                            <div>
                                <span class="b-product_price_title"><?php _e('Price', 'delta'); ?>:&nbsp;</span>
                                <span class="b-product_price_old"><?php echo $product[ 'price' ]; ?></span>
                                <strong class="b-product_min"> </strong>
                            </div>
                            <div>
                                <span class="b-product_price_title"><?php _e('Sale Price', 'delta'); ?>:&nbsp;</span>
                                <span class="b-product_price_now" itemprop="price"><?php echo $product[ 'salePrice' ]; ?></span>
                                <strong class="b-product_max"></strong>
                            </div>

                    <div class="text-center">
                        <form method="POST" class="b-product_order">

                            <?php
                                $Buynow      = '';
                                $Buynow_text = '';
                                $btn_text    = ($Buynow && $Buynow != '') ? $Buynow : __( 'Order Now', 'delta' );
                                $buy_now_txt = ($Buynow_text && $Buynow_text != '') ? $Buynow_text :
                                    __( 'from AliExpress', 'delta' );
                            ?>
                    <input type="hidden" name="<?php echo $product_redirect_link?>" value="<?php echo $post->ID ?>">
                            <input type="submit" id="affiliate-submit" value="<?php echo $btn_text ?>" class="btn btn-orange">

                            <?php if( get_option('ae-alibaba') ) : ?>

                                <div class="alibaba_href">
                                    <?php _e('or', 'delta') ?><br>
                                    <a href="#modal"  role="button" data-toggle="modal" id="modal_call_alibaba">
                                        <?php _e('Learn How to Buy it Even Cheaper!', 'delta'); ?></a>
                                </div>

                            <?php else : ?>
                                <i><?php echo $buy_now_txt ?></i>
                            <?php endif;?>
                        </form>
                    </div>
                </div>
                <div class="b-product_desc">
                    <?php if( cz('tp_guarantee') ) : ?>
					<table>
                        <tr>
                            <th><img src="<?php echo get_template_directory_uri(); ?>/public/images/box-single.jpg"
                                     width="45" height="39" alt="45 days Money back"/></th>
                            <td>
                                <strong><?php _e('45 days Money back', 'delta'); ?></strong>
                                <?php _e('Returns accepted if product not as described, buyer pays return shipping; or keep the product & agree refund with seller.', 'delta'); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><img src="<?php echo get_template_directory_uri(); ?>/public/images/car-single.jpg"
                                     width="45" height="40" alt="On-time Delivery"/></th>
                            <td>
                                <strong><?php _e('On-time Delivery', 'delta'); ?></strong><br/>
                                <?php _e('Guarantees: On-time Delivery 60 days', 'delta'); ?>
                            </td>
                        </tr>
                    </table>
				<?php endif;?>
                </div>
            </div>
        </div>
        <div class="col-lg-4 pull-right">
            <div class="b-social-squared">
                <h3><?php _e('Share', 'delta'); ?>:</h3>
                <?php get_template_part('templates/social-more'); ?>
            </div>
            <hr class="hidden-xs"/>
            <h3 class="text-center base-he2 hidden-xs"><?php _e('Most Popular from Category', 'delta'); ?></h3>
			<div class="hidden-md hidden-sm hidden-xs">
				<div class="b-products b-products__min text-right"><?php get_template_part('templates/products-count-2'); ?></div>
			</div>
		</div>
        <div class="col-lg-20 pull-left single-tabs-block">
            <div role="tabpanel" class="b-product_description_tabs">
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#product" aria-controls="product" role="tab" data-toggle="tab">
                            <?php _e('Product Description', 'delta'); ?>
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#reviews" aria-controls="reviews" role="tab" data-toggle="tab">
                            <?php _e('Reviews', 'delta'); ?> <?php comments_number('', '(1)', '(%)'); ?>
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#payment" aria-controls="payment" role="tab" data-toggle="tab">
                            <?php _e('Shipping and payment', 'delta'); ?>
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#sellers" aria-controls="sellers" role="tab" data-toggle="tab">
                            <?php _e("Seller Guarantees", "delta"); ?>
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="product">
                        <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="reviews">
					    <div class="row">
                            <div class="col-lg-24">
                                <?php
									$reviews = new aliFeedBackTM( $post->ID );

									$posts_per_page = ( isset( $wp_query->query_vars[ 'comments_per_page' ] ) &&
										intval( $wp_query->query_vars[ 'comments_per_page' ] ) ) ?
										$wp_query->query_vars[ 'comments_per_page' ] :
										intval( get_option( 'comments_per_page' ) );
								?>
								<?php if ( comments_open() ): ?>
								<div class="col-lg-24 customer-single-block">
													<?php
													$args = array(
														'walker'            => null,
														'max_depth'         => '',
														'style'             => 'tr',
														'callback'          => 'list_review',
														'end-callback'      => null,
														'type'              => 'all',
														'reply_text'        => 'Reply',
								//						'page'              => '',
														'per_page'          => $posts_per_page,
														'avatar_size'       => 32,
														'reverse_top_level' => null,
														'reverse_children'  => '',
														'format'            => 'html5',
								//						'echo'              => true,
														'status'            => 'approve'
													);
								
													wp_list_comments( $args, $reviews->comments );
													?>
										<div class="wrap-pagination">
											<div class="pagination">
												<?php
												paginate_comments_links( array(
													'prev_text' => '&laquo;',
													'next_text' => '&raquo;'
												) );
												?>
											</div>
										</div>
								</div>
							<?php endif; ?>
                            </div>
                        </div>
				    </div>
					<div role="tabpanel" class="tab-pane" id="payment">
						<table class="table table-responsive table-bordered">
							<thead>
							<tr>
								<th><?php _e('Shipping Company', 'delta'); ?></th>
								<th><?php _e('Shipping Cost', 'delta'); ?></th>
								<th><?php _e('Estimated Delivery Time', 'delta'); ?></th>
							</tr>
							</thead>
							<tbody>
							<tr>
								<th><img src="<?php echo get_template_directory_uri(); ?>/public/images/icon-dhl.jpg"
										 width="90" height="30" alt="DHL"/></th>
								<td></td>
								<td>3&nbsp;-&nbsp;7&nbsp;<?php _e('days', 'delta'); ?></td>
							</tr>
							<tr>
								<th><img src="<?php echo get_template_directory_uri(); ?>/public/images/icon-ups-e.gif"
										 width="82" height="34" alt="UPS Expedited"/></th>
								<td></td>
								<td>3&nbsp;-&nbsp;7&nbsp;<?php _e('days', 'delta'); ?></td>
							</tr>
							<tr>
								<th><img src="<?php echo get_template_directory_uri(); ?>/public/images/icon-ems.jpg"
										 width="70" height="30" alt="EMS"/></th>
								<td></td>
								<td>5&nbsp;-&nbsp;14&nbsp;<?php _e('days', 'delta'); ?></td>
							</tr>
							<tr>
								<th><?php _e('Post Air Mail', 'delta'); ?></th>
								<td><?php _e('Free Shipping', 'delta'); ?></td>
								<td>15&nbsp;-&nbsp;45&nbsp;<?php _e('days', 'delta'); ?></td>
							</tr>
							</tbody>
						</table>
					</div>
                    <div role="tabpanel" class="tab-pane" id="sellers">
                        <table class="table table-responsive table-bordered">
                            <tbody>
                            <tr>
                                <th><?php _e('Return Policy', 'delta'); ?></th>
                                <td><?php _e('If the product you receive is not as described or low quality, the seller promises that you may return it before order completion (when you click "Confirm Order Received" or exceed confirmation timeframe) and receive a full refund. The return shipping fee will be paid by you. Or, you can choose to keep the product and agree the refund amount directly with the seller.', 'delta'); ?>
                                    <br/><br/><?php _e('N.B.: If the seller provides the "Longer Protection" service on this product, you may ask for refund up to 15 days after order completion.', 'delta'); ?>
                                </td>
                            </tr>
                            <tr>
                                <th><?php _e('Seller Service', 'delta'); ?></th>
                                <td>
                                    <strong><?php _e('On-time Delivery', 'delta'); ?></strong><?php _e('If you do not receive your purchase within 60 days, you can ask for a full refund before order completion (when you click "Confirm Order Received" or exceed confirmation timeframe). ', 'delta'); ?>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>

        <hr class="visible-xs-block">
        <h3 class="text-center base-he2 mobilepopular"><?php _e('Most Popular from Category', 'delta'); ?></h3>
        <hr class="visible-xs-block">

        <div class="b-products b-products__min"><?php get_template_part('templates/products-count-6'); ?></div>
    </div>

    <?php // get_template_part('templates/text-line'); ?>
<?php if (!empty(cz('tp_price_block'))){?>
<div class="buy-window">
<form method="POST" class="b-product_order">
	<div class="bw-price">
	<span><?php _e('Price', 'delta'); ?>:&nbsp;</span>
	<span><?php echo $product[ 'price' ]; ?></span>
	</div>
	<div class="bw-saleprice">
	<?php _e('Sale Price', 'delta'); ?>:&nbsp;
	<span><?php echo $product[ 'salePrice' ]; ?></span>
	</div>
    <input type="hidden" name="<?php echo $product_redirect_link?>" value="<?php echo $post->ID ?>">
     <input type="submit" name="ae_submit" value="<?php echo $btn_text ?>" class="btn btn-orange">
                            <?php if( get_option('ae-alibaba') ) : ?>
                                <div class="alibaba_href">
                                    <?php _e('or', 'delta') ?><br>
                                    <a href="#modal"  role="button" data-toggle="modal" id="modal_call_alibaba">
                                        <?php _e('Learn How to Buy it Even Cheaper!', 'delta'); ?></a>
                                </div>
                            <?php else : ?>
                                <i><?php echo $buy_now_txt ?></i>
                            <?php endif;?>
	</form>
</div>
<?php } ?>
    <div id="modal_form">
        <span id="modal_close">X</span>
        <div class="modal_title text-center">
            <?php _e('Do you know that you can <span>save up to 90%</span> on your<br> online shopping, buying directly from manufacturers?', 'delta') ?>
        </div>
        <div class="modal_subtitle"><?php _e('And it is very easy:', 'delta') ?></div>
        <ul class="modal_ul">
            <li><?php _e('Go to', 'delta') ?> <a href="<?php echo get_option( 'ae-alibaba_href' )?>" target="_blank">Alibaba.com</a>
                <?php _e('and enter the wanted item into search field.', 'delta') ?></li>
            <li><?php _e('Having made your choice, click "Contact supplier" button on the right', 'delta') ?></li>
            <li><?php _e('On the next page enter your request and click "Send" button.', 'delta') ?></li>
            <li><?php _e('Upon clicking you will be asked to get registered. Do it and wait for the reply.', 'delta') ?></li>
        </ul>
        <div class="text-center modal_ready"><?php _e('ARE YOU READY TO SAVE UP TO 90%?', 'delta') ?></div>
        <a class="btn btn-orange text-center" href="<?php echo get_option( 'ae-alibaba_href' )?>" target="_blank">
            <?php _e('GO TO ALIBABA', 'delta') ?>
        </a>
    </div>

    <div id="overlay"></div>
    <script>
                (function startTimer() {
            var my_timer = document.getElementById("my_timer");

            if( my_timer !== null && my_timer.length !== 0 ){
                var time = my_timer.innerHTML;
                var arr = time.split(":");
                var h = arr[0];
                var m = arr[1];
                var s = arr[2];
                if (s == 0) {
                    if (m == 0) {
                        if (h == 0) {
                            window.location.reload();
                            return;
                        }
                        h--;
                        m = 60;
                        if (h < 10) h = "0" + h;
                    }
                    m--;
                    if (m < 10) m = "0" + m;
                    s = 59;
                }
                else s--;
                if (s < 10) s = "0" + s;
                document.getElementById("my_timer").innerHTML = h+":"+m+":"+s;
                setTimeout(startTimer, 1000);
            }
        }());
    </script>
<?php get_footer(); ?>