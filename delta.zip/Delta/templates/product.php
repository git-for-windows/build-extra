<?php
global $post;
$info = new aliProductTM( array(
	'attributes' => true,
	'alimeta'    => true
) );
$info->setData( $post );
$title = get_the_title();


$table_name = $wpdb->prefix . "exp_review";
	$get_exp_data = $wpdb->get_row("select * from ". $table_name . " where post_id = " .$post->ID);	
	if( isset($get_exp_data) ) {
	$rating = unserialize($get_exp_data->rating);
	$overall_rating = $get_exp_data->overall_rating;
	}
$product = $info->singleProductMin();
global $reviews;
$reviews = new aliFeedBackTM( $post->ID );
?>
<a href="<?php the_permalink() ?>" class="b-products__item" itemscope itemtype="http://schema.org/Offer" data-toggle="ctooltip">
    <div class="b-products__warp">
        <div class="b-products__image">
            <img itemprop="image" src="<?php echo $product[ 'thumb' ]; ?>" width="220" height="220" alt="<?php the_title(); ?>"/>
        </div>
        <h3 itemprop="name" class="b-products__title text-overflow" data-toggle="tooltip" data-placement="top" title="<?php the_title(); ?>">
            <?php the_title(); ?>
        </h3>
        <div class="b-products__price">
                <span itemprop="price"><?php echo $product[ 'salePrice' ]; ?></span>
                <br/>
                <strong class="b-products__price_old">
                    <?php echo $product[ '_price' ]; ?> 
                </strong>

        </div>
        <div class="b-product_rate fs10">
            <?php
                //$ratings = $post->evaluateScore;;
                //$int = intval($ratings);
                //if ($ratings == 0.0 || $int == 0) {
                    $ratings = mt_rand(3, 5);
               // }
            ?>

            <?php 
               $reviews->renderStarRating( $reviews->averageStar());
            ?>
        </div>
    </div>
</a>