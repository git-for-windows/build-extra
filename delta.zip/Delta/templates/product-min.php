<?php
global $post;
$info = new aliProductTM( array(
	'attributes' => true,
	'alimeta'    => true
) );
$info->setData( $post );
$title = get_the_title();

$product = $info->singleProductMin();
?>
<a href="<?php the_permalink() ?>" class="item" itemscope itemtype="http://schema.org/Offer" data-toggle="ctooltip">
    <div class="canvas">
        <img itemprop="image" src="<?php echo $product[ 'thumb' ]; ?>" width="50" height="50" alt="<?php the_title(); ?>" />
    </div>
    <div class="inside">
        <h3 itemprop="name" class="text-overflow" data-toggle="tooltip" data-placement="top" title="<?php the_title(); ?>">
            <?php the_title(); ?>
        </h3>
        <span class="price" itemprop="price"><?php echo $product[ 'salePrice' ]; ?></span>
        <span class="price old"><?php echo $product[ '_price' ]; ?></span>
    </div>
</a>