<?php while ( have_posts() ) : the_post(); ?>
	<?php the_content(); ?>
<?php endwhile; ?>
<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } ?>