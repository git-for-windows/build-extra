<?php
 $cat_id =  cz('tp_products_cat2');
 global $GLOBAL, $post;
if ( ! isset( $GLOBAL[ 'id_post_show' ] ) ) {
	$GLOBAL[ 'id_post_show' ] = array();
}

$args = array(
	'post_type'      => 'product',
	'posts_per_page' => 4,
	'_orderby'       => 'promotionVolume',
	'_order'         => 'DESC',
	'post__not_in'   => $GLOBAL[ 'id_post_show' ],
	'tax_query' => array(
	 array(
	'taxonomy' => 'product_cat',
    'field'    => 'id',
    'terms'    => $cat_id
	))
);
query_posts( $args );
?>
 <h2 class="text-header th-products-mini">
	<a href="<?php the_term_link($cat_id); ?>"><?php the_term_title($cat_id); ?></a>
</h2>
<div class="products-mini clearfix">
	<?php while ( have_posts() ) : the_post(); ?><?php get_template_part( 'templates/product-min' ); ?><?php endwhile; ?>
</div>
<?php wp_reset_query(); ?>