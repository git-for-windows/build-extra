<style>
    <?php if(!cz('blog_banner_mobile_show_1')):?>
    @media (max-width: 768px) {
        .banner_top{
            display: none;
        }
    }
    <?php endif;?>
    <?php if(!cz('blog_banner_mobile_show_2')):?>
    @media (max-width: 768px) {
        .banner_bottom{
            display: none;
        }
    }
    <?php endif;?>
</style>

<div class="container blog-page">
        <div class="shadow"></div>

		<div class="row">
			<div class="col-sm-24 col-xs-24 col-md-16 col-lg-17">

                <?php // get_template_part( 'tpl/blog/tpl/_select_category' ); ?>
<?php
function category_blog_list_show() {

	/*	$select = wp_dropdown_categories( array(
			'show_option_all' => __( 'All Categories', 'rem' ),
			'taxonomy' => 'product_cat',
			'show_count'      => 0,
			'hide_empty'      => 1,
			'echo'            => 0,
			'name'            => 'product_cat',
			'value_field'     => 'slug'
		) );
		$select = preg_replace( "#<select([^>]*)>#", "<select$1 onchange='return this.form.submit()'>", $select );
		$select = preg_replace( '#value=["\']0["\']#', 'value="product"', $select );
		echo $select;*/

    $post_slug = get_queried_object()->slug;
	//$post_slug = get_query_var('product_cat', 'product');
	$categories = get_categories(array(
		'taxonomy' => 'category',
		'orderby' => 'name',
		'order'   => 'ASC',
        'child_of' => 0,
    ));

	$select = '<div class="row"><select class="col-xs-24" name="category" id="blog_cat" class="postform" tabindex="-98">';
	$select.= "<option value='".home_url('blog')."'>".__('All Categories', 'rem')."</option>";

	foreach($categories as $category){
		if($category->count > 0){
			$selected = $category->slug == $post_slug ? 'selected="selected"':'';
			$select.= "<option value='".get_term_link( $category->term_id , "category" )."' ".$selected.">".$category->name ." (". $category->count.")</option>";
		}
	}

	$select.= "</select></div>";

	echo $select;
}

?>
				<?php
				if ( is_single() ) {
					//get_template_part( 'tpl/blog/tpl/_single' );
					?>
					<div class="visible-xs visible-sm">
    <div class="block_line">
        <span class="block_line_title">Blog</span>
        <span class="line"></span>
    </div>
</div>

<div class="visible-xs visible-sm">
    <div class="list">
        <div class="cat_list">
            <form action="<?php bloginfo( 'url' ); ?>/" method="get">
                <div>
                    <?php category_blog_list_show(); ?>
                    <script type="text/javascript">
                        var dropdown = document.getElementById("blog_cat");
                        function onCatChangeBlog() {
                            if ( dropdown.options[dropdown.selectedIndex].value != -1 ) {
                                location.href = dropdown.options[dropdown.selectedIndex].value;
                            }
                        }
                        dropdown.onchange = onCatChangeBlog;
                    </script>
                </div>
            </form>
        </div>
    </div>
</div>

<?php

while ( have_posts() ) : the_post(); ?>

	<div class="blog-item single">
        <div class="visible-xs visible-sm">
            <div class="banner_top">
	            <?php echo cz('blog_banner_1'); ?>
            </div>
        </div>

		<?php the_title( '<h2 class="blog-title"><a href="' . get_the_permalink() . '">', '</a></h2>' ); ?>
		<div class="blog-meta pull-left">
			<time class="meta-time" datetime="<?php echo get_the_date() ?>" itemprop="datePublished"><?php echo get_the_date() ?></time>
			<?php
			$categories = get_the_category( $post->ID );
            echo '<strong>Category: </strong>';
			foreach ( $categories as $category ) {
				printf( '<span><a href=">%1$s">%2$s</a></span>',
					get_category_link($category->cat_ID),
					$category->name
				);
			}
			?>
		</div>

        <div class="pull-right">
            <div class="pull-left">
                <span class="view"><i class="fa fa-eye"></i> <?php echo getPostViews($post->ID) ?></span>
                <span class="comment">
                    <i class="fa fa-comment"></i>
                    <?php echo get_comments_number(); ?>
                </span>
            </div>

		    <div class="blog-share ya-share2 pull-right hidden-xs" data-services="facebook,gplus,pinterest,twitter" data-size="m" data-counter=""></div>
        </div>

		<?php if ( has_post_thumbnail() ) { ?>
			<div class="blog_img">
				<a href="<?php the_permalink(); ?>">
					<?php the_post_thumbnail(); ?>
				</a>
			</div>
		<?php } ?>

		<div class="content">
			<?php the_content(); ?>
		</div>

        <div class="sidebar-blog">
	        <?php echo cz('blog_register_html'); ?>
        </div>

        <div class="share">
            <div class="blog-share ya-share2 text-center" data-services="facebook,gplus,pinterest,twitter" data-size="m" data-counter=""></div>
        </div>



	<!--<div class="blog-pagination-single">-->
		<?php
		/*if( get_adjacent_post(false, '', true) ) {
			previous_post_link('%link', __('< Previous post', 'rem'), true);
		}else{
			printf('<span>%1$s</span>', __('< Previous post', 'rem'));
		}
		if( get_adjacent_post(false, '', false) ) {
			next_post_link('%link', __('Next post >', 'rem') , true);
		}else{
			printf('<span>%1$s</span>', __('Next post >', 'rem'));
		}*/



        $prev = get_previous_post();
        $next = get_next_post();

        if (empty($prev)) {
            $prev = wp_get_recent_posts(['numberposts' => 1], OBJECT);
            $prev = $prev[0];
        }

        if (empty($next)) {
            $next = wp_get_recent_posts(['numberposts' => 1, 'order' => 'ASC'], OBJECT);
            $next = $next[0];
        }

        ?>

        <div class="post-nav">
            <div class="post-nav-box">
                <div class="row">
                    <div class="col-xs-12">
                        <?php printf('<a href="%s">%s</a>', $prev->guid, __('< Previous post') ) ?>
                    </div>
                    <div class="col-xs-12 text-right">
                        <?php printf('<a href="%s">%s</a>', $next->guid, __('Next post >') ) ?>
                    </div>
                </div><!-- .row -->
            </div><!-- .post-nav-box -->

            <div class="row ">
                <div class="col-xs-12">
                    <div class="item clearfix">
                        <!--<div class="hidden-xs hidden-sm">-->
                            <?php printf('<a href="%s">%s</a>', $prev->guid, theme_thumb_photo($prev->ID, 'thumbnail')) ?>
                        <!--</div>-->
                        <div class="title">
                            <?php printf('<a href="%s">%s</a>', $prev->guid, $prev->post_title) ?>
                        </div>
                        <div class="date">
                            <?php echo get_the_date() ?>
                        </div>
                    </div><!-- .item -->
                </div>
                <div class="col-xs-12">
                    <div class="item clearfix">
                        <!--<div class="hidden-xs hidden-sm">-->
                            <?php printf('<a href="%s">%s</a>', $next->guid, theme_thumb_photo($next->ID, 'thumbnail')) ?>
                        <!--</div>-->
                        <div class="title">
                            <?php printf('<a href="%s">%s</a>', $next->guid, $next->post_title) ?>
                        </div>
                        <div class="date">
                            <?php echo get_the_date() ?>
                        </div>
                    </div><!-- .item -->
                </div>
            </div><!-- .row -->

        </div><!-- .post-nav -->

        <div class="visible-xs visible-sm" style="display:none;">
            <div class="banner_bottom">
	            <?php echo cz('blog_banner_2'); ?>
            </div>
        </div>

        <?php

        if ((comments_open() || get_comments_number())) {
            comments_template();
        }
        ?>
        <!--</div>-->
        <?php if(cz('tm_show_blog_comment')): ?>
            <!--<div class="row">
                <div class="col-xs-24">

                    <div class="blog-comments">
                        <div class="fb-comments" data-href="" data-numposts="5" data-colorscheme="light" data-width="100%"></div>
                    </div>

                </div>
            </div>--><!-- .row -->
        <?php endif; ?>
    </div>




<?php endwhile; ?>
<?php
				} else {  ?>

                    <?php
					//get_template_part( 'tpl/blog/tpl/_loop' );
					?>
					<div class="block_line">
    <span class="block_line_title">Blog</span>
    <span class="line2"></span>
</div>

<div class="visible-xs visible-sm">
    <div class="list">
        <div class="cat_list">
            <form action="<?php bloginfo( 'url' ); ?>/" method="get">
                <div>
                    <?php category_blog_list_show(); ?>
                    <script type="text/javascript">
                        var dropdown = document.getElementById("blog_cat");
                        function onCatChangeBlog() {
                            if ( dropdown.options[dropdown.selectedIndex].value != -1 ) {
                                location.href = dropdown.options[dropdown.selectedIndex].value;
                            }
                        }
                        dropdown.onchange = onCatChangeBlog;
                    </script>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="blog-list">
    <div class="visible-xs visible-sm">
        <div class="banner_top">
	        <?php echo cz('blog_banner_1'); ?>
			баннер
        </div>
    </div>

    <div class="visible-xs visible-sm">
        <?php
        $show_load_more = true;
        $cat_id = 0;
        if(is_category()) {
            ?>
            <div class="category-blog-header">
                <?php
                $category = get_the_category();
                $show_load_more = false;
                foreach ($category as $cat) {
                    echo '<strong>' . $cat->name . '</strong> <span>(' . $cat->count . ')</span>';
                    if($cat->count >= 20){
                        $show_load_more = true;
                        $cat_id = $cat->term_id;
                    }
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>

    <?php while ( have_posts() ) : the_post(); ?>
		<?php // get_template_part( 'tpl/blog/tpl/_item' ); ?>
<div class="blog-item">
    <div class="row">

        <div class="col-xs-8 col-sm-7 visible-xs visible-sm visible-md visible-lg">
            <?php printf('<a href="%s">%s</a>', get_the_permalink(), theme_thumb_photo($post->ID, 'thumbnail')) ?>
        </div>

        <div class="col-sm-15 col-sm-offset-1">
            <?php the_title( '<h2 class="blog-title"><a href="' . get_the_permalink() . '">', '</a></h2>' ); ?>
            <div class="blog-meta">
                <time class="meta-time" datetime="<?php echo get_the_date() ?>" itemprop="datePublished"><?php echo get_the_date() ?></time>

                <?php
                $categories = get_the_category( $post->ID );
                echo '<strong>Category: </strong>';
                echo get_the_category_list( ', ', 1 );
                ?>

                <div class="pull-right hidden-xs">
                    <span class="view"><i class="fa fa-eye"></i> <?php echo getPostViews($post->ID) ?></span>

                    <span class="comment">
                        <i class="fa fa-comment"></i>
                        <?php echo get_comments_number(); ?>
                    </span>
                </div>

            </div>


            <div class="content">
                <div class="hidden-sm hidden-xs">
                    <?php the_excerpt(); ?>
                </div>
                <div class="footer-content">
                    <?php printf( '<a class="btn more-link" href="%1$s" target="_blank">%2$s</a>',
                        get_the_permalink(),
                        __( 'Read More', 'rem' )
                    ); ?>
                </div>
            </div>

        </div>
	</div>
</div>
	<?php endwhile; ?>
</div>

<div class="hidden-sm hidden-xs">
    <div class="pagination-blog">
        <?php custom_pagination(); ?>
    </div>
</div>

<div class="visible-xs visible-sm">
    <?php
    if($show_load_more) {
        ?>
        <div class="text-center">
            <a class="btn load-more-link" id="show_more_posts" href="#" data-offset="15" data-cat="<?php echo $cat_id;?>">Load More</a>
        </div>
        <?php
    }
    ?>
</div>

<div class="visible-xs visible-sm">
    <div class="banner_bottom">
	    <?php echo cz('blog_banner_2'); ?>
		баннер 2
    </div>
</div><?php
				}
				?>
			</div>

            <div class="visible-md visible-lg col-md-offset-1 col-md-5 col-lg-6">
                <?php // get_template_part( 'tpl/blog/tpl/_bar' ); ?>
				<div class="bar">
	<div class="list-cat">
        <div class="banner_top" style="display:none">
            <?php echo cz('blog_banner_1'); ?>
			баннер 1
        </div>

        <div class="search" style="margin-top: 20px;">
            <form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
                <input type="hidden" name="target" value="post" />
                <input type="hidden" name="post_type" value="post" />
                <div class="input-group">
                    <input type="text" name="s" class="form-control" value="<?php echo get_search_query() ?>" placeholder="Search..." />
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                    </span>
                </div><!-- /input-group -->
            </form>
        </div>

        <div class="categories">
            <h2>Categories</h2>
            <ul>
                <?php
                wp_list_categories(
                    array(
                        'child_of'            => 0,
                        'current_category'    => 0,
                        'depth'               => 0,
                        'echo'                => 1,
                        'exclude'             => '1',
                        'exclude_tree'        => '',
                        'feed'                => '',
                        'feed_image'          => '',
                        'feed_type'           => '',
                        'hide_empty'          => 1,
                        'hide_title_if_empty' => false,
                        'hierarchical'        => true,
                        'order'               => 'ASC',
                        'orderby'             => 'name',
                        'separator'           => '<br />',
                        'show_count'          => 1,
                        'show_option_all'     => '',
                        'show_option_none'    => __( 'No categories', 'rem' ),
                        'style'               => 'list',
                        'taxonomy'            => 'category',
                        'title_li'            => '',
                        'use_desc_for_title'  => 1,
                    )
                );
                ?>
            </ul>
        </div>
	</div>
<!--    <?php // if ( cz( 'blog_subscribe' ) ): ?>
        <div class="subscription">
            <div class="f-head"><?php  // _e( 'STAY UP TO DATE', 'rem' ) ?></div>
            <?php // echo cz( 'blog_subscribe' ); ?>
        </div>
    <?php // endif; ?> -->

	<div class="recent-posts">
        <?php

        $query = new WP_Query(array(
            'meta_key' => 'post_views_count',
            'orderby' => 'meta_value_num',
            'order' => 'desc',
            'posts_per_page' => 5,
        ));

        if ($query->have_posts()) :
        ?>
        <div class="popular">
            <h2>Most Popular</h2>

            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <div class="item clearfix">
                    <?php printf('<a class="preview" href="%s">%s</a>', get_the_permalink(), theme_thumb_photo($post->ID, 'thumbnail')) ?>
                    <div class="title">
                        <?php printf('<a href="%s">%s</a>', get_the_permalink(), get_the_title()) ?>
                    </div>
                    <div class="date">
                        <?php echo get_the_date() ?>
                    </div>
                </div><!-- .item -->
            <?php endwhile; ?>

        </div>
            <?php wp_reset_postdata(); endif; ?>
	</div>

    <div class="banner_bottom" style="display:none;">
	    <?php echo cz('blog_banner_2'); ?>
		баннер 2
    </div>

</div>


            </div>

            <div class="popular-products">
                <div class="row">
                    <div class="popular-products-title">
                        <span class="p-title">
                            Most Popular Products from Our Store
                        </span>
                    </div>
                    <?php get_template_part( 'templates/products-best' ); ?>
                </div>
            </div>

		</div>
</div><!-- .container -->