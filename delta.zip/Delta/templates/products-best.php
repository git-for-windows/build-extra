<?php
global $GLOBAL, $post;
if ( ! isset( $GLOBAL[ 'id_post_show' ] ) ) {
	$GLOBAL[ 'id_post_show' ] = array();
}

$args = array(
	'post_type'      => 'product',
	'posts_per_page' => 8,
	'_orderby'       => 'promotionVolume',
	'_order'         => 'DESC',
	'post__not_in'   => $GLOBAL[ 'id_post_show' ]
);
query_posts( $args );?>
    <div class="b-products">
        <?php if ( have_posts() ) : while ( have_posts() ) :
	the_post();
	$GLOBAL[ 'id_post_show' ][] = $post->ID;
            get_template_part('templates/product');
endwhile; endif;
 ?>
    </div>

<?php wp_reset_query(); ?>