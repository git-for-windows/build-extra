<?php get_header(); ?>
    <div class="container">
        <?php get_template_part( 'templates/breadcrumbs' ); ?>

        <div class="b-grid-a-left b-margin-base">
            <?php get_template_part( 'templates/filter' ); ?>
        </div>
        <div class="b-grid-a-right b-margin-base">
            <?php get_template_part( 'templates/sort' ); ?>

            <?php if ( have_posts() ): ?>
                <div class="b-products b-products__min">

                    <?php
                       $info = new aliProductTM( array(
							'attributes' => true,
							'alimeta'    => true
						) );
                        //$todays = (get_option('ae-todaysdeal')) ? get_option('ae-todaysdeal') : '';
                        //$hotdeal = (get_option('ae-hotdeal')) ? get_option('ae-hotdeal') : '';

                        while ( have_posts() ) : the_post();

                            $post_id = get_the_ID();

                           $info->setData( $post_id );

                            get_template_part( 'templates/product' );

                        endwhile;

                    ?>
                </div>
                <div class="text-center">
                    <?php custom_pagination(); ?>
                </div>
            <?php else: ?>
                <?php get_template_part( 'templates/content', 'none' ); ?>
            <?php endif; ?>
        </div>
    </div>
<?php get_footer(); ?>