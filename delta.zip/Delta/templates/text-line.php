<?php $text_inline = '34423'; if($text_inline): ?>
<div class="container-fluid b-text-inline b-margin-base">
	<div class="container">
		<?php echo $text_inline; ?>&nbsp;
		<a class="btn btn-cwhite b-margin-upper" href="<?php echo esc_url( home_url( '/product' ) ); ?>">
			<?php
			$Catalog = '';
			if ( $Catalog && $Catalog != '' ):
				// echo $ali1->ssdma_catalogue;
			else:
				echo _e( 'Go to Catalogue', 'ssdma' );
			endif;
			?>
		</a>
	</div>
</div>
<?php endif; ?>
<?php $sf1 = '467657';
 $sf2 = '4765'; if($sf1 || $sf2): ?>
<div class="container b-social-widget b-margin-base">
	<div class="col-lg-12 b-margin-base">
		<?php echo $sf1; ?>
	</div>
	<div class="col-lg-12 b-margin-base">
		<?php echo $sf2; ?>
	</div>
</div>
<?php endif; ?>