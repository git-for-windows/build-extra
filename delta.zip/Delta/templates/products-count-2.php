<?php
 global $GLOBAL, $post;
$cat_id = $post->post_parent;
$terms = wp_get_post_terms( $post->ID, 'product_cat' );
$term = 0;
if($terms && is_array($terms) & count($terms) > 0) {
	$term = array_shift($terms); if($term) { $cat_id = $term->term_id; }
	}

if ( ! isset( $GLOBAL[ 'id_post_show' ] ) ) {
	$GLOBAL[ 'id_post_show' ] = array();
}

$args = array(
	'post_type'      => 'product',
	'posts_per_page' => 2,
	'_orderby'       => 'promotionVolume',
	'_order'         => 'DESC',
	'post__not_in'   => $GLOBAL[ 'id_post_show' ],
		'tax_query' => array(
	 array(
	'taxonomy' => 'product_cat',
    'field'    => 'id',
    'terms'    => $cat_id
	))
);
query_posts( $args );
?>
<?php if ( have_posts() ): ?>
	<?php while ( have_posts() ) : the_post(); ?>
	<?php get_template_part( 'templates/product' ); ?>
	<?php endwhile; ?>
<?php else: ?>
	<?php get_template_part( 'templates/content', 'none' ); ?>
<?php endif; ?>
<?php wp_reset_query(); ?>