
		<p><strong><?php _e( 'How to search products?', 'delta' ); ?></strong></p>
		<p><?php _e( 'Search for products by entering the product name or keyword into the', 'delta' ); ?> <em><?php _e( 'Search Bar', 'delta' ); ?></em> <?php _e( 'at the top of any page. Try to enter a general description. The more keywords you use, the less products you will get in the results page. When you find a product you’re interested in, simply click the product name or the product image for more details.', 'delta' ); ?></p>
		<p><strong><?php _e( 'How are shipping costs calculated?', 'delta' ); ?></strong></p>
		<p><?php _e( 'Shipping costs are calculated based on shipping method (air, sea or land) and product weight / volume. Different shipping companies have different rates, so it’s best to check and compare which is most affordable and economical. For more details on how shipping costs are calculated, please', 'delta' ); ?> <u><a href="/contact-us/"><?php _e( 'contact us', 'delta' ); ?></a></u> <?php _e( 'directly', 'delta' ); ?>.</p>
		<p><strong><?php _e( 'What is Buyer Protection?', 'delta' ); ?></strong></p>
		<p><?php _e( 'Buyer Protection is a set of guarantees that enables buyers to shop with confidence on our website.', 'delta' ); ?></p>
		<p><?php _e( 'You are protected when:', 'delta' ); ?></p>
		<ul>
			<li><?php _e( 'The item you ordered did not arrive within the time promised by the seller.', 'delta' ); ?></li>
			<li><?php _e( 'The item you received was not as described.', 'delta' ); ?></li>
			<li><?php _e( 'The item you received that was assured to be genuine was fake.', 'delta' ); ?></li>
		</ul>


