<?php
if ( isset( $_POST[ 'tp_create' ] ) && $_POST[ 'tp_create' ] == true && is_admin() ) {
	update_option( 'posts_per_rss', 20 );
	update_option( 'posts_per_page', 20 );
	update_option( 'show_on_front', 'page' );
	update_option( 'comments_per_page', 50 );
	update_option( 'page_comments', 1 );
	//$wp_rewrite->set_permalink_structure( '/%category%/%postname%/' );
	$wp_rewrite->set_permalink_structure( '/%postname%/' );

	$page = new mic_PageTemplate();
	$page->addPage( array( 'title' => 'Home', 'post_name' => 'home', 'static' => 'front' ) );
	$page->addPage( array( 'title' => 'All Products', 'post_name' => 'All Products', 'static' => 'posts' ) );

	$page->addPage( array( 'title' => __('Contact us', 'delta'), 'post_name' => 'contact-us' ) );
	$page->addPage( array( 'title' => __('Privacy policy', 'delta'), 'post_name' => 'privacy-policy' ) );
	$page->create();

	$memu   = array();
	$memu[] = array( 'title' => __( 'Home', 'delta' ), 'url' => '/' );
	$memu[] = array( 'title' => __( 'All Products', 'delta' ), 'url' => '/product/' );
	$memu[] = array( 'title' => __( 'Privacy policy', 'delta' ), 'url' => '/privacy-policy/' );
	$memu[] = array( 'title' => __( 'Contact us', 'delta' ), 'url' => '/contact-us/' );
	createMemu( $memu, 'Main Menu', 'primary' );

	$memu   = array();
	$memu[] = array( 'title' => __( 'Home', 'delta' ), 'url' => '/' );
	$memu[] = array( 'title' => __( 'All Products', 'delta' ), 'url' => '/product/' );
	$memu[] = array( 'title' => __( 'Privacy policy', 'delta' ), 'url' => '/privacy-policy/' );
	$memu[] = array( 'title' => __( 'Contact us', 'delta' ), 'url' => '/contact-us/' );
	createMemu( $memu, 'Footer', 'footer' );
	
	$memu   = array();
	$memu[] = array( 'title' => __( 'All Products', 'delta' ), 'url' => '/product/' );
	$memu[] = array( 'title' => __( 'Blog', 'delta' ), 'url' => '/blog/' );
	createMemu( $memu, 'Top Menu', 'topmenu' );

	$memu   = array();
	$memu[] = array( 'title' => __( 'Costumes', 'delta' ), 'url' => '/costumes/', 'slug' => 'costumes' );
	$memu[] = array( 'title' => __( 'Custom category', 'delta' ), 'url' => '/custom-category/', 'slug' => 'custom-category' );
	$memu[] = array( 'title' => __( 'Gifts', 'delta' ), 'url' => '/gifts/', 'slug' => 'gifts' );
	$memu[] = array( 'title' => __( 'Jewelry', 'delta' ), 'url' => '/jewelry/', 'slug' => 'jewelry' );
	$memu[] = array( 'title' => __( 'Men clothing', 'delta' ), 'url' => '/men-clothing/', 'slug' => 'men-clothing' );
	$memu[] = array( 'title' => __( 'Phone cases', 'delta' ), 'url' => '/phone-cases/', 'slug' => 'phone-cases' );
	$memu[] = array( 'title' => __( 'Posters', 'delta' ), 'url' => '/posters/', 'slug' => 'posters' );
	$memu[] = array( 'title' => __( 'T-shirts', 'delta' ), 'url' => '/t-shirts/', 'slug' => 't-shirts' );
	$memu[] = array( 'title' => __( 'Toys', 'delta' ), 'url' => '/toys/', 'slug' => 'toys' );
	$memu[] = array( 'title' => __( 'Women clothing', 'delta' ), 'url' => '/women-clothing/', 'slug' => 'women-clothing' );
	add_action( 'init', 'createCategoryProduct', 10, $memu );

}
//@TODO
function createCategoryProduct()
{
	$category   = array();
	$category[] = array( 'title' => __( 'Costumes', 'delta' ), 'url' => '/costumes/', 'slug' => 'costumes' );
	$category[] = array( 'title' => __( 'Custom category', 'delta' ), 'url' => '/custom-category/', 'slug' => 'custom-category' );
	$category[] = array( 'title' => __( 'Gifts', 'delta' ), 'url' => '/gifts/', 'slug' => 'gifts' );
	$category[] = array( 'title' => __( 'Jewelry', 'delta' ), 'url' => '/jewelry/', 'slug' => 'jewelry' );
	$category[] = array( 'title' => __( 'Men clothing', 'delta' ), 'url' => '/men-clothing/', 'slug' => 'men-clothing' );
	$category[] = array( 'title' => __( 'Phone cases', 'delta' ), 'url' => '/phone-cases/', 'slug' => 'phone-cases' );
	$category[] = array( 'title' => __( 'Posters', 'delta' ), 'url' => '/posters/', 'slug' => 'posters' );
	$category[] = array( 'title' => __( 'T-shirts', 'delta' ), 'url' => '/t-shirts/', 'slug' => 't-shirts' );
	$category[] = array( 'title' => __( 'Toys', 'delta' ), 'url' => '/toys/', 'slug' => 'toys' );
	$category[] = array( 'title' => __( 'Women clothing', 'delta' ), 'url' => '/women-clothing/', 'slug' => 'women-clothing' );
	foreach ( $category as $key => $item ) {
		wp_insert_term(
			$item[ 'title' ],
			'product_cat',
			array(
				'description' => '',
				'slug'        => $item[ 'slug' ],
				'parent'      => 0
			)
		);

	}
}

function createMemu( $memu, $menu_name, $location = false )
{
	$menu_exists = wp_get_nav_menu_object( $menu_name );
	if ( !$menu_exists ) {
		$menu_id = wp_create_nav_menu( $menu_name );

		if ( $location ) {
			$locations              = get_theme_mod( 'nav_menu_locations' );
			$locations[ $location ] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}

		foreach ( $memu as $key => $item ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'    => $item[ 'title' ],
				'menu-item-position' => $key,
				'menu-item-url'      => home_url( $item[ 'url' ] ),
				'menu-item-status'   => 'publish' ) );
		}

		return true;
	}

	return false;
}

class mic_PageTemplate
{
	private
		$_pages = array();

	function __construct()
	{
	}

	/**
	 * @param $page
	 * @throws Exception
	 */
	public function addPage( $page )
	{

		if ( empty( $page[ 'post_name' ] ) )
			throw new Exception( 'no post_name' );

		$page[ 'content' ] = $this->getContent( $page[ 'post_name' ] );

		array_push( $this->_pages, $page );
	}

	/**
	 * @return int|WP_Error
	 */
	public function create()
	{
		foreach ( $this->_pages as $page ) {

			$new_page = array(
				'post_type'    => 'page',
				'post_title'   => $page[ 'title' ],
				'post_name'    => $page[ 'post_name' ],
				'post_content' => $page[ 'content' ],
				'post_status'  => 'publish',
				'post_author'  => 1,
			);

			if ( !$this->issetPage( $page[ 'post_name' ] ) ) {
				$id = wp_insert_post( $new_page );
				if ( isset( $page[ 'static' ] ) && $page[ 'static' ] == 'front' ) update_option( 'page_on_front', $id );
				if ( isset( $page[ 'static' ] ) && $page[ 'static' ] == 'posts' ) update_option( 'page_for_posts', $id );
			}
		}
	}

	/**
	 * @param $slug
	 * @return bool
	 */
	private function issetPage( $slug )
	{
		$args       = array(
			'pagename'           => $slug
		);

		$page_check = new WP_Query( $args );
		if ( $page_check->post ) return true;

		return false;
	}

	/**
	 * @param $pagename
	 * @return mixed|string
	 */
	private function getContent( $pagename )
	{
		$file = dirname( __FILE__ ) . '/pages_default/' . $pagename . '.php';
		if ( file_exists( $file ) ) {
			ob_start();
			include( $file );
			$text = ob_get_contents();
			ob_end_clean();

			return $text;
		}

		return '';
	}
}