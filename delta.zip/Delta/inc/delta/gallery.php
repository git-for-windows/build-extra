<?php
function mic_theGallery( $items, $alt = '' ) {

	if ( ! $items || count( $items ) == 0 ) { ?>
		<div class="product-slider">
		</div>
		<?php
		return false;
	}

	?>
	<div class="product-slider">
		<ul class="thumb-list">
			<?php

			foreach ( $items as $k => $item ) {
				printf(
					'<li class="item-touch" data-image="%2$s">
							<div class="img"><img src="%1$s" alt="%2$s" data-zoom-image="%3$s" class="img-responsive" /></div>
							</li>',
					$item[ 'ali-large' ],
					$alt,
					$item[ 'full' ]
				);
			}
			?>
		</ul>
		<div class="img-wrap">
			<div class="img-main slider-for">

				<?php

				foreach ( $items as $k => $item ) {
					printf(
						'<img class="img-responsive" data-zoom-image="%1$s" src="%1$s" alt=""/>',
						$item[ 'full' ],
						$item[ 'ali-large' ]
					);
				}
				?>
			</div>
		</div>
	</div>
	<?php
}
