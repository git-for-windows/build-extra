<?php
if(!function_exists('list_review')){
	function list_review( $comment, $args, $depth ) {
		$images = get_comment_meta($comment->comment_ID, 'images', true);
        $size = 'ali-thumb';
		
		 $show_comments_imgs = true;

        if ($show_comments_imgs) {
            $images = get_comment_meta($comment->comment_ID, 'images', true);
            $size = 'ali-thumb';

            $gallery = ali_prepare_gallery($images, $size);

            if (!$gallery) {
                $gallery = array();
            }
        }

		$all_countries_indexes = ali_shipping_countries();
		?>
		<div class="col-lg-24 col-xs-22 review-one">
			<div class="col-lg-4 col-xs-4 text-center customer-info" itemscope itemtype="http://schema.org/Review" <?php comment_class('feedback-one'); ?> id="li-comment-<?php comment_ID() ?>">
				<?php printf( '<div><strong itemprop="name">%1$s</strong></div>', $comment->comment_author); ?>
				<div class="buyer-status"><?php _e('Verified buyer','delta')?></div>
				<div class="buyer-country"><?php 	if ( array_key_exists($comment->flag, $all_countries_indexes) ) printf( '<img src="%1$s"/>',  ali_pachFlag( $comment->flag ) . '?1000' ); ?></div>
			</div>
			<div class="col-lg-19 col-xs-19 col-lg-offset-1">
				<span itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">
					<meta itemprop="name" content="<?php the_title(); ?>"/>
				</span>
				<div class="feedback-rating-one"><strong><?php _e('Rating:','delta')?> </strong>
				<div class="stars" itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
					<meta itemprop="ratingValue" content="<?php echo $comment->star; ?>"/>
					<meta itemprop="bestRating" content="5.0"/>
					<?php  aliFeedBackTM::renderStarRating( $comment->star ); ?>
				</div>
				</div>
				<div>
				<?php
				printf( '<p class="text">%1$s</p>', $comment->comment_content ); ?>
				</div>
                    <div class="comment-mini-gallery">
                        <?php if ($show_comments_imgs && isset($gallery)) { ?>
                            <?php foreach ($gallery as $image): ?>

                                <?php
                                
                                $img_path = '';
                                $size = 'ali-thumb';

                                if ( array_key_exists('full', $image) ) {
                                    $img_path = $image['full'];
                                } else {
                                    $img_path = $image[$size];
                                }

                                ?>

                                <a href="<?php echo $img_path; ?>" target="_blank">
                                    <img src="<?php echo $image[$size]; ?>">
                                </a>
                            <?php endforeach; ?>
                        <?php } ?>
                    </div>
			</div>
		</div>
		<?php
	}
}


if(!function_exists('dav_comment_form_add')){
	function dav_comment_form_add( $post_id = null, $args = array() ) {
		global $id;

		if ( null === $post_id ) {
			$post_id = $id;
		} else {
			$id = $post_id;
		}

		$commenter     = wp_get_current_commenter();
		$user          = wp_get_current_user();
		$user_identity = $user->exists() ? $user->display_name : '';
		$req           = get_option( 'require_name_email' );
		$aria_req      = ( $req ? " aria-required='true'" : '' );
		$fields        = array(
			'author' => '<label for="author" class="col-sm-10 col-xs-10 control-label">' . __( 'Name (required)', 'delta' ) . '</label>
						<div class="col-sm-offset-1 col-sm-49 col-xs-49 col-xs-offset-1"><input class="form-control" id="author" name="author" type="text"
						value="' . esc_attr( $commenter[ 'comment_author' ] ) . '" ' . $aria_req . '/></div>',
			'email'  => '<label for="email" class="col-sm-10 col-xs-10  control-label">' . __( 'Email (required)', 'delta' ) . '</label>
						<div class="col-sm-offset-1 col-sm-49 col-xs-49 col-xs-offset-1"><input class="form-control" id="email" name="email" type="text"
						value="' . esc_attr( $commenter[ 'comment_author_email' ] ) . '" ' . $aria_req . '/></div>',
		);

		$defaults = array(
			'fields'               => apply_filters( 'comment_form_default_fields', $fields )
			,
			'comment_field'        => '<label for="comment" class="col-sm-10 col-xs-10 control-label">' . __( 'Comment', 'delta' ) . '</label>
                                <div class="col-sm-offset-1 col-sm-49 col-xs-49 col-xs-offset-1">
                                    <textarea class="form-control" name="comment" id="comment" aria-required="true" rows="8"></textarea>
                                    </div>'
			,
			'must_log_in'          => '<p>' . sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.', 'delta' ),
					wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>'
			,
			'logged_in_as'         => '<p>' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'delta' ),
					admin_url( 'profile.php' ), $user_identity,
					wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>'
			,
			'comment_notes_before' => ''
			,
			'comment_notes_after'  => ''
			,
			'id_form'              => 'commentform'
			,
			'id_submit'            => 'submit'
			,
			'title_reply'          => '
			<div class="head_form">
				<div class="col-sm-60 col-xs-60">  								
					<div class="col1"> 
						<div class="add_review_box">
							<div class="prod_head">
								<div class="cat_title">
									<span>Write a customer review:</span>
								</div>
							</div>
						</div>	 
					</div>
					<div class="col1 line_width"> 
						<div class="hr_line"></div>
					</div>													
				</div>
			</div'
			,
			'title_reply_to'       => __( "Leave a Reply to %s", 'delta' )
			,
			'cancel_reply_link'    => __( "Cancel reply", 'delta' )
			,
			'label_submit'         => __( "Post your review", 'delta' )
		);
		$args     = wp_parse_args( $args, apply_filters( 'comment_form_defaults', $defaults ) );

		if ( comments_open( $post_id ) ) :

			do_action( 'comment_form_before' );

			comment_form_title( $args[ 'title_reply' ], $args[ 'title_reply_to' ] ); ?>
			<small><?php cancel_comment_reply_link( $args[ 'cancel_reply_link' ] ); ?></small>

			<?php

			if ( get_option( 'comment_registration' ) && ! is_user_logged_in() ) :

				echo $args[ 'must_log_in' ];

				do_action( 'comment_form_must_log_in_after' );

			else :

				?>

				<form class="form-horizontal" action="<?php echo site_url( '/wp-comments-post.php' ); ?>"
				      method="post" id="<?php echo esc_attr( $args[ 'id_form' ] ); ?>">

					<?php
					do_action( 'comment_form_top' );

					if ( is_user_logged_in() ) :

						echo apply_filters( 'comment_form_logged_in', $args[ 'logged_in_as' ], $commenter, $user_identity );

						do_action( 'comment_form_logged_in_after', $commenter, $user_identity );

					else :

						echo $args[ 'comment_notes_before' ];

						do_action( 'comment_form_before_fields' );

						foreach ( (array) $args[ 'fields' ] as $name => $field ) {
							echo '<div class="form-group">' . apply_filters( "comment_form_field_{$name}", $field ) . '</div>';
						}

						do_action( 'comment_form_after_fields' );

					endif;

					?>
					<div class="form-group">
						<label for="comment" class="col-sm-10 control-label"><?php _e( 'Score' ); ?></label>
						<div class="col-sm-offset-1 col-sm-49">
							<?php for ( $i = 5; $i > 0; $i -- ) {
								printf( '<label class="checkbox-inline"><input type="radio" name="star" value="%1$s" class="widefat"  %2$s/> %1$s</label>',
									$i,
									0
								);
							}
							?>
						</div>
					</div>
					<?php
					echo '<div class="form-group">' . apply_filters( 'comment_form_field_comment', $args[ 'comment_field' ] ) . '</div>';
					?>

					<div class="form-group form_review">
						<div class="col-sm-offset-11 col-sm-49 review_but">
							<input name="submit" type="submit" class="btn btn-large rev_but"
							       id="<?php echo esc_attr( $args[ 'id_submit' ] ); ?>"
							       value="<?php echo esc_attr( $args[ 'label_submit' ] ); ?>"/>
						</div>
					</div>

					<?php
					echo $args[ 'comment_notes_after' ];

					comment_id_fields( $post_id );

					do_action( 'comment_form', $post_id );

					?>

				</form>

				<?php

			endif;

			do_action( 'comment_form_after' );

		else :

			do_action( 'comment_form_comments_closed' );

		endif;
	}
}