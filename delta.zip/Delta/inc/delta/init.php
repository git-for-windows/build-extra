<?php
if ( is_admin() ) {
	include( __DIR__ . '/create_page_template.php' );
}
include( __DIR__ . '/lang.php' );
include( __DIR__ . '/search_form.php' );
include( __DIR__ . '/pagination.php' );
include( __DIR__ . '/contact_form.php' );
include( __DIR__ . '/review.php' );
/*single*/
include( __DIR__ . '/gallery.php' );
include( __DIR__ . '/sku.php' );
/**
 * Register primary menu
 */
register_nav_menus( array(
	'primary' => 'Main Menu',
	'footer'  => 'Footer Menu',
) );


/**
 * Add theme support for Featured Images
 */
//add_image_size( 'big-blog', 824, 349, true );
//add_image_size( 'min-blog', 285, 177, true );
add_theme_support( 'post-thumbnails' );

/**
 * Enqueue script
 */
function dav_enqueue_script() {

	wp_register_script( 'fotorama', get_template_directory_uri() . '/public/js/fotorama.js',
		array(
			'jquery'
		), '1.0', true );

	/**
	 * init single.php blog
	 * */

	// Yandex Share
	wp_register_script( 'ya.shims', '//yastatic.net/es5-shims/0.0.2/es5-shims.min.js', null, '0.0.2', true );
	wp_register_script( 'ya.share', '//yastatic.net/share2/share.js', array( 'ya.shims' ), '2.0.0', true );
	// Facebook SDK
	wp_register_script( 'facebook', sprintf( '//connect.facebook.net/%1$s/sdk.js#xfbml=1&version=v2.5&appId=1049899748393568', get_bloginfo( 'language' ) ), array(), '2.5.0', true );

	/**/

	wp_register_script( 'delta', get_template_directory_uri() . '/public/js/index.js', array(
		'jquery',
		'jquery-ui-slider',
		'fotorama'
	), '1.0', true );

	wp_localize_script( 'delta', 'alidAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

	wp_enqueue_script( 'delta' );


}

add_action( 'wp_enqueue_scripts', 'dav_enqueue_script' );


/**
 * Filter to excerpt
 *
 * @param $length
 *
 * @return int
 */
function mic_excerpt_length( $length ) {
	return 50;
}

add_filter( 'excerpt_length', 'mic_excerpt_length' );

/**
 * Filter to name pages
 *
 * @param $pagename
 *
 * @return string
 */
add_filter( 'ads_template_pagename', function ( $pagename ) {
	return 'alids';
} );

/**
 * Excerpt after text
 *
 * @param $more
 *
 * @return string
 */
function mic_excerpt_more( $more ) {
	return "...";
}

add_filter( 'excerpt_more', 'mic_excerpt_more' );


/**
 * Get count items in Basket
 *
 * @return int
 */

function srtCut($str, $cut_chars = 55, $hr = ' ... '){
    if( strlen($str) >= $cut_chars ){
        $endStr = mb_substr($str, 0, $cut_chars);
        return $endStr . $hr;
    } else {
        return $str;
    }
}