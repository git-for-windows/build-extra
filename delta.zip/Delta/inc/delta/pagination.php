<?php

/**
 * Pagination
 */
function custom_pagination($isPageOf = false) {
	global $wp_query;
	$big = 999999999; // need an unlikely integer
	$total = $wp_query->max_num_pages;
	$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
	$pages = paginate_links( array(
		'base'               => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format'             => '?page=%#%',
		'total'              => $total,
		'current'            => max( 1, $paged ),
		// 'show_all'           => true,
		// 'end_size'           => 1,
		// 'mid_size'           => 2,
		'prev_next'          => true,
		'prev_text'          => '<i class="fa fa-angle-left"></i>',
		'next_text'          => '<i class="fa fa-angle-right"></i>',
		'type'               => 'array',
		// 'add_args'           => false,
		// 'add_fragment'       => '',
		// 'before_page_number' => '',
		// 'after_page_number'  => '',
	) );

    /*
	if( is_array( $pages ) ) {

		echo '<div class="wrap-pagination">';
		echo '<ul class="pagination">';

		if ( $isPageOf ) {
			$keyFirst = 0;
			$keyLast = count($pages) - 1;

			// var_dump( $pages[$keyFirst] );
			// var_dump( $pages[$keyLast] );

			if ( is_numeric($pages[$keyFirst]) ) {
				echo "<li>$pages[$keyFirst]</li>";
			}

			printf( '<li><span>%1$s %3$d %2$s %4$d</span></li>', __('Page'), __('of'), $paged, $total );

			if ( is_numeric($pages[$keyLast]) ) {
				echo "<li>$pages[$keyLast]</li>";
			}

		} else {

			foreach ( $pages as $page ) {
				echo "<li>$page</li>";
			}

		}

		echo '</ul>';
		echo '</div>';
	}
    */

    if( is_array( $pages ) ) {

        echo '<div class="wrap-pagination">';
        echo '<ul class="pagination">';

        if ( $isPageOf ) {
            $keyFirst = 0;
            $keyLast = count($pages) - 1;

            // var_dump( $pages[$keyFirst] );
            // var_dump( $pages[$keyLast] );



            if ( is_numeric($pages[$keyFirst]) ) {
                echo "<li>$pages[$keyFirst]</li>";
            }

            printf( '<li><span>%1$s %3$d %2$s %4$d</span></li>', __('Page'), __('of'), $paged, $total );

            if ( is_numeric($pages[$keyLast]) ) {
                echo "<li>$pages[$keyLast]</li>";
            }

        } else {

            foreach ( $pages as $page ) {

                $result = explode("#038;order=", $page);

                $this_current_page = strpos($page, "current");

                if ( isset($result[1]) && !$this_current_page ) {

                    $excess_param = $result[1];

                    $necessary_filter_param = "";
                    $url = "";
                    $class = "";
                    $link_text = "";
                    $filtered_page = "";

                    if ($excess_param == "ASC") {
                        $necessary_filter_param = "order=ASC";
                    } else if ($excess_param == "DESC") {
                        $necessary_filter_param = "order=DESC";
                    }

                    $url_fragment_1 = explode("href=", $page);
                    $url_fragment_2 = explode("\">", $url_fragment_1[1]);
                    $url_fragment_3 = explode("#038;order=", $url_fragment_2[0]);
                    $url_fragment_3 = str_replace("'", "", $url_fragment_3);
                    $url_fragment_3 = str_replace("\"", "", $url_fragment_3);
                    $url = $url_fragment_3[0] . $necessary_filter_param;

                    $page_fragment_1 = explode("<a", $page);
                    $page_fragment_2 = explode("href=", $page_fragment_1[1]);
                    $class = $page_fragment_2[0];

                    $have_icon = strpos($page, "fa-angle");

                    if( $have_icon ) {
                        $page_fragment_4 = explode($necessary_filter_param . "\">", $page);
                        $page_fragment_5 = explode("</a", $page_fragment_4[1]);

                        $link_text = $page_fragment_5[0];
                    } else {
                        $page_fragment_3 = str_replace("'", "", $page);
                        $page_fragment_3 = str_replace("\"", "", $page_fragment_3);
                        $page_fragment_4 = explode($necessary_filter_param . ">", $page_fragment_3);
                        $page_fragment_5 = explode("</a", $page_fragment_4[1]);

                        $link_text = $page_fragment_5[0];
                    }

                    $filtered_page = '<a ' . $class . ' href="' . $url . '">' . $link_text . '</a>';

                    echo "<li>$filtered_page</li>";

                } else {

                    echo "<li>$page</li>";

                }

            }

        }

        echo '</ul>';
        echo '</div>';

    }














}