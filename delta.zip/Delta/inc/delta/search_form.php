<?php
/**
 * Search form hook
 *
 * @param $form
 *
 * @return string
 */
function mic_search_form( $form ) {

	ob_start();

	?>
<form class="b-search" role="search" method="GET" action="<?php echo esc_url(home_url( '/' )) ?>">
	<div class="input-group">
		<input type="text" name="s" class="form-control" placeholder="<?php _e('Search for a product, category or brand', 'delta'); ?>" value="<?php echo get_search_query() ?>">
		<span class="input-group-btn">
			<button class="btn btn-default" type="submit">
				<span class="b-social-icon-search"></span>
			</button>
		</span>
	</div>
</form>
	<?php

	$return = ob_get_contents();
	ob_end_clean();

	return $return;
}

add_filter( 'get_search_form', 'mic_search_form' );
