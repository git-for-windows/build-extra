<?php
function delta_lang_init() {

	load_theme_textdomain('delta', get_template_directory() . '/lang');
}
add_action( 'init', 'delta_lang_init' );