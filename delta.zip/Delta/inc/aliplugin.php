<?php
if(!class_exists('\ads\adsProduct')){
	return 'update';
}
class aliProductTM extends \ads\adsProduct {
	public $is_free_shipping = false;
	public $price_shipping   = false;

	public function __construct( $args = array() ) {
		$post_id = '';
		parent::__construct( $post_id, $args );
	}

	public function starRating( $count = false ) {
		$number = floatval( $this->getRate() );
		$max    = 5;

		$int  = intval( $number );
		$star = array();

		for ( $i = 0; $i < $int; $i ++ ) {
			$star[] = 'full';
		}

		if ( $int != $number ) {
			$star[] = 'half';
		}

		$empty = $max - count( $star );
		for ( $i = 0; $i < $empty; $i ++ ) {
			$star[] = 'no';
		}

		$star = implode( '"></span><span class="star star-', $star );

		$method = $count ? '<span class="call-item"> (' . $count . ')</span>' : '';

		return '<div class="stars"><span class="star star-' . $star . '"></span>' . $method . '</div>';
	}

	public function ratingPercentage() {
		$number = floatval( $this->getRate() );
		$max    = 5;

		return ( $number * 100 ) / $max;
	}

	private function getSave($_salePrice, $_price){

		$savePercent = $_price > 0 && $_salePrice > 0 ? round( ( ( $_price - $_salePrice ) / $_price ) * 100 ) : false;
		if ( $savePercent && $savePercent > 0 ) {
			$save = ali_price_out_current_front( $_price - $_salePrice );
		} else {
			$savePercent = '';
			$save = '';
		}

		return array(
			'savePercent'=> $savePercent,
			'save'=> $save
		);
	}

	function singleProduct() {

		$currency   = $this->getCurrency();
		$_price     = function_exists( 'ali_price_convert' ) ? ali_price_convert( $this->getPrice(), $currency ) : 0;
		$_salePrice = function_exists( 'ali_price_convert' ) ? ali_price_convert( $this->getSalePrice(), $currency ) : 0;

		if ( $_salePrice < $_price ) {
			$price = ali_price_out_current_front( $_price );
		} else {
			$price = false;
		}

		$salePrice = ali_price_out_current_front( $_salePrice );

		$skuAttr = $this->getSkuAttr();
		if ( $skuAttr ) {
			foreach ( $skuAttr as &$v ) {
				$v[ 'price' ]     = ali_price_convert( $v[ 'price' ], $currency );
				$v[ 'salePrice' ] = ali_price_convert( $v[ 'salePrice' ], $currency );

				$v[ 'discount' ] = '';
				$v[ 'save' ]     = '';
				if ( $v[ 'price' ] > 0 ) {
					$v[ 'save' ]     = ali_price_out_current_front( $v[ 'price' ] - $v[ 'salePrice' ] );
					$v[ 'discount' ] = round( ( ( $v[ 'price' ] - $v[ 'salePrice' ] ) / $v[ 'price' ] ) * 100 );
				}
				$v[ '_price' ]     = $v[ 'price' ];
				$v[ 'price' ]      = ali_price_out_current_front( $v[ 'price' ] );
				$v[ '_salePrice' ] = $v[ 'salePrice' ];
				$v[ 'salePrice' ]  = ali_price_out_current_front( $v[ 'salePrice' ] );
			}
		}

		/*вывод цены первой вариации*/
		$sku = $this->getSku();
		if ( ! empty( $sku ) ) {
			$attrPrice = $skuAttr;
			$attrPrice = array_shift($attrPrice);
			$_salePrice = $attrPrice['_salePrice'];
			$salePrice = $attrPrice['salePrice'];
			$_price = $attrPrice['_price'];
			$price = $attrPrice['price'];
		}

		$saveInfo = $this->getSave($_salePrice, $_price);
		$shipping = $this->getShipping();

		return array(
			//'service'     => $this->getService(),
			'price'       => $price,
			'salePrice'   => $salePrice,
			'_price'      => $_price,
			'_salePrice'  => $_salePrice,
			'savePercent' => $saveInfo['savePercent'],
			'save'        => $saveInfo['save'],
			'currency'    => $currency,
			'quantity'    => $this->getQuantity(),

			'shipping'         => $shipping,
//			'renderShipping'   => $this->renderShipping( $shipping ),
			'is_free_shipping' => $this->is_free_shipping,
			'price_shipping'   => $this->price_shipping,

			'rate'            => $this->getRate(),
			'promotionVolume' => $this->getPromotionVolume(),

			'pack'   => $this->getPack(),
			'attrib' => $this->getAttributes(),

			'gallery' => $this->getGallery(),
			'sku'     => $sku,
			'skuAttr' => $skuAttr,
		);
	}

	public function singleProductMin() {

		$currency   = $this->getCurrency();
		$_price     = ali_price_convert( $this->getPrice(), $currency );
		$_salePrice = ali_price_convert( $this->getSalePrice(), $currency );

		$price     = $_price !== $_salePrice ? ali_price_out_current_front( $_price ) : false;
		$salePrice = ali_price_out_current_front( $_salePrice );

		$discount = $_price > 0 && $_salePrice > 0 ? round( ( ( $_price - $_salePrice ) / $_price ) * 100 ) : false;
		$discount = ( $discount && $discount > 0 ) ? $discount : false;

		$thumb = $this->getImageUrl( 'ali-medium' );


		return array(
			'_price'     => $_price,
			'price'      => $price,
			'_salePrice' => $_salePrice,
			'salePrice'  => $salePrice,
			'currency'   => $currency,
			'discount'   => $discount,
			'thumb'      => $thumb
		);
	}

}


class aliFeedBackTM extends \ads\adsFeedback {

	public function __construct($post_id) {
		global $wp_query;
		$cpage = max( 1, get_query_var( 'cpage' ) );

		$posts_per_page = ( isset( $wp_query->query_vars[ 'comments_per_page' ] ) &&
		                    intval( $wp_query->query_vars[ 'comments_per_page' ] ) ) ?
			$wp_query->query_vars[ 'comments_per_page' ] :
			intval( get_option( 'comments_per_page' ) );

		parent::__construct($post_id, $cpage, $posts_per_page );
	}

	static public function renderStarRating( $rating ) {
		$full_stars  = floor( $rating );
		$half_stars  = ceil( $rating - $full_stars );
		$empty_stars = 5 - $full_stars - $half_stars;

		echo str_repeat( '<span class="star b-social-icon b-social-icon-star-full"></span>', $full_stars );
		echo str_repeat( '<span class="star b-social-icon b-social-icon-star-empty"></span>', $half_stars );
		echo str_repeat( '<span class="star b-social-icon b-social-icon-star-empty"></span>', $empty_stars );
	}
}
