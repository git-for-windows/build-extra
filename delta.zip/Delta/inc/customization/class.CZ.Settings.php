<?php
class czSettings extends czAdminTpl {

	function __construct() {
		parent::__construct();
	}

	/**
	 * list menu
	 * @return array
	 */
	public function listMenu() {
		$listMenu = array(
			'czbase' => array(
				'tmp'         => 'tmplGeneral',
				'title'       => __( 'General', 'delta' ),
				'description' => __( 'Some basic configuration settings.', 'delta' ),
				'icon'        => 'tachometer',
				'submenu'     => array()
			),

			'czhead'          => array(
				'tmp'         => 'tmplHead',
				'title'       => __( 'Head', 'delta' ),
				'description' => __( 'Use this section to add and edit scripts and styles.', 'delta' ),
				'icon'        => 'life-ring',
				'submenu'     => array()
			),
			'czheader'        => array(
				'tmp'         => 'tmplHeader',
				'title'       => __( 'Header', 'delta' ),
				'description' => __( 'Header main elements settings.', 'delta' ),
				'icon'        => 'cog',
				'submenu'     => array()
			),
			'czhome'          => array(
				'tmp'         => 'tmplHome',
				'title'       => __( 'Home', 'delta' ),
				'description' => __( 'Home page main settings.', 'delta' ),
				'icon'        => 'home',
				'submenu'     => array()
			),
			'czsingleproduct' => array(
				'tmp'         => 'tmplSingleProduct',
				'title'       => __( 'Single product', 'delta' ),
				'description' => __( 'Single product page main settings.', 'delta' ),
				'icon'        => 'home',
				'submenu'     => array()
			),
			'czcontactus'     => array(
				'tmp'         => 'tmplContactUs',
				'title'       => __( 'Contact Us', 'delta' ),
				'description' => __( 'Contact Us', 'delta' ),
				'icon'        => 'smile-o ',
				'submenu'     => array()
			),
			'czsocial'        => array(
				'tmp'         => 'tmplSocial',
				'title'       => __( 'Social Media', 'delta' ),
				'description' => __( 'Social media pages integration.', 'delta' ),
				'icon'        => 'hand-o-right ',
				'submenu'     => array()
			),
			'czsubscribe'     => array(
				'tmp'         => 'tmplSubscribe',
				'title'       => __( 'Subscribe Form', 'delta' ),
				'description' => __( 'Subscription form settings for collecting users’ emails.', 'delta' ),
				'icon'        => 'envelope',
				'submenu'     => array()
			),
			'czfooter'        => array(
				'tmp'         => 'tmplFooter',
				'title'       => __( 'Footer', 'delta' ),
				'description' => __( 'Footer options and settings.', 'delta' ),
				'icon'        => 'bars',
				'submenu'     => array()
			),
			'czseo'           => array(
				'tmp'         => 'tmplSeo',
				'title'       => __( 'SEO', 'delta' ),
				'description' => __( 'SEO meta data settings.', 'delta' ),
				'icon'        => 'line-chart',
				'submenu'     => array()
			)
		);

		return apply_filters( 'cz_list_menu', $listMenu );
	}

	/**
	 * Template Base
	 */
	function tmplGeneral() {
		$this->block(
			array(
				$this->Button( 'tp_create', array(
					'label' => __( 'Add default pages and menus', 'delta' ),
					'value' => true,
					'text'  => __( 'Create', 'delta' )
				) )
			)
		);

		$this->block( $this->row( array(
				$this->textField( 's_mail', array(
					'label' => __( 'Contact email', 'delta' ),
				) ),
				$this->textField( 's_phone', array(
					'label' => __( 'Contact phone', 'delta' ),
				) )
			)
		) );

		$this->block(
			array(

				$this->row( array(
					$this->colorField( 'tp_color_header', array(
						'label' => __( 'Template color header', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_footer', array(
						'label' => __( 'Template color footer', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_text', array(
						'label' => __( 'Template color header text', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_footer_text', array(
						'label' => __( 'Template color footer text', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_discount', array(
						'label' => __( 'Discount color', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_buttons_colors', array(
						'label' => __( 'Buttons Color', 'delta' )
					) ),
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_price_product', array(
						'label' => __( 'Prices color', 'delta' ),
					) )
				) )
			)
		);

		$this->block(
			$this->uploadImgField( 'tp_favicon', array(
					'label'  => __( 'Favicon', 'delta' ),
					'width'  => 16,
					'height' => 16,
				)
			)
		);

		$this->block(
			array(
				$this->row( array(
					$this->textField( 'tp_head_ga', array(
						'label' => __( 'Google Analytics Tracking ID', 'delta' ),
					) )
				) )
				//$this->row( array(
				//	$this->textField( 'tp_facebook_pixel', array(
				//		'label' => __( 'Facebook Pixel Code', 'delta' ),
				//	) )
				//) )
			)
		);

	}

	/**
	 * Template Header
	 */
	function tmplHead() {
		$this->block(
			array(
				$this->textTextArea( 'tp_head', array(
					'label' => __( '< head > tag container for head elements', 'delta' ),
					'rows'  => 10
				) ),
				$this->textTextArea( 'tp_style', array(
					'label' => __( 'css style', 'delta' ),
					'rows'  => 10
				) )
			)
		);
	}

	/**
	 * Template Header
	 */
	function tmplHeader() {

		$this->block(
			array(
				$this->row(
					array(
						$this->uploadImgField( 'tp_logo_img', array(
							'label'  => __( 'Website logo', 'delta' ),
							'width'  => 25,
							'height' => 21,
						) )
					) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_top', array(
						'label' => __( 'Color header top', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_top_color', array(
						'label' => __( 'Color header top text', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_top_social_color', array(
						'label' => __( 'Header social color', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_top_social_color_hover', array(
						'label' => __( 'Header social color hover', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_hover', array(
						'label' => __( 'Menu hover color', 'delta' ),
					) )
				) ),
				$this->row( array(
					$this->colorField( 'tp_color_header_border', array(
						'label' => __( 'Menu border color', 'delta' ),
					) )
				) ),
			)
		);
		$this->block(
			$this->row(
				$this->uploadImgField( 'free_shipping', array(
					'label'  => __( 'Free shipping image', 'delta' ),
					'width'  => 180,
					'height' => 42,
				) )
			)
		);
	}

	/**
	 * Template Settings
	 */
	function tmplHome() {
		$slider_home = $this->slider_home		;
		$foo         = array();
		foreach ( $slider_home as $k => $v ) {
			array_push( $foo,
				$this->row(
					array(
						$this->uploadImgField( 'slider_home[' . $k . '][img]', array(
							'value'  => $v[ 'img' ],
							'label'  => __( 'image', 'delta' ) . ' - ' . ($k+1),
							'width'  => 960,
							'height' => 350,
						) )
					) )
			);
        
			array_push( $foo,
				$this->row( array(
					$this->textField( 'slider_home[' . $k . '][head]', array(
						'value'       => $v[ 'head' ],
						'label'       => __( 'Header Text', 'delta' ) . ' - ' . ($k+1),
						'description' => '',
					) )
				) )
			);
        
			array_push( $foo,
				$this->row( array(
					$this->textField( 'slider_home[' . $k . '][text]', array(
						'value'       => $v[ 'text' ],
						'label'       => __( 'Text', 'delta' ) . ' - ' . ($k+1),
						'description' => '',
					) )
				) )
			);
			array_push( $foo,
				$this->row( array(
					$this->textField( 'slider_home[' . $k . '][text_button]', array(
						'value'       => $v[ 'text_button' ],
						'label'       => __( 'Text Button', 'delta' ) . ' - ' . ($k+1),
						'description' => '',
					) )
				) )
			);
        
			array_push( $foo,
				$this->row( array(
					$this->textField( 'slider_home[' . $k . '][shop_now_link]', array(
						'value'       => $v[ 'shop_now_link' ],
						'label'       => __( 'Shop now link', 'delta' ) . ' - ' . ($k+1),
						'description' => '',
					) )
				) )
			);
		}
		$this->block( $foo,
			array( 'title' => 'Image' )
		);
		$this->block( $this->textTextArea( 'tp_inform_home_1',
			array(
				'label' => 'Banner 1',
				'rows'  => 20
			) ) );
		$terms = get_terms('product_cat', array('hide_empty' => false));
            $default = 0;
            $categories = array();
            if( count($terms) ) {
                foreach( $terms as $term ) {
                    if(!$default){
                        $default = $term->term_id;
                    }
                    $categories[$term->term_id] = $term->name . ' (' . $term->count . ')';
                }
            }
		$this->block( array(
			$this->row( array(
				$this->textField( 'text_inline', array(
					'label' => __( 'Text', 'delta' ),
				) ),
				$this->textField( 'text_inline_button', array(
					'label' => __( 'Button text', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->colorField( 'text_inline_back', array(
					'label' => __( 'Background color', 'delta' ),
				) ),
				$this->colorField( 'text_inline_color', array(
					'label' => __( 'Text color', 'delta' ),
				) ),
			) ),
			$this->row( array(
				$this->colorField( 'text_inline_button_back', array(
					'label' => __( 'Button background color', 'delta' ),
				) ),
				$this->colorField( 'text_inline_button_color', array(
					'label' => __( 'Button text color', 'delta' ),
				) ),
			) )
		), array( 'title' => __( 'Shopping slogan block', 'delta' ) ) );
		$this->block( array(
			$this->row( array(
					$this->dropDownField( 'tp_products_cat1', array(
                        'label'=> __('Categories tab 1', 'delta'),
                        'value'=> $categories,
						), false),
					$this->dropDownField( 'tp_products_cat2', array(
                        'label'=> __('Categories tab 2', 'delta'),
                        'value'=> $categories,
						), false),
                    )),
            $this->row( array(
					$this->dropDownField( 'tp_products_cat3', array(
                        'label'=> __('Categories tab 3', 'delta'),
                        'value'=> $categories,
                    ), false),
					$this->dropDownField( 'tp_products_cat4', array(
                        'label'=> __('Categories tab 4', 'delta'),
                        'value'=> $categories,
                    ), false),
					))
					));
	
		$this->block( array(
			$this->row( array(
				$this->checkboxField( 'show_protection', array(
					'label' => __( 'Show "Buyer protection" block', 'delta' ),
				) )
			) ),
			));
		$this->block( array(
			$this->row( array(
				$this->colorField( 'tp_tabs_color', array(
					'label' => __( 'Tabs text color', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->colorField( 'tp_tabs_color_hover', array(
					'label' => __( 'Tabs text hover color', 'delta' ),
				) )
			) ),
			));
	}

	/**
	 * Template Social
	 */
	function tmplSocial() {

		$this->block( array(
			$this->row( array(
				$this->textField( 's_link_tw', array(
					'label' => __( 'Twitter link', 'delta' ),
				) ),
				$this->textField( 's_link_gl', array(
					'label' => __( 'Google plus link', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->textField( 's_link_pt', array(
					'label' => __( 'Pinterest link', 'delta' ),
				) ),
				$this->textField( 's_link_fb', array(
					'label' => __( 'Facebook link', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->textField( 's_link_yt', array(
					'label' => __( 'Youtube link', 'delta' ),
				) ),
				$this->textField( 's_link_vk', array(
					'label' => __( 'VK link', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->textField( 's_link_inst', array(
					'label' => __( 'Instagram link', 'delta' ),
				) )
			) )
		), array( 'title' => __( 'Social pages links', 'delta' ) ) );

		$this->block( array(
			$this->row( array(
				$this->checkboxField( 'twitter_on', array(
					'label' => __( 'Twitter enable', 'delta' ),
				) ),
				$this->checkboxField( 'gplus_on', array(
					'label' => __( 'Google plus enable', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->checkboxField( 'pinterest_on', array(
					'label' => __( 'Pinterest enable', 'delta' ),
				) ),
				$this->checkboxField( 'facebook_on', array(
					'label' => __( 'Facebook enable', 'delta' ),
				) )
			) ),
			$this->row( array(
				$this->checkboxField( 'youtube_on', array(
					'label' => __( 'Youtube enable', 'delta' ),
				) ),
				$this->checkboxField( 'vk_on', array(
					'label' => __( 'VK enable', 'delta' ),
				) )
			) ),
			$this->row(
				$this->checkboxField( 'instagram_on', array(
					'label' => __( 'Instagram enable', 'delta' ),
				) )
			 )
		), array( 'title' => __( 'Social buttons', 'delta' ) ) );
	}

	/**
	 * Template Footer
	 */
	function tmplFooter() {

		$this->block(
			$this->row( array(
					$this->colorField( 'tp_color_footer_social_color', array(
						'label' => __( 'Footer social color', 'delta' ),
					) ),
					$this->colorField( 'tp_color_footer_social_color_hover', array(
						'label' => __( 'Footer social color hover', 'delta' ),
					) )
				) )
				);
		$this->block(
			$this->row(
				$this->uploadImgField( 'tp_logo_img_w', array(
					'label'  => __( 'Logo', 'delta' ),
					'width'  => 161,
					'height' => 56,
				) )
			)
		);


		$this->block(
			array(
				$this->row(
					$this->textTextArea( 'tp_copyright', array() )
				),
				$this->row(
					$this->textTextArea( 'tp_address', array() )
				),
				$this->row(
					$this->textTextArea( 'tp_copyright__line', array() )
				)
			),
			array( 'title' => __( 'Copyright', 'delta' ) )
		);

		$this->block(
			$this->row(
				$this->textTextArea( 'tp_footer_script', array(
					'label' => __( 'Footer tag container', 'delta' ),
					'rows'  => 20
				) )
			));
		$this->block(
			$this->row(
				$this->checkboxField( 'show_partners', array(
					'label' => __( 'Show "Partners" block', 'delta' )
				) )
			)
		);

	}


	/**
	 * Template Subscribe
	 */
	function tmplSubscribe() {
    
		$this->block(
			$this->row(
				$this->textTextArea( 'tp_subscribe', array(
					'label' => __( 'Paste your ‘Autoresponder’ code here', 'delta' ),
					'rows'  => 20
				) )
			)
		);
	}

	function tmplContactUs() {

		$this->block(
			array(
				$this->row(
					$this->textTextArea( 'tp_contactUs_text', array(
						'label' => __( 'Paste your ‘Autoresponder’ code here', 'delta' ),
						'rows'  => 20
					) )
				),
				$this->row(
					$this->uploadImgField( 'tp_contactUs_map', array(
						'label'  => __( 'Image map', 'delta' ),
						'width'  => 470,
						'height' => 349,
					) )
				)
			)
		);
	}

	/**
	 * Template SEO
	 */
	function tmplSeo() {
		$this->block( array(
			$this->textTextArea( 'tp_home_seo_title', array(
				'label' => __( 'SEO Title', 'delta' )
			) ),
			$this->textTextArea( 'tp_home_seo_description', array(
				'label' => __( 'SEO Description', 'delta' )
			) ),
			$this->textTextArea( 'tp_home_seo_keywords', array(
				'label' => __( 'Keywords', 'delta' )
			) )
		),
			array( 'title' => 'Home Page' ) );


		$this->block( array(
			$this->textTextArea( 'tp_seo_products_title', array(
				'label' => __( 'SEO Title', 'delta' )
			) ),
			$this->textTextArea( 'tp_seo_products_description', array(
				'label' => __( 'SEO Description', 'delta' )
			) ),
			$this->textTextArea( 'tp_seo_products_keywords', array(
				'label' => __( 'Keywords', 'delta' )
			) )
		),
			array( 'title' => 'All Products' ) );

	}

	/**
	 * Template Settings
	 */
	function tmplSingleProduct() {
		$this->block( $this->checkboxField( 'tp_price_block', array( 'label' => 'Enable price block' ) ) );
		$this->block( $this->checkboxField( 'tp_guarantee', array( 'label' => 'Enable guarantee block' ) ) );
		$this->block( array(
			$this->row(
				$this->colorField( 'product_price_block_button_bg', array(
					'label' => __( 'Price block button background', 'delta' )
				) )
			),
			$this->row(
				$this->colorField( 'product_price_block_button_color', array(
					'label' => __( 'Price block button text color', 'delta' )
				) )
			),
			$this->row(
				$this->colorField( 'product_price_block_button_hover_bg', array(
					'label' => __( 'Price block button hover background', 'delta' )
				) )
			))
		);
	}


}
