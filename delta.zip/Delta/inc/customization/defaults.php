<?php
return array(
	'tp_head'                => '',
	'tp_style'               => '',


	/*base*/
	'tp_head_ga'             => '',
	//'tp_facebook_pixel'      => '',
	'tp_create'              		=> true,
	'show_protection'              		=> true,
	'show_partners'              		=> true,
	'tp_color_header_top'    		=> '#E9E9E9',
	'tp_color_header_top_color'     => '#878787',
	'tp_color_header_top_social_color'     => '#898989',
	'tp_color_header_top_social_color_hover'     => '#333',
	'tp_color_footer_social_color'     => '#898989',
	'tp_color_footer_social_color_hover'     => '#333',
	'tp_color_header'        		=> '#01a0c7',
	'tp_color_header_hover' 		=> '#1bb3d8',
	'tp_color_footer'        		=> '#2b2728',
	'tp_color_header_text'    	    => '#fff',
	'tp_color_footer_text'    	    => '#898989',
	'tp_discount'          			=> '#898989',
	'tp_color_price_product'		=> '#687b9c',

	'tp_logo_img'   => get_template_directory_uri() . '/public/images/logo_header.png',
	'tp_logo_img_w' => '',
	'tp_favicon'    => get_template_directory_uri() . '/favicon.ico',
	's_mail'        => 'support@' . $_SERVER[ 'SERVER_NAME' ],
	's_phone'       => '1 (716) 235 57 71',
	'free_shipping'       =>  get_template_directory_uri() . '/public/images/free-shipping.jpg',

	'tp_buttons_colors' => '#01a0c7',

	/*home*/
	//'id_video_youtube_home' => 'rsbZbmMk3BY',
		
	'slider_home' => array(
		array(
			'img'           => get_template_directory_uri() . '/public/images/header_img1.jpg',
			'head'          => __( 'FIND THE BEST CHOICES', 'delta'),
			'text'          => __( 'We have collected over million product reviews from experts and customers.', 'delta'),
			'text_button'   => __( 'Go to catalogue', 'delta'),
			'shop_now_link' => home_url( '/product/' ),
		),
		array(
			'img'           => get_template_directory_uri() . '/public/images/header_img2.jpg',
			'head'          => __( 'FIND THE BEST CHOICES', 'delta'),
			'text'          => __( 'We have collected over million product reviews from experts and customers.', 'delta'),
			'text_button'   => __( 'Go to catalogue', 'delta'),
			'shop_now_link' => home_url( '/product/' ),
		),
		array(
			'img'           => get_template_directory_uri() . '/public/images/header_img3.jpg',
			'head'          => __( 'FIND THE BEST CHOICES. ', 'delta'),
			'text'          => __( 'We have collected over million product reviews from experts and customers.', 'delta'),
			'text_button'   => __( 'Go to catalogue', 'delta'),
			'shop_now_link' => home_url( '/product/' ),
		),
//		array(
//			'img'           => IMG_DIR . 'slider2.jpg',
//			'head'          => 'What is Lorem Ipsum?',
//			'text'          => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan',
//			'shop_now_link' => home_url( '/product/' ),
//		),
//		array(
//			'img'           => IMG_DIR . 'slider1.jpg',
//			'head'          => 'What is Lorem Ipsum?',
//			'text'          => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan',
//			'shop_now_link' => home_url( '/product/' ),
//		),
	),
	'tp_inform_home_1' => '',
	'tp_products_cat1' => '0',
	'tp_products_cat2' => '0',
	'tp_products_cat3' => '0',
	'tp_products_cat4' => '0',
	'text_inline' => 'Smart shopping better living',
	'text_inline_button' => 'Go to catalogue',
	'text_inline_back' => '#676b74',
	'text_inline_color' => '#fff',
	'text_inline_button_back' => '#fff',
	'text_inline_button_color' => '#EC555C',
	'tp_color_header_border' => '#bdf2ff',
	'tp_tabs_color' => '#9C9C9C',
	'tp_tabs_color_hover' => '#FF545C',

	'tp_price_block'				  => true,
	'tp_guarantee'				 	  => true,
	'product_price_block_button_bg'				  => '#FFA22E',
	'product_price_block_button_color'			  => '#fff',
	'product_price_block_button_hover_bg'		  => '#FFB032',


	/*SEO*/
	'tp_home_seo_title'                  => '',
	'tp_home_seo_description'            => '',
	'tp_home_seo_keywords'               => '',

	'tp_seo_products_title'       => __( 'All products', 'delta' ),
	'tp_seo_products_description' => __( 'All products – choose the ones you like.', 'delta' ),
	'tp_seo_products_keywords'    => '',

	/*contact Us*/
	'tp_contactUs_text'             => __( 'Have any questions or need to get more information?', 'delta' ),
	'tp_contactUs_map'              => get_template_directory_uri() . '/public/images/map.jpg',

	/*social*/
	's_link_fb'                     => 'https://facebook.com/',
	's_link_tw'           => 'https://twitter.com/',
	's_link_gl'           => 'https://plus.google.com/',
	's_link_pt'           => 'https://www.pinterest.com/',
	's_link_yt'           => 'https://www.youtube.com/',
	's_link_vk'           => 'https://www.vk.com/',
	's_link_inst'           => 'https://www.vk.com/',
	'facebook_on'				  => true,
	'twitter_on'				  => true,
	'gplus_on'					  => true,
	'youtube_on'				  => true,
	'pinterest_on'				  => true,
	'vk_on'				 		  => true,
	'instagram_on'				  => true,

	/*subscribe*/
	'tp_subscribe'        => '',


	'tp_copyright'               => '© Copyright {{YEAR}}. All Rights Reserved',
	'tp_address'                 => 'Mountain View, CA 94043, US',
	'tp_copyright__line'         => $_SERVER[ 'SERVER_NAME' ],
	'tp_footer_script'           => '',

);