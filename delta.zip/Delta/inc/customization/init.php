<?php
define( 'IMG_DIR', get_template_directory_uri() . '/img/' );


class czOptions {
	protected $field_options = 'cz_options';
	protected $data          = array();

	public function __construct() {
		$theme               = wp_get_theme();
		$this->field_options = 'cz_' . $theme->get( 'Name' );
		//$this->field_options = 'cz_ami3.0';

		//@TODO save stripslashes
		$this->data = get_site_option( $this->field_options );
		$options    = $this->get_defaults();
		$this->data = wp_parse_args( $this->data, $options );
	}

	//@TODO save stripslashes
	public function __get( $name ) {

		if ( array_key_exists( $name, $this->data ) ) {

			return $this->stripslashes( $this->data[ $name ] );
		} else {
			throw new \Exception( 'Getting unknown property:' . $name );
		}

		return null;
	}

	private function stripslashes( $data ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $k => $v ) {
				$data[ $k ] = $this->stripslashes( $v );
			}
		} else {
			$data = stripslashes( $data );
		}

		return $data;
	}

//@TODO save stripslashes
	public function data() {
		$data = $this->data;

		foreach ( $data as $k => $v ) {
			$v          = $this->stripslashes( $v );
			$data[ $k ] = $v;
		}

		return $data;
	}

	public function get_defaults() {
		$defaults = include dirname( __FILE__ ) . '/defaults.php';

		return apply_filters( 'cz_fields', $defaults );
	}

	public static function getTemplateField( $pagename ) {
		$file = dirname( __FILE__ ) . '/template/' . $pagename . '.php';
		if ( file_exists( $file ) ) {
			ob_start();
			include( $file );
			$text = ob_get_contents();
			ob_end_clean();

			return $text;
		}

		return '';
	}

}
require( dirname( __FILE__ ) . '/style.php' );
if ( is_admin() ) {
	require( dirname( __FILE__ ) . '/menu.php' );
	require( dirname( __FILE__ ) . '/class.CZ.AdminTpl.php' );
	require( dirname( __FILE__ ) . '/class.CZ.Settings.php' );
	require( dirname( __FILE__ ) . '/core.php' );
}



add_action( 'init', 'init_cz' );
function init_cz() {
	global $cz_data;
	$cz      = new czOptions();
	$cz_data = $cz->data();
}


if ( ! function_exists( 'cz' ) ) {
	function cz( $name ) {
		global $cz_data;

		return isset( $cz_data[ $name ] ) ? $cz_data[ $name ] : '';
	}
}
