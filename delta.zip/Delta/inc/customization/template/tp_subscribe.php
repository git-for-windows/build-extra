<div class="subscribe-block">
	<div class="item">
		<?php _e('Subscription', 'delta')?>	</div>

	<div class="item">
		<form id="footer-subscribe-form" method="POST" accept-charset="UTF-8" action="https://www.aweber.com/scripts/addlead.pl">

			<input type="hidden" name="meta_web_form_id" value="509496166"/>
			<input type="hidden" name="meta_split_id" value=""/>
			<input type="hidden" name="listname" value="awlist3960106"/>
			<input type="hidden" name="redirect" value="http://dima.wherebabieslive.com/subscription"
						 id="redirect_b6fdc6e08dd59b71518c2776b932a856"/>
			<input type="hidden" name="meta_adtracking" value="World_Of_Harry_Potter"/>
			<input type="hidden" name="meta_message" value="1001"/>
			<input type="hidden" name="meta_required" value="email"/>
			<input type="hidden" name="meta_tooltip" value=""/>

			<div class="form-item">
				<input type="text" name="email" value="" placeholder="Please enter your email" class="subscribe-info">
				<div class="additional-info">
					<?php _e('Register now to get recent news and updates', 'delta')?>				</div>
			</div>

			<div class="form-item">
				<button class="button" name="submit" type="submit" value="Submit">
					<?php _e('Subscribe', 'delta')?>				</button>
			</div>

		</form>
	</div>
</div>
