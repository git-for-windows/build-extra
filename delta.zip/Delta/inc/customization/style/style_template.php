.b-product_order .btn.btn-orange{
	background: <?php echo cz( 'product_price_block_button_bg' ) ?>;
	color: <?php echo cz( 'product_price_block_button_color' ) ?>;
}
.b-product_order .btn.btn-orange:hover{
	background: <?php echo cz( 'product_price_block_button_hover_bg' ) ?>;
}
.b-c-tabs li a{
	color:  <?php echo cz( 'tp_tabs_color' ) ?>;
}
.b-c-tabs li.active a, .b-c-tabs li a:hover, .b-c-tabs li a:focus{
	color:  <?php echo cz( 'tp_tabs_color_hover' ) ?>;
}
.b-social li a{
	color:  <?php echo cz( 'tp_color_header_top_social_color' ) ?>;
}
.b-social li a:hover{
	color:  <?php echo cz( 'tp_color_header_top_social_color_hover' ) ?>;
}
.b-footer .b-social li a span{
	color:  <?php echo cz( 'tp_color_footer_social_color' ) ?>!important;
}
.b-footer .b-social li a:hover span{
	color:  <?php echo cz( 'tp_color_footer_social_color_hover' ) ?>!important;
}
.nav-c-top li a{
	color:  <?php echo cz( 'tp_color_header_top_color' ) ?>;
}
.b-top-menu{
	background-color:<?php echo cz( 'tp_color_header_top' ) ?>;
}
.btn.btn-cwhite{
	background: <?php echo cz( 'text_inline_button_back' ) ?>;
	color:  <?php echo cz( 'text_inline_button_color' ) ?>;
	border-bottom: 2px solid <?php echo cz( 'text_inline_button_back' ) ?>;
}
.b-text-inline{
	background-color: <?php echo cz( 'text_inline_back' ) ?>;
	color:  <?php echo cz( 'text_inline_color' ) ?>;
}
.b-main-menu li:hover{
  background-color: <?php echo cz( 'tp_color_header_hover' ) ?>!important;
}
.dropdown-menu li:hover{
	  background-color: <?php echo cz( 'tp_color_header_hover' ) ?>!important; 
 }
.b-main-menu{
  background-color: <?php echo cz( 'tp_color_header' ) ?>!important;
}
.dropdown-menu{
	  background-color: <?php echo cz( 'tp_color_header' ) ?>!important; 
 }
.b-footer{
  background-color: <?php echo cz( 'tp_color_footer' ) ?>!important;
}
.nav-c-main-menu:after{
    border-right: 1px solid <?php echo cz( 'tp_color_header_border' ) ?>;
}
.nav-c-main-menu li:after{
    border-right: 1px solid <?php echo cz( 'tp_color_header_border' ) ?>;
}
.b-main-menu li a, .dropdown-menu li a{
  color: <?php echo cz( 'tp_color_header_text' ) ?>!important;
}
.b-footer *{
  color: <?php echo cz( 'tp_color_footer_text' ) ?>!important;
}
.b-products__price_old, .products-mini .item .price.old, .b-product_price_old {
	color: <?php echo cz( 'tp_discount' ) ?>;
}
.b-products .b-products__item .b-products__price, .products-mini .item .price, .h-left-sidebar, .b-product_price_now, .bw-saleprice span{
	color: <?php echo cz( 'tp_color_price_product' ) ?>;
}
.b-filter-slider .ui-slider-range{
	background: <?php echo cz( 'tp_color_price_product' ) ?>;
}
.btn.btn-cred{
		background: <?php echo cz( 'tp_buttons_colors' ) ?>!important;
}
.b-search button{
		background-color: <?php echo cz( 'tp_buttons_colors' ) ?>!important;
		border-color: <?php echo cz( 'tp_buttons_colors' ) ?>!important;
}


.top-block{
	<?php foreach (cz('slider_home') as $item): ?>
	background: url(<?php echo $item['img'] ?>) no-repeat center
	<?php endforeach; ?>
}




