<?php get_header(); ?>
<div class="container">
	<?php get_template_part( 'templates/breadcrumbs' ); ?>
	<?php get_template_part( 'templates/catalog' ); ?>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>