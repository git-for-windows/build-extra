<?php get_header(); ?>
<div class="container">
	<?php get_template_part( 'templates/breadcrumbs' ); ?>
	<h1 class="page-title b-margin-base">
		<?php single_cat_title(); ?>
	</h1>
	<?php get_template_part( 'templates/catalog' ); ?>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>