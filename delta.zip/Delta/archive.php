<?php get_header(); ?>
<div class="container">
	<?php get_template_part( 'templates/breadcrumbs' ); ?>
	<h1 class="page-title b-margin-base">
		<?php if ( is_day() ) : printf( __( 'Daily Archives: %s', 'delta' ), get_the_date() );
				elseif ( is_month() ) : printf( __( 'Monthly Archives: %s', 'delta' ),
						get_the_date( _x( 'F Y', 'monthly archives date format', 'delta' ) ) );
				elseif( is_year() ): printf( __( 'Yearly Archives: %s', 'delta' ),
						get_the_date( _x( 'Y', 'yearly archives date format', 'delta' ) ) );
				else: _e( 'Archives', 'delta' );
				endif;
		?>
	</h1>
	<?php get_template_part( 'templates/catalog' ); ?>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>