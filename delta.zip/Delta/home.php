<?php get_header(); ?>

<?php if (cz('slider_home') ) { ?>
	<div class="container">
    <div class="hidden-xs">
    <div class="fotorama">
<?php foreach (cz('slider_home') as $item): ?>
                <?php
                if ( isset($item['img']) && $item['img']){ ?>
					<span class="fotorama">
						<div class="b-header-img">
							<img class="img-responsive" src="<?php echo $item['img'] ?>">
								<div class="b-header-img__caption"><?php echo $item['head'] ?><br/><br/>
									<?php echo $item['text']?><br/><br/>
									<a class="btn btn-cred" href="<?php echo $item['shop_now_link']?>">
										<?php echo $item['text_button']?>
									</a>
								</div>
						</div>
					</span>
				<?php }?>
<?php endforeach; ?>
  
<?php  } ?>
    </div>
    </div>
	</div>
<?php if (cz('show_protection') ) { ?>
	<div class="container">
		<div class="b-protection clearfix b-margin-base b-margin-upper"><?php get_template_part( 'templates/protection' ); ?></div>
	</div>
<?php  } ?>

<?php if (cz('tp_inform_home_1') ) { ?>
	<div class="container text-center">
	<?php	echo cz('tp_inform_home_1')?>
	</div>
<?php  } ?>
	<div class="container b-margin-base">
	<div role="tabpanel">
		<ul class="b-c-tabs" role="tablist">
			<li role="presentation" class="active">
				<a href="#specials" aria-controls="specials" role="tab" data-toggle="tab"><?php _e( 'Specials', 'delta' ) ?>
					<span class="b-social-icon-sort"></span>
				</a>
			</li>
			<li role="presentation">
				<a href="#latest" aria-controls="latest" role="tab" data-toggle="tab"><?php _e( 'Latest', 'delta' ) ?>
					<span class="b-social-icon-sort"></span>
				</a>
			</li>
			<li role="presentation">
				<a href="#sellers" aria-controls="sellers" role="tab" data-toggle="tab"><?php _e( 'Best sellers', 'delta' ) ?>
					<span class="b-social-icon-sort"></span>
				</a>
			</li>
		</ul>
		<div class="tab-content">
			<div role="tabpanel" class="tab-pane active"
			     id="specials"><?php get_template_part( 'templates/products-special' ); ?></div>
			<div role="tabpanel" class="tab-pane"
			     id="latest"><?php get_template_part( 'templates/products-latest' ); ?></div>
			<div role="tabpanel" class="tab-pane"
			     id="sellers"><?php get_template_part( 'templates/products-best' ); ?></div>
		</div>
	</div>
	</div>
	<?php 
if (cz('text_inline') ) :?>
	<div class="container-fluid b-text-inline b-margin-base">
		<div class="container">
			<?php echo cz('text_inline'); ?> &nbsp;
			<?php if (cz('text_inline_button') ) :?>
				<a class="btn btn-cwhite" href="<?php echo esc_url( home_url( '/product' ) ); ?>">
					<?php echo cz('text_inline_button'); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>
	<div class="container">
		<div class="col-lg-6 col-md-12 col-sm-12 col-xs-24 mobilecat"><?php get_template_part( 'templates/products-cat-1' ); ?></div>
		<div class="col-lg-6 col-md-12 col-sm-12 col-xs-24 mobilecat"><?php get_template_part( 'templates/products-cat-2' ); ?></div>
		<div class="col-lg-6 col-md-12 col-sm-12 col-xs-24 mobilecat"><?php get_template_part( 'templates/products-cat-3' ); ?></div>
		<div class="col-lg-6 col-md-12 col-sm-12 col-xs-24 mobilecat"><?php get_template_part( 'templates/products-cat-4' ); ?></div>
	</div>

<?php
$seo_main = '';
echo $seo_main; ?>
<?php $sf1 = '';
$sf2       = ''; //$ali1->ssdma_beforef2_line;
if ( $sf1 || $sf2 ): ?>
	<div class="container b-social-widget b-margin-base">
		<div class="col-lg-12 b-margin-base"><?php echo $sf1; ?></div>
		<div class="col-lg-12 b-margin-base"><?php echo $sf2; ?></div>
	</div>
<?php endif; ?>
<?php get_footer(); ?>