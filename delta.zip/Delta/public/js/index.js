if ("undefined" == typeof jQuery)throw new Error("Bootstrap's JavaScript requires jQuery");

jQuery(function($) {


$(document).ready(function(){
        $(window).scroll(function(){
            var bo = $("body").scrollTop();
			if ( bo > 500 ) { $(".buy-window").css("display", "block"); } else { $(".buy-window").css("display", "none"); };
        })
    });
    $('a#modal_call_alibaba').click( function(event){
        event.preventDefault();
        $('#overlay').fadeIn(400, function(){
            $('#modal_form').css('display', 'block').animate({opacity: 1, top: '50%'}, 200);
        });
    });

    $('#modal_close, #overlay').click(function(){
        $('#modal_form').animate({opacity: 0, top: '45%'}, 200, function(){
            $(this).css('display', 'none');
            $('#overlay').fadeOut(400);
        });
    });

    function isURL( str ) {

        var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
        return regexp.test( str );
    }

    $.fn.sku = function ( defaults ) {

        var options = $.extend( {
            item          : '.sku-set',
            sku           : '.item-sku',
            slider        : '.b-product_preview .b-product_preview__main',
        }, defaults );

        var th = $( this );

        var setSKU = function () {

            th.on('click', options.item, function(){

                var line = $(this).parents( options.sku );

                if ( $(this).hasClass('active') ) {
                    $(this).removeClass('active');
                }
                else {
                    line.find( options.item ).each( function () {
                        $( this ).removeClass( 'active' );
                    } );
                    line.find('dt').css('color','');

                    $(this).addClass( 'active' );

                    if( typeof $(this).find('img') != 'undefined' ) {

                        var src = $(this).find('img').attr('src');

                        if ( isURL( src ) ) {

                            if ( src.indexOf( '_50x50.jpg' ) > 0 ) {
                                src = src.replace( '_50x50.jpg', '' );
                            }

                            $(options.slider).find('img').attr('src', src);
                        }
                    }
                }
            });
        };

        return this.each( setSKU );
    };

    $('.sku-listing').sku();

    $('.fotorama').fotorama({
        width: '100%',
        maxwidth: '100%',
        ratio: 16/9,
        loop: true,
        nav: false,
        maxheight: '410px',
        arrows : true,
        click : true,
		autoplay: true,
        swipe : true
    });

    $('.mobile_menu').click(
        function(){
            $('.nav-c-top').toggle();
        }
    );
    $('.second_menu_button').click(
        function(){
            $('.b-main-menu').toggle();
        }
    );
});

+function (t) {
    "use strict";
    var e = t.fn.jquery.split(" ")[0].split(".");
    if (e[0] < 2 && e[1] < 9 || 1 == e[0] && 9 == e[1] && e[2] < 1)throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher")
}(jQuery), +function (t) {
    "use strict";
    function e() {
        var t = document.createElement("bootstrap"), e = {
            WebkitTransition: "webkitTransitionEnd",
            MozTransition: "transitionend",
            OTransition: "oTransitionEnd otransitionend",
            transition: "transitionend"
        };
        for (var i in e)if (void 0 !== t.style[i])return {end: e[i]};
        return !1
    }

    t.fn.emulateTransitionEnd = function (e) {
        var i = !1, o = this;
        t(this).one("bsTransitionEnd", function () {
            i = !0
        });
        var n = function () {
            i || t(o).trigger(t.support.transition.end)
        };
        return setTimeout(n, e), this
    }, t(function () {
        t.support.transition = e(), t.support.transition && (t.event.special.bsTransitionEnd = {
            bindType: t.support.transition.end,
            delegateType: t.support.transition.end,
            handle: function (e) {
                return t(e.target).is(this) ? e.handleObj.handler.apply(this, arguments) : void 0
            }
        })
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var i = t(this), n = i.data("bs.alert");
            n || i.data("bs.alert", n = new o(this)), "string" == typeof e && n[e].call(i)
        })
    }

    var i = '[data-dismiss="alert"]', o = function (e) {
        t(e).on("click", i, this.close)
    };
    o.VERSION = "3.3.2", o.TRANSITION_DURATION = 150, o.prototype.close = function (e) {
        function i() {
            s.detach().trigger("closed.bs.alert").remove()
        }

        var n = t(this), a = n.attr("data-target");
        a || (a = n.attr("href"), a = a && a.replace(/.*(?=#[^\s]*$)/, ""));
        var s = t(a);
        e && e.preventDefault(), s.length || (s = n.closest(".alert")), s.trigger(e = t.Event("close.bs.alert")), e.isDefaultPrevented() || (s.removeClass("in"), t.support.transition && s.hasClass("fade") ? s.one("bsTransitionEnd", i).emulateTransitionEnd(o.TRANSITION_DURATION) : i())
    };
    var n = t.fn.alert;
    t.fn.alert = e, t.fn.alert.Constructor = o, t.fn.alert.noConflict = function () {
        return t.fn.alert = n, this
    }, t(document).on("click.bs.alert.data-api", i, o.prototype.close)
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.button"), a = "object" == typeof e && e;
            n || o.data("bs.button", n = new i(this, a)), "toggle" == e ? n.toggle() : e && n.setState(e)
        })
    }

    var i = function (e, o) {
        this.$element = t(e), this.options = t.extend({}, i.DEFAULTS, o), this.isLoading = !1
    };
    i.VERSION = "3.3.2", i.DEFAULTS = {loadingText: "loading..."}, i.prototype.setState = function (e) {
        var i = "disabled", o = this.$element, n = o.is("input") ? "val" : "html", a = o.data();
        e += "Text", null == a.resetText && o.data("resetText", o[n]()), setTimeout(t.proxy(function () {
            o[n](null == a[e] ? this.options[e] : a[e]), "loadingText" == e ? (this.isLoading = !0, o.addClass(i).attr(i, i)) : this.isLoading && (this.isLoading = !1, o.removeClass(i).removeAttr(i))
        }, this), 0)
    }, i.prototype.toggle = function () {
        var t = !0, e = this.$element.closest('[data-toggle="buttons"]');
        if (e.length) {
            var i = this.$element.find("input");
            "radio" == i.prop("type") && (i.prop("checked") && this.$element.hasClass("active") ? t = !1 : e.find(".active").removeClass("active")), t && i.prop("checked", !this.$element.hasClass("active")).trigger("change")
        } else this.$element.attr("aria-pressed", !this.$element.hasClass("active"));
        t && this.$element.toggleClass("active")
    };
    var o = t.fn.button;
    t.fn.button = e, t.fn.button.Constructor = i, t.fn.button.noConflict = function () {
        return t.fn.button = o, this
    }, t(document).on("click.bs.button.data-api", '[data-toggle^="button"]', function (i) {
        var o = t(i.target);
        o.hasClass("btn") || (o = o.closest(".btn")), e.call(o, "toggle"), i.preventDefault()
    }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function (e) {
        t(e.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(e.type))
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.carousel"), a = t.extend({}, i.DEFAULTS, o.data(), "object" == typeof e && e), s = "string" == typeof e ? e : a.slide;
            n || o.data("bs.carousel", n = new i(this, a)), "number" == typeof e ? n.to(e) : s ? n[s]() : a.interval && n.pause().cycle()
        })
    }

    var i = function (e, i) {
        this.$element = t(e), this.$indicators = this.$element.find(".carousel-indicators"), this.options = i, this.paused = this.sliding = this.interval = this.$active = this.$items = null, this.options.keyboard && this.$element.on("keydown.bs.carousel", t.proxy(this.keydown, this)), "hover" == this.options.pause && !("ontouchstart"in document.documentElement) && this.$element.on("mouseenter.bs.carousel", t.proxy(this.pause, this)).on("mouseleave.bs.carousel", t.proxy(this.cycle, this))
    };
    i.VERSION = "3.3.2", i.TRANSITION_DURATION = 600, i.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    }, i.prototype.keydown = function (t) {
        if (!/input|textarea/i.test(t.target.tagName)) {
            switch (t.which) {
                case 37:
                    this.prev();
                    break;
                case 39:
                    this.next();
                    break;
                default:
                    return
            }
            t.preventDefault()
        }
    }, i.prototype.cycle = function (e) {
        return e || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(t.proxy(this.next, this), this.options.interval)), this
    }, i.prototype.getItemIndex = function (t) {
        return this.$items = t.parent().children(".item"), this.$items.index(t || this.$active)
    }, i.prototype.getItemForDirection = function (t, e) {
        var i = this.getItemIndex(e), o = "prev" == t && 0 === i || "next" == t && i == this.$items.length - 1;
        if (o && !this.options.wrap)return e;
        var n = "prev" == t ? -1 : 1, a = (i + n) % this.$items.length;
        return this.$items.eq(a)
    }, i.prototype.to = function (t) {
        var e = this, i = this.getItemIndex(this.$active = this.$element.find(".item.active"));
        return t > this.$items.length - 1 || 0 > t ? void 0 : this.sliding ? this.$element.one("slid.bs.carousel", function () {
            e.to(t)
        }) : i == t ? this.pause().cycle() : this.slide(t > i ? "next" : "prev", this.$items.eq(t))
    }, i.prototype.pause = function (e) {
        return e || (this.paused = !0), this.$element.find(".next, .prev").length && t.support.transition && (this.$element.trigger(t.support.transition.end), this.cycle(!0)), this.interval = clearInterval(this.interval), this
    }, i.prototype.next = function () {
        return this.sliding ? void 0 : this.slide("next")
    }, i.prototype.prev = function () {
        return this.sliding ? void 0 : this.slide("prev")
    }, i.prototype.slide = function (e, o) {
        var n = this.$element.find(".item.active"), a = o || this.getItemForDirection(e, n), s = this.interval, r = "next" == e ? "left" : "right", l = this;
        if (a.hasClass("active"))return this.sliding = !1;
        var c = a[0], h = t.Event("slide.bs.carousel", {relatedTarget: c, direction: r});
        if (this.$element.trigger(h), !h.isDefaultPrevented()) {
            if (this.sliding = !0, s && this.pause(), this.$indicators.length) {
                this.$indicators.find(".active").removeClass("active");
                var d = t(this.$indicators.children()[this.getItemIndex(a)]);
                d && d.addClass("active")
            }
            var p = t.Event("slid.bs.carousel", {relatedTarget: c, direction: r});
            return t.support.transition && this.$element.hasClass("slide") ? (a.addClass(e), a[0].offsetWidth, n.addClass(r), a.addClass(r), n.one("bsTransitionEnd", function () {
                a.removeClass([e, r].join(" ")).addClass("active"), n.removeClass(["active", r].join(" ")), l.sliding = !1, setTimeout(function () {
                    l.$element.trigger(p)
                }, 0)
            }).emulateTransitionEnd(i.TRANSITION_DURATION)) : (n.removeClass("active"), a.addClass("active"), this.sliding = !1, this.$element.trigger(p)), s && this.cycle(), this
        }
    };
    var o = t.fn.carousel;
    t.fn.carousel = e, t.fn.carousel.Constructor = i, t.fn.carousel.noConflict = function () {
        return t.fn.carousel = o, this
    };
    var n = function (i) {
        var o, n = t(this), a = t(n.attr("data-target") || (o = n.attr("href")) && o.replace(/.*(?=#[^\s]+$)/, ""));
        if (a.hasClass("carousel")) {
            var s = t.extend({}, a.data(), n.data()), r = n.attr("data-slide-to");
            r && (s.interval = !1), e.call(a, s), r && a.data("bs.carousel").to(r), i.preventDefault()
        }
    };
    t(document).on("click.bs.carousel.data-api", "[data-slide]", n).on("click.bs.carousel.data-api", "[data-slide-to]", n), t(window).on("load", function () {
        t('[data-ride="carousel"]').each(function () {
            var i = t(this);
            e.call(i, i.data())
        })
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        var i, o = e.attr("data-target") || (i = e.attr("href")) && i.replace(/.*(?=#[^\s]+$)/, "");
        return t(o)
    }

    function i(e) {
        return this.each(function () {
            var i = t(this), n = i.data("bs.collapse"), a = t.extend({}, o.DEFAULTS, i.data(), "object" == typeof e && e);
            !n && a.toggle && "show" == e && (a.toggle = !1), n || i.data("bs.collapse", n = new o(this, a)), "string" == typeof e && n[e]()
        })
    }

    var o = function (e, i) {
        this.$element = t(e), this.options = t.extend({}, o.DEFAULTS, i), this.$trigger = t(this.options.trigger).filter('[href="#' + e.id + '"], [data-target="#' + e.id + '"]'), this.transitioning = null, this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger), this.options.toggle && this.toggle()
    };
    o.VERSION = "3.3.2", o.TRANSITION_DURATION = 350, o.DEFAULTS = {
        toggle: !0,
        trigger: '[data-toggle="collapse"]'
    }, o.prototype.dimension = function () {
        var t = this.$element.hasClass("width");
        return t ? "width" : "height"
    }, o.prototype.show = function () {
        if (!this.transitioning && !this.$element.hasClass("in")) {
            var e, n = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
            if (!(n && n.length && (e = n.data("bs.collapse"), e && e.transitioning))) {
                var a = t.Event("show.bs.collapse");
                if (this.$element.trigger(a), !a.isDefaultPrevented()) {
                    n && n.length && (i.call(n, "hide"), e || n.data("bs.collapse", null));
                    var s = this.dimension();
                    this.$element.removeClass("collapse").addClass("collapsing")[s](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), this.transitioning = 1;
                    var r = function () {
                        this.$element.removeClass("collapsing").addClass("collapse in")[s](""), this.transitioning = 0, this.$element.trigger("shown.bs.collapse")
                    };
                    if (!t.support.transition)return r.call(this);
                    var l = t.camelCase(["scroll", s].join("-"));
                    this.$element.one("bsTransitionEnd", t.proxy(r, this)).emulateTransitionEnd(o.TRANSITION_DURATION)[s](this.$element[0][l])
                }
            }
        }
    }, o.prototype.hide = function () {
        if (!this.transitioning && this.$element.hasClass("in")) {
            var e = t.Event("hide.bs.collapse");
            if (this.$element.trigger(e), !e.isDefaultPrevented()) {
                var i = this.dimension();
                this.$element[i](this.$element[i]())[0].offsetHeight, this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1), this.$trigger.addClass("collapsed").attr("aria-expanded", !1), this.transitioning = 1;
                var n = function () {
                    this.transitioning = 0, this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                };
                return t.support.transition ? void this.$element[i](0).one("bsTransitionEnd", t.proxy(n, this)).emulateTransitionEnd(o.TRANSITION_DURATION) : n.call(this)
            }
        }
    }, o.prototype.toggle = function () {
        this[this.$element.hasClass("in") ? "hide" : "show"]()
    }, o.prototype.getParent = function () {
        return t(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(t.proxy(function (i, o) {
            var n = t(o);
            this.addAriaAndCollapsedClass(e(n), n)
        }, this)).end()
    }, o.prototype.addAriaAndCollapsedClass = function (t, e) {
        var i = t.hasClass("in");
        t.attr("aria-expanded", i), e.toggleClass("collapsed", !i).attr("aria-expanded", i)
    };
    var n = t.fn.collapse;
    t.fn.collapse = i, t.fn.collapse.Constructor = o, t.fn.collapse.noConflict = function () {
        return t.fn.collapse = n, this
    }, t(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function (o) {
        var n = t(this);
        n.attr("data-target") || o.preventDefault();
        var a = e(n), s = a.data("bs.collapse"), r = s ? "toggle" : t.extend({}, n.data(), {trigger: this});
        i.call(a, r)
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        e && 3 === e.which || (t(n).remove(), t(a).each(function () {
            var o = t(this), n = i(o), a = {relatedTarget: this};
            n.hasClass("open") && (n.trigger(e = t.Event("hide.bs.dropdown", a)), e.isDefaultPrevented() || (o.attr("aria-expanded", "false"), n.removeClass("open").trigger("hidden.bs.dropdown", a)))
        }))
    }

    function i(e) {
        var i = e.attr("data-target");
        i || (i = e.attr("href"), i = i && /#[A-Za-z]/.test(i) && i.replace(/.*(?=#[^\s]*$)/, ""));
        var o = i && t(i);
        return o && o.length ? o : e.parent()
    }

    function o(e) {
        return this.each(function () {
            var i = t(this), o = i.data("bs.dropdown");
            o || i.data("bs.dropdown", o = new s(this)), "string" == typeof e && o[e].call(i)
        })
    }

    var n = ".dropdown-backdrop", a = '[data-toggle="dropdown"]', s = function (e) {
        t(e).on("click.bs.dropdown", this.toggle)
    };
    s.VERSION = "3.3.2", s.prototype.toggle = function (o) {
        var n = t(this);
        if (!n.is(".disabled, :disabled")) {
            var a = i(n), s = a.hasClass("open");
            if (e(), !s) {
                "ontouchstart"in document.documentElement && !a.closest(".navbar-nav").length && t('<div class="dropdown-backdrop"/>').insertAfter(t(this)).on("click", e);
                var r = {relatedTarget: this};
                if (a.trigger(o = t.Event("show.bs.dropdown", r)), o.isDefaultPrevented())return;
                n.trigger("focus").attr("aria-expanded", "true"), a.toggleClass("open").trigger("shown.bs.dropdown", r)
            }
            return !1
        }
    }, s.prototype.keydown = function (e) {
        if (/(38|40|27|32)/.test(e.which) && !/input|textarea/i.test(e.target.tagName)) {
            var o = t(this);
            if (e.preventDefault(), e.stopPropagation(), !o.is(".disabled, :disabled")) {
                var n = i(o), s = n.hasClass("open");
                if (!s && 27 != e.which || s && 27 == e.which)return 27 == e.which && n.find(a).trigger("focus"), o.trigger("click");
                var r = " li:not(.divider):visible a", l = n.find('[role="menu"]' + r + ', [role="listbox"]' + r);
                if (l.length) {
                    var c = l.index(e.target);
                    38 == e.which && c > 0 && c--, 40 == e.which && c < l.length - 1 && c++, ~c || (c = 0), l.eq(c).trigger("focus")
                }
            }
        }
    };
    var r = t.fn.dropdown;
    t.fn.dropdown = o, t.fn.dropdown.Constructor = s, t.fn.dropdown.noConflict = function () {
        return t.fn.dropdown = r, this
    }, t(document).on("click.bs.dropdown.data-api", e).on("click.bs.dropdown.data-api", ".dropdown form", function (t) {
        t.stopPropagation()
    }).on("click.bs.dropdown.data-api", a, s.prototype.toggle).on("keydown.bs.dropdown.data-api", a, s.prototype.keydown).on("keydown.bs.dropdown.data-api", '[role="menu"]', s.prototype.keydown).on("keydown.bs.dropdown.data-api", '[role="listbox"]', s.prototype.keydown)
}(jQuery), +function (t) {
    "use strict";
    function e(e, o) {
        return this.each(function () {
            var n = t(this), a = n.data("bs.modal"), s = t.extend({}, i.DEFAULTS, n.data(), "object" == typeof e && e);
            a || n.data("bs.modal", a = new i(this, s)), "string" == typeof e ? a[e](o) : s.show && a.show(o)
        })
    }

    var i = function (e, i) {
        this.options = i, this.$body = t(document.body), this.$element = t(e), this.$backdrop = this.isShown = null, this.scrollbarWidth = 0, this.options.remote && this.$element.find(".modal-content").load(this.options.remote, t.proxy(function () {
            this.$element.trigger("loaded.bs.modal")
        }, this))
    };
    i.VERSION = "3.3.2", i.TRANSITION_DURATION = 300, i.BACKDROP_TRANSITION_DURATION = 150, i.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    }, i.prototype.toggle = function (t) {
        return this.isShown ? this.hide() : this.show(t)
    }, i.prototype.show = function (e) {
        var o = this, n = t.Event("show.bs.modal", {relatedTarget: e});
        this.$element.trigger(n), this.isShown || n.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', t.proxy(this.hide, this)), this.backdrop(function () {
            var n = t.support.transition && o.$element.hasClass("fade");
            o.$element.parent().length || o.$element.appendTo(o.$body), o.$element.show().scrollTop(0), o.options.backdrop && o.adjustBackdrop(), o.adjustDialog(), n && o.$element[0].offsetWidth, o.$element.addClass("in").attr("aria-hidden", !1), o.enforceFocus();
            var a = t.Event("shown.bs.modal", {relatedTarget: e});
            n ? o.$element.find(".modal-dialog").one("bsTransitionEnd", function () {
                o.$element.trigger("focus").trigger(a)
            }).emulateTransitionEnd(i.TRANSITION_DURATION) : o.$element.trigger("focus").trigger(a)
        }))
    }, i.prototype.hide = function (e) {
        e && e.preventDefault(), e = t.Event("hide.bs.modal"), this.$element.trigger(e), this.isShown && !e.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), t(document).off("focusin.bs.modal"), this.$element.removeClass("in").attr("aria-hidden", !0).off("click.dismiss.bs.modal"), t.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", t.proxy(this.hideModal, this)).emulateTransitionEnd(i.TRANSITION_DURATION) : this.hideModal())
    }, i.prototype.enforceFocus = function () {
        t(document).off("focusin.bs.modal").on("focusin.bs.modal", t.proxy(function (t) {
            this.$element[0] === t.target || this.$element.has(t.target).length || this.$element.trigger("focus")
        }, this))
    }, i.prototype.escape = function () {
        this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", t.proxy(function (t) {
            27 == t.which && this.hide()
        }, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
    }, i.prototype.resize = function () {
        this.isShown ? t(window).on("resize.bs.modal", t.proxy(this.handleUpdate, this)) : t(window).off("resize.bs.modal")
    }, i.prototype.hideModal = function () {
        var t = this;
        this.$element.hide(), this.backdrop(function () {
            t.$body.removeClass("modal-open"), t.resetAdjustments(), t.resetScrollbar(), t.$element.trigger("hidden.bs.modal")
        })
    }, i.prototype.removeBackdrop = function () {
        this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
    }, i.prototype.backdrop = function (e) {
        var o = this, n = this.$element.hasClass("fade") ? "fade" : "";
        if (this.isShown && this.options.backdrop) {
            var a = t.support.transition && n;
            if (this.$backdrop = t('<div class="modal-backdrop ' + n + '" />').prependTo(this.$element).on("click.dismiss.bs.modal", t.proxy(function (t) {
                    t.target === t.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus.call(this.$element[0]) : this.hide.call(this))
                }, this)), a && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), !e)return;
            a ? this.$backdrop.one("bsTransitionEnd", e).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION) : e()
        } else if (!this.isShown && this.$backdrop) {
            this.$backdrop.removeClass("in");
            var s = function () {
                o.removeBackdrop(), e && e()
            };
            t.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", s).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION) : s()
        } else e && e()
    }, i.prototype.handleUpdate = function () {
        this.options.backdrop && this.adjustBackdrop(), this.adjustDialog()
    }, i.prototype.adjustBackdrop = function () {
        this.$backdrop.css("height", 0).css("height", this.$element[0].scrollHeight)
    }, i.prototype.adjustDialog = function () {
        var t = this.$element[0].scrollHeight > document.documentElement.clientHeight;
        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && t ? this.scrollbarWidth : "",
            paddingRight: this.bodyIsOverflowing && !t ? this.scrollbarWidth : ""
        })
    }, i.prototype.resetAdjustments = function () {
        this.$element.css({paddingLeft: "", paddingRight: ""})
    }, i.prototype.checkScrollbar = function () {
        this.bodyIsOverflowing = document.body.scrollHeight > document.documentElement.clientHeight, this.scrollbarWidth = this.measureScrollbar()
    }, i.prototype.setScrollbar = function () {
        var t = parseInt(this.$body.css("padding-right") || 0, 10);
        this.bodyIsOverflowing && this.$body.css("padding-right", t + this.scrollbarWidth)
    }, i.prototype.resetScrollbar = function () {
        this.$body.css("padding-right", "")
    }, i.prototype.measureScrollbar = function () {
        var t = document.createElement("div");
        t.className = "modal-scrollbar-measure", this.$body.append(t);
        var e = t.offsetWidth - t.clientWidth;
        return this.$body[0].removeChild(t), e
    };
    var o = t.fn.modal;
    t.fn.modal = e, t.fn.modal.Constructor = i, t.fn.modal.noConflict = function () {
        return t.fn.modal = o, this
    }, t(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function (i) {
        var o = t(this), n = o.attr("href"), a = t(o.attr("data-target") || n && n.replace(/.*(?=#[^\s]+$)/, "")), s = a.data("bs.modal") ? "toggle" : t.extend({remote: !/#/.test(n) && n}, a.data(), o.data());
        o.is("a") && i.preventDefault(), a.one("show.bs.modal", function (t) {
            t.isDefaultPrevented() || a.one("hidden.bs.modal", function () {
                o.is(":visible") && o.trigger("focus")
            })
        }), e.call(a, s, this)
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.tooltip"), a = "object" == typeof e && e;
            (n || "destroy" != e) && (n || o.data("bs.tooltip", n = new i(this, a)), "string" == typeof e && n[e]())
        })
    }

    var i = function (t, e) {
        this.type = this.options = this.enabled = this.timeout = this.hoverState = this.$element = null, this.init("tooltip", t, e)
    };
    i.VERSION = "3.3.2", i.TRANSITION_DURATION = 150, i.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1,
        viewport: {selector: "body", padding: 0}
    }, i.prototype.init = function (e, i, o) {
        this.enabled = !0, this.type = e, this.$element = t(i), this.options = this.getOptions(o), this.$viewport = this.options.viewport && t(this.options.viewport.selector || this.options.viewport);
        for (var n = this.options.trigger.split(" "), a = n.length; a--;) {
            var s = n[a];
            if ("click" == s)this.$element.on("click." + this.type, this.options.selector, t.proxy(this.toggle, this)); else if ("manual" != s) {
                var r = "hover" == s ? "mouseenter" : "focusin", l = "hover" == s ? "mouseleave" : "focusout";
                this.$element.on(r + "." + this.type, this.options.selector, t.proxy(this.enter, this)), this.$element.on(l + "." + this.type, this.options.selector, t.proxy(this.leave, this))
            }
        }
        this.options.selector ? this._options = t.extend({}, this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    }, i.prototype.getDefaults = function () {
        return i.DEFAULTS
    }, i.prototype.getOptions = function (e) {
        return e = t.extend({}, this.getDefaults(), this.$element.data(), e), e.delay && "number" == typeof e.delay && (e.delay = {
            show: e.delay,
            hide: e.delay
        }), e
    }, i.prototype.getDelegateOptions = function () {
        var e = {}, i = this.getDefaults();
        return this._options && t.each(this._options, function (t, o) {
            i[t] != o && (e[t] = o)
        }), e
    }, i.prototype.enter = function (e) {
        var i = e instanceof this.constructor ? e : t(e.currentTarget).data("bs." + this.type);
        return i && i.$tip && i.$tip.is(":visible") ? void(i.hoverState = "in") : (i || (i = new this.constructor(e.currentTarget, this.getDelegateOptions()), t(e.currentTarget).data("bs." + this.type, i)), clearTimeout(i.timeout), i.hoverState = "in", i.options.delay && i.options.delay.show ? void(i.timeout = setTimeout(function () {
            "in" == i.hoverState && i.show()
        }, i.options.delay.show)) : i.show())
    }, i.prototype.leave = function (e) {
        var i = e instanceof this.constructor ? e : t(e.currentTarget).data("bs." + this.type);
        return i || (i = new this.constructor(e.currentTarget, this.getDelegateOptions()), t(e.currentTarget).data("bs." + this.type, i)), clearTimeout(i.timeout), i.hoverState = "out", i.options.delay && i.options.delay.hide ? void(i.timeout = setTimeout(function () {
            "out" == i.hoverState && i.hide()
        }, i.options.delay.hide)) : i.hide()
    }, i.prototype.show = function () {
        var e = t.Event("show.bs." + this.type);
        if (this.hasContent() && this.enabled) {
            this.$element.trigger(e);
            var o = t.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]);
            if (e.isDefaultPrevented() || !o)return;
            var n = this, a = this.tip(), s = this.getUID(this.type);
            this.setContent(), a.attr("id", s), this.$element.attr("aria-describedby", s), this.options.animation && a.addClass("fade");
            var r = "function" == typeof this.options.placement ? this.options.placement.call(this, a[0], this.$element[0]) : this.options.placement, l = /\s?auto?\s?/i, c = l.test(r);
            c && (r = r.replace(l, "") || "top"), a.detach().css({
                top: 0,
                left: 0,
                display: "block"
            }).addClass(r).data("bs." + this.type, this), this.options.container ? a.appendTo(this.options.container) : a.insertAfter(this.$element);
            var h = this.getPosition(), d = a[0].offsetWidth, p = a[0].offsetHeight;
            if (c) {
                var f = r, u = this.options.container ? t(this.options.container) : this.$element.parent(), g = this.getPosition(u);
                r = "bottom" == r && h.bottom + p > g.bottom ? "top" : "top" == r && h.top - p < g.top ? "bottom" : "right" == r && h.right + d > g.width ? "left" : "left" == r && h.left - d < g.left ? "right" : r, a.removeClass(f).addClass(r)
            }
            var m = this.getCalculatedOffset(r, h, d, p);
            this.applyPlacement(m, r);
            var v = function () {
                var t = n.hoverState;
                n.$element.trigger("shown.bs." + n.type), n.hoverState = null, "out" == t && n.leave(n)
            };
            t.support.transition && this.$tip.hasClass("fade") ? a.one("bsTransitionEnd", v).emulateTransitionEnd(i.TRANSITION_DURATION) : v()
        }
    }, i.prototype.applyPlacement = function (e, i) {
        var o = this.tip(), n = o[0].offsetWidth, a = o[0].offsetHeight, s = parseInt(o.css("margin-top"), 10), r = parseInt(o.css("margin-left"), 10);
        isNaN(s) && (s = 0), isNaN(r) && (r = 0), e.top = e.top + s, e.left = e.left + r, t.offset.setOffset(o[0], t.extend({
            using: function (t) {
                o.css({top: Math.round(t.top), left: Math.round(t.left)})
            }
        }, e), 0), o.addClass("in");
        var l = o[0].offsetWidth, c = o[0].offsetHeight;
        "top" == i && c != a && (e.top = e.top + a - c);
        var h = this.getViewportAdjustedDelta(i, e, l, c);
        h.left ? e.left += h.left : e.top += h.top;
        var d = /top|bottom/.test(i), p = d ? 2 * h.left - n + l : 2 * h.top - a + c, f = d ? "offsetWidth" : "offsetHeight";
        o.offset(e), this.replaceArrow(p, o[0][f], d)
    }, i.prototype.replaceArrow = function (t, e, i) {
        this.arrow().css(i ? "left" : "top", 50 * (1 - t / e) + "%").css(i ? "top" : "left", "")
    }, i.prototype.setContent = function () {
        var t = this.tip(), e = this.getTitle();
        t.find(".tooltip-inner")[this.options.html ? "html" : "text"](e), t.removeClass("fade in top bottom left right")
    }, i.prototype.hide = function (e) {
        function o() {
            "in" != n.hoverState && a.detach(), n.$element.removeAttr("aria-describedby").trigger("hidden.bs." + n.type), e && e()
        }

        var n = this, a = this.tip(), s = t.Event("hide.bs." + this.type);
        return this.$element.trigger(s), s.isDefaultPrevented() ? void 0 : (a.removeClass("in"), t.support.transition && this.$tip.hasClass("fade") ? a.one("bsTransitionEnd", o).emulateTransitionEnd(i.TRANSITION_DURATION) : o(), this.hoverState = null, this)
    }, i.prototype.fixTitle = function () {
        var t = this.$element;
        (t.attr("title") || "string" != typeof t.attr("data-original-title")) && t.attr("data-original-title", t.attr("title") || "").attr("title", "")
    }, i.prototype.hasContent = function () {
        return this.getTitle()
    }, i.prototype.getPosition = function (e) {
        e = e || this.$element;
        var i = e[0], o = "BODY" == i.tagName, n = i.getBoundingClientRect();
        null == n.width && (n = t.extend({}, n, {width: n.right - n.left, height: n.bottom - n.top}));
        var a = o ? {
            top: 0,
            left: 0
        } : e.offset(), s = {scroll: o ? document.documentElement.scrollTop || document.body.scrollTop : e.scrollTop()}, r = o ? {
            width: t(window).width(),
            height: t(window).height()
        } : null;
        return t.extend({}, n, s, r, a)
    }, i.prototype.getCalculatedOffset = function (t, e, i, o) {
        return "bottom" == t ? {
            top: e.top + e.height,
            left: e.left + e.width / 2 - i / 2
        } : "top" == t ? {
            top: e.top - o,
            left: e.left + e.width / 2 - i / 2
        } : "left" == t ? {top: e.top + e.height / 2 - o / 2, left: e.left - i} : {
            top: e.top + e.height / 2 - o / 2,
            left: e.left + e.width
        }
    }, i.prototype.getViewportAdjustedDelta = function (t, e, i, o) {
        var n = {top: 0, left: 0};
        if (!this.$viewport)return n;
        var a = this.options.viewport && this.options.viewport.padding || 0, s = this.getPosition(this.$viewport);
        if (/right|left/.test(t)) {
            var r = e.top - a - s.scroll, l = e.top + a - s.scroll + o;
            r < s.top ? n.top = s.top - r : l > s.top + s.height && (n.top = s.top + s.height - l)
        } else {
            var c = e.left - a, h = e.left + a + i;
            c < s.left ? n.left = s.left - c : h > s.width && (n.left = s.left + s.width - h)
        }
        return n
    }, i.prototype.getTitle = function () {
        var t, e = this.$element, i = this.options;
        return t = e.attr("data-original-title") || ("function" == typeof i.title ? i.title.call(e[0]) : i.title)
    }, i.prototype.getUID = function (t) {
        do t += ~~(1e6 * Math.random()); while (document.getElementById(t));
        return t
    }, i.prototype.tip = function () {
        return this.$tip = this.$tip || t(this.options.template)
    }, i.prototype.arrow = function () {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    }, i.prototype.enable = function () {
        this.enabled = !0
    }, i.prototype.disable = function () {
        this.enabled = !1
    }, i.prototype.toggleEnabled = function () {
        this.enabled = !this.enabled
    }, i.prototype.toggle = function (e) {
        var i = this;
        e && (i = t(e.currentTarget).data("bs." + this.type), i || (i = new this.constructor(e.currentTarget, this.getDelegateOptions()), t(e.currentTarget).data("bs." + this.type, i))), i.tip().hasClass("in") ? i.leave(i) : i.enter(i)
    }, i.prototype.destroy = function () {
        var t = this;
        clearTimeout(this.timeout), this.hide(function () {
            t.$element.off("." + t.type).removeData("bs." + t.type)
        })
    };
    var o = t.fn.tooltip;
    t.fn.tooltip = e, t.fn.tooltip.Constructor = i, t.fn.tooltip.noConflict = function () {
        return t.fn.tooltip = o, this
    }
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.popover"), a = "object" == typeof e && e;
            (n || "destroy" != e) && (n || o.data("bs.popover", n = new i(this, a)), "string" == typeof e && n[e]())
        })
    }

    var i = function (t, e) {
        this.init("popover", t, e)
    };
    if (!t.fn.tooltip)throw new Error("Popover requires tooltip.js");
    i.VERSION = "3.3.2", i.DEFAULTS = t.extend({}, t.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    }), i.prototype = t.extend({}, t.fn.tooltip.Constructor.prototype), i.prototype.constructor = i, i.prototype.getDefaults = function () {
        return i.DEFAULTS
    }, i.prototype.setContent = function () {
        var t = this.tip(), e = this.getTitle(), i = this.getContent();
        t.find(".popover-title")[this.options.html ? "html" : "text"](e), t.find(".popover-content").children().detach().end()[this.options.html ? "string" == typeof i ? "html" : "append" : "text"](i), t.removeClass("fade top bottom left right in"), t.find(".popover-title").html() || t.find(".popover-title").hide()
    }, i.prototype.hasContent = function () {
        return this.getTitle() || this.getContent()
    }, i.prototype.getContent = function () {
        var t = this.$element, e = this.options;
        return t.attr("data-content") || ("function" == typeof e.content ? e.content.call(t[0]) : e.content)
    }, i.prototype.arrow = function () {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    }, i.prototype.tip = function () {
        return this.$tip || (this.$tip = t(this.options.template)), this.$tip
    };
    var o = t.fn.popover;
    t.fn.popover = e, t.fn.popover.Constructor = i, t.fn.popover.noConflict = function () {
        return t.fn.popover = o, this
    }
}(jQuery), +function (t) {
    "use strict";
    function e(i, o) {
        var n = t.proxy(this.process, this);
        this.$body = t("body"), this.$scrollElement = t(t(i).is("body") ? window : i), this.options = t.extend({}, e.DEFAULTS, o), this.selector = (this.options.target || "") + " .nav li > a", this.offsets = [], this.targets = [], this.activeTarget = null, this.scrollHeight = 0, this.$scrollElement.on("scroll.bs.scrollspy", n), this.refresh(), this.process()
    }

    function i(i) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.scrollspy"), a = "object" == typeof i && i;
            n || o.data("bs.scrollspy", n = new e(this, a)), "string" == typeof i && n[i]()
        })
    }

    e.VERSION = "3.3.2", e.DEFAULTS = {offset: 10}, e.prototype.getScrollHeight = function () {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    }, e.prototype.refresh = function () {
        var e = "offset", i = 0;
        t.isWindow(this.$scrollElement[0]) || (e = "position", i = this.$scrollElement.scrollTop()), this.offsets = [], this.targets = [], this.scrollHeight = this.getScrollHeight();
        var o = this;
        this.$body.find(this.selector).map(function () {
            var o = t(this), n = o.data("target") || o.attr("href"), a = /^#./.test(n) && t(n);
            return a && a.length && a.is(":visible") && [[a[e]().top + i, n]] || null
        }).sort(function (t, e) {
            return t[0] - e[0]
        }).each(function () {
            o.offsets.push(this[0]), o.targets.push(this[1])
        })
    }, e.prototype.process = function () {
        var t, e = this.$scrollElement.scrollTop() + this.options.offset, i = this.getScrollHeight(), o = this.options.offset + i - this.$scrollElement.height(), n = this.offsets, a = this.targets, s = this.activeTarget;
        if (this.scrollHeight != i && this.refresh(), e >= o)return s != (t = a[a.length - 1]) && this.activate(t);
        if (s && e < n[0])return this.activeTarget = null, this.clear();
        for (t = n.length; t--;)s != a[t] && e >= n[t] && (!n[t + 1] || e <= n[t + 1]) && this.activate(a[t])
    }, e.prototype.activate = function (e) {
        this.activeTarget = e, this.clear();
        var i = this.selector + '[data-target="' + e + '"],' + this.selector + '[href="' + e + '"]', o = t(i).parents("li").addClass("active");
        o.parent(".dropdown-menu").length && (o = o.closest("li.dropdown").addClass("active")), o.trigger("activate.bs.scrollspy")
    }, e.prototype.clear = function () {
        t(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
    };
    var o = t.fn.scrollspy;
    t.fn.scrollspy = i, t.fn.scrollspy.Constructor = e, t.fn.scrollspy.noConflict = function () {
        return t.fn.scrollspy = o, this
    }, t(window).on("load.bs.scrollspy.data-api", function () {
        t('[data-spy="scroll"]').each(function () {
            var e = t(this);
            i.call(e, e.data())
        })
    })
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.tab");
            n || o.data("bs.tab", n = new i(this)), "string" == typeof e && n[e]()
        })
    }

    var i = function (e) {
        this.element = t(e)
    };
    i.VERSION = "3.3.2", i.TRANSITION_DURATION = 150, i.prototype.show = function () {
        var e = this.element, i = e.closest("ul:not(.dropdown-menu)"), o = e.data("target");
        if (o || (o = e.attr("href"), o = o && o.replace(/.*(?=#[^\s]*$)/, "")), !e.parent("li").hasClass("active")) {
            var n = i.find(".active:last a"), a = t.Event("hide.bs.tab", {relatedTarget: e[0]}), s = t.Event("show.bs.tab", {relatedTarget: n[0]});
            if (n.trigger(a), e.trigger(s), !s.isDefaultPrevented() && !a.isDefaultPrevented()) {
                var r = t(o);
                this.activate(e.closest("li"), i), this.activate(r, r.parent(), function () {
                    n.trigger({type: "hidden.bs.tab", relatedTarget: e[0]}), e.trigger({
                        type: "shown.bs.tab",
                        relatedTarget: n[0]
                    })
                })
            }
        }
    }, i.prototype.activate = function (e, o, n) {
        function a() {
            s.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1), e.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0), r ? (e[0].offsetWidth, e.addClass("in")) : e.removeClass("fade"), e.parent(".dropdown-menu") && e.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0), n && n()
        }

        var s = o.find("> .active"), r = n && t.support.transition && (s.length && s.hasClass("fade") || !!o.find("> .fade").length);
        s.length && r ? s.one("bsTransitionEnd", a).emulateTransitionEnd(i.TRANSITION_DURATION) : a(), s.removeClass("in")
    };
    var o = t.fn.tab;
    t.fn.tab = e, t.fn.tab.Constructor = i, t.fn.tab.noConflict = function () {
        return t.fn.tab = o, this
    };
    var n = function (i) {
        i.preventDefault(), e.call(t(this), "show")
    };
    t(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', n).on("click.bs.tab.data-api", '[data-toggle="pill"]', n)
}(jQuery), +function (t) {
    "use strict";
    function e(e) {
        return this.each(function () {
            var o = t(this), n = o.data("bs.affix"), a = "object" == typeof e && e;
            n || o.data("bs.affix", n = new i(this, a)), "string" == typeof e && n[e]()
        })
    }

    var i = function (e, o) {
        this.options = t.extend({}, i.DEFAULTS, o), this.$target = t(this.options.target).on("scroll.bs.affix.data-api", t.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", t.proxy(this.checkPositionWithEventLoop, this)), this.$element = t(e), this.affixed = this.unpin = this.pinnedOffset = null, this.checkPosition()
    };
    i.VERSION = "3.3.2", i.RESET = "affix affix-top affix-bottom", i.DEFAULTS = {
        offset: 0,
        target: window
    }, i.prototype.getState = function (t, e, i, o) {
        var n = this.$target.scrollTop(), a = this.$element.offset(), s = this.$target.height();
        if (null != i && "top" == this.affixed)return i > n ? "top" : !1;
        if ("bottom" == this.affixed)return null != i ? n + this.unpin <= a.top ? !1 : "bottom" : t - o >= n + s ? !1 : "bottom";
        var r = null == this.affixed, l = r ? n : a.top, c = r ? s : e;
        return null != i && i >= n ? "top" : null != o && l + c >= t - o ? "bottom" : !1
    }, i.prototype.getPinnedOffset = function () {
        if (this.pinnedOffset)return this.pinnedOffset;
        this.$element.removeClass(i.RESET).addClass("affix");
        var t = this.$target.scrollTop(), e = this.$element.offset();
        return this.pinnedOffset = e.top - t
    }, i.prototype.checkPositionWithEventLoop = function () {
        setTimeout(t.proxy(this.checkPosition, this), 1)
    }, i.prototype.checkPosition = function () {
        if (this.$element.is(":visible")) {
            var e = this.$element.height(), o = this.options.offset, n = o.top, a = o.bottom, s = t("body").height();
            "object" != typeof o && (a = n = o), "function" == typeof n && (n = o.top(this.$element)), "function" == typeof a && (a = o.bottom(this.$element));
            var r = this.getState(s, e, n, a);
            if (this.affixed != r) {
                null != this.unpin && this.$element.css("top", "");
                var l = "affix" + (r ? "-" + r : ""), c = t.Event(l + ".bs.affix");
                if (this.$element.trigger(c), c.isDefaultPrevented())return;
                this.affixed = r, this.unpin = "bottom" == r ? this.getPinnedOffset() : null, this.$element.removeClass(i.RESET).addClass(l).trigger(l.replace("affix", "affixed") + ".bs.affix")
            }
            "bottom" == r && this.$element.offset({top: s - e - a})
        }
    };
    var o = t.fn.affix;
    t.fn.affix = e, t.fn.affix.Constructor = i, t.fn.affix.noConflict = function () {
        return t.fn.affix = o, this
    }, t(window).on("load", function () {
        t('[data-spy="affix"]').each(function () {
            var i = t(this), o = i.data();
            o.offset = o.offset || {}, null != o.offsetBottom && (o.offset.bottom = o.offsetBottom), null != o.offsetTop && (o.offset.top = o.offsetTop), e.call(i, o)
        })
    })
}(jQuery), function (t, e, i, o) {
    var n = i("html"), a = i(t), s = i(e), r = i.fancybox = function () {
        r.open.apply(this, arguments)
    }, l = navigator.userAgent.match(/msie/i), c = null, h = e.createTouch !== o, d = function (t) {
        return t && t.hasOwnProperty && t instanceof i
    }, p = function (t) {
        return t && "string" === i.type(t)
    }, f = function (t) {
        return p(t) && 0 < t.indexOf("%")
    }, u = function (t, e) {
        var i = parseInt(t, 10) || 0;
        return e && f(t) && (i *= r.getViewport()[e] / 100), Math.ceil(i)
    }, g = function (t, e) {
        return u(t, e) + "px"
    };
    i.extend(r, {
        version: "2.1.5",
        defaults: {
            padding: 15,
            margin: 20,
            width: 800,
            height: 600,
            minWidth: 100,
            minHeight: 100,
            maxWidth: 9999,
            maxHeight: 9999,
            pixelRatio: 1,
            autoSize: !0,
            autoHeight: !1,
            autoWidth: !1,
            autoResize: !0,
            autoCenter: !h,
            fitToView: !0,
            aspectRatio: !1,
            topRatio: .5,
            leftRatio: .5,
            scrolling: "auto",
            wrapCSS: "",
            arrows: !0,
            closeBtn: !0,
            closeClick: !1,
            nextClick: !1,
            mouseWheel: !0,
            autoPlay: !1,
            playSpeed: 3e3,
            preload: 3,
            modal: !1,
            loop: !0,
            ajax: {dataType: "html", headers: {"X-fancyBox": !0}},
            iframe: {scrolling: "auto", preload: !0},
            swf: {wmode: "transparent", allowfullscreen: "true", allowscriptaccess: "always"},
            keys: {
                next: {13: "left", 34: "up", 39: "left", 40: "up"},
                prev: {8: "right", 33: "down", 37: "right", 38: "down"},
                close: [27],
                play: [32],
                toggle: [70]
            },
            direction: {next: "left", prev: "right"},
            scrollOutside: !0,
            index: 0,
            type: null,
            href: null,
            content: null,
            title: null,
            tpl: {
                wrap: '<div class="fancybox-wrap" tabIndex="-1"><div class="fancybox-skin"><div class="fancybox-outer"><div class="fancybox-inner"></div></div></div></div>',
                image: '<img class="fancybox-image" src="{href}" alt="" />',
                iframe: '<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen' + (l ? ' allowtransparency="true"' : "") + "></iframe>",
                error: '<p class="fancybox-error">The requested content cannot be loaded.<br/>Please try again later.</p>',
                closeBtn: '<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>',
                next: '<a title="Next" class="fancybox-nav fancybox-next" href="javascript:;"><span></span></a>',
                prev: '<a title="Previous" class="fancybox-nav fancybox-prev" href="javascript:;"><span></span></a>'
            },
            openEffect: "fade",
            openSpeed: 250,
            openEasing: "swing",
            openOpacity: !0,
            openMethod: "zoomIn",
            closeEffect: "fade",
            closeSpeed: 250,
            closeEasing: "swing",
            closeOpacity: !0,
            closeMethod: "zoomOut",
            nextEffect: "elastic",
            nextSpeed: 250,
            nextEasing: "swing",
            nextMethod: "changeIn",
            prevEffect: "elastic",
            prevSpeed: 250,
            prevEasing: "swing",
            prevMethod: "changeOut",
            helpers: {overlay: !0, title: !0},
            onCancel: i.noop,
            beforeLoad: i.noop,
            afterLoad: i.noop,
            beforeShow: i.noop,
            afterShow: i.noop,
            beforeChange: i.noop,
            beforeClose: i.noop,
            afterClose: i.noop
        },
        group: {},
        opts: {},
        previous: null,
        coming: null,
        current: null,
        isActive: !1,
        isOpen: !1,
        isOpened: !1,
        wrap: null,
        skin: null,
        outer: null,
        inner: null,
        player: {timer: null, isActive: !1},
        ajaxLoad: null,
        imgPreload: null,
        transitions: {},
        helpers: {},
        open: function (t, e) {
            return t && (i.isPlainObject(e) || (e = {}), !1 !== r.close(!0)) ? (i.isArray(t) || (t = d(t) ? i(t).get() : [t]), i.each(t, function (n, a) {
                var s, l, c, h, f, u = {};
                "object" === i.type(a) && (a.nodeType && (a = i(a)), d(a) ? (u = {
                    href: a.data("fancybox-href") || a.attr("href"),
                    title: a.data("fancybox-title") || a.attr("title"),
                    isDom: !0,
                    element: a
                }, i.metadata && i.extend(!0, u, a.metadata())) : u = a), s = e.href || u.href || (p(a) ? a : null), l = e.title !== o ? e.title : u.title || "", h = (c = e.content || u.content) ? "html" : e.type || u.type, !h && u.isDom && (h = a.data("fancybox-type"), h || (h = (h = a.prop("class").match(/fancybox\.(\w+)/)) ? h[1] : null)), p(s) && (h || (r.isImage(s) ? h = "image" : r.isSWF(s) ? h = "swf" : "#" === s.charAt(0) ? h = "inline" : p(a) && (h = "html", c = a)), "ajax" === h && (f = s.split(/\s+/, 2), s = f.shift(), f = f.shift())), c || ("inline" === h ? s ? c = i(p(s) ? s.replace(/.*(?=#[^\s]+$)/, "") : s) : u.isDom && (c = a) : "html" === h ? c = s : !h && !s && u.isDom && (h = "inline", c = a)), i.extend(u, {
                    href: s,
                    type: h,
                    content: c,
                    title: l,
                    selector: f
                }), t[n] = u
            }), r.opts = i.extend(!0, {}, r.defaults, e), e.keys !== o && (r.opts.keys = e.keys ? i.extend({}, r.defaults.keys, e.keys) : !1), r.group = t, r._start(r.opts.index)) : void 0
        },
        cancel: function () {
            var t = r.coming;
            t && !1 !== r.trigger("onCancel") && (r.hideLoading(), r.ajaxLoad && r.ajaxLoad.abort(), r.ajaxLoad = null, r.imgPreload && (r.imgPreload.onload = r.imgPreload.onerror = null), t.wrap && t.wrap.stop(!0, !0).trigger("onReset").remove(), r.coming = null, r.current || r._afterZoomOut(t))
        },
        close: function (t) {
            r.cancel(), !1 !== r.trigger("beforeClose") && (r.unbindEvents(), r.isActive && (r.isOpen && !0 !== t ? (r.isOpen = r.isOpened = !1, r.isClosing = !0, i(".fancybox-item, .fancybox-nav").remove(), r.wrap.stop(!0, !0).removeClass("fancybox-opened"), r.transitions[r.current.closeMethod]()) : (i(".fancybox-wrap").stop(!0).trigger("onReset").remove(), r._afterZoomOut())))
        },
        play: function (t) {
            var e = function () {
                clearTimeout(r.player.timer)
            }, i = function () {
                e(), r.current && r.player.isActive && (r.player.timer = setTimeout(r.next, r.current.playSpeed))
            }, o = function () {
                e(), s.unbind(".player"), r.player.isActive = !1, r.trigger("onPlayEnd")
            };
            !0 === t || !r.player.isActive && !1 !== t ? r.current && (r.current.loop || r.current.index < r.group.length - 1) && (r.player.isActive = !0, s.bind({
                "onCancel.player beforeClose.player": o,
                "onUpdate.player": i,
                "beforeLoad.player": e
            }), i(), r.trigger("onPlayStart")) : o()
        },
        next: function (t) {
            var e = r.current;
            e && (p(t) || (t = e.direction.next), r.jumpto(e.index + 1, t, "next"))
        },
        prev: function (t) {
            var e = r.current;
            e && (p(t) || (t = e.direction.prev), r.jumpto(e.index - 1, t, "prev"))
        },
        jumpto: function (t, e, i) {
            var n = r.current;
            n && (t = u(t), r.direction = e || n.direction[t >= n.index ? "next" : "prev"], r.router = i || "jumpto", n.loop && (0 > t && (t = n.group.length + t % n.group.length), t %= n.group.length), n.group[t] !== o && (r.cancel(), r._start(t)))
        },
        reposition: function (t, e) {
            var o, n = r.current, a = n ? n.wrap : null;
            a && (o = r._getPosition(e), t && "scroll" === t.type ? (delete o.position, a.stop(!0, !0).animate(o, 200)) : (a.css(o), n.pos = i.extend({}, n.dim, o)))
        },
        update: function (t) {
            var e = t && t.type, i = !e || "orientationchange" === e;
            i && (clearTimeout(c), c = null), r.isOpen && !c && (c = setTimeout(function () {
                var o = r.current;
                o && !r.isClosing && (r.wrap.removeClass("fancybox-tmp"), (i || "load" === e || "resize" === e && o.autoResize) && r._setDimension(), "scroll" === e && o.canShrink || r.reposition(t), r.trigger("onUpdate"), c = null)
            }, i && !h ? 0 : 300))
        },
        toggle: function (t) {
            r.isOpen && (r.current.fitToView = "boolean" === i.type(t) ? t : !r.current.fitToView, h && (r.wrap.removeAttr("style").addClass("fancybox-tmp"), r.trigger("onUpdate")), r.update())
        },
        hideLoading: function () {
            s.unbind(".loading"), i("#fancybox-loading").remove()
        },
        showLoading: function () {
            var t, e;
            r.hideLoading(), t = i('<div id="fancybox-loading"><div></div></div>').click(r.cancel).appendTo("body"), s.bind("keydown.loading", function (t) {
                27 === (t.which || t.keyCode) && (t.preventDefault(), r.cancel())
            }), r.defaults.fixed || (e = r.getViewport(), t.css({
                position: "absolute",
                top: .5 * e.h + e.y,
                left: .5 * e.w + e.x
            }))
        },
        getViewport: function () {
            var e = r.current && r.current.locked || !1, i = {x: a.scrollLeft(), y: a.scrollTop()};
            return e ? (i.w = e[0].clientWidth, i.h = e[0].clientHeight) : (i.w = h && t.innerWidth ? t.innerWidth : a.width(), i.h = h && t.innerHeight ? t.innerHeight : a.height()), i
        },
        unbindEvents: function () {
            r.wrap && d(r.wrap) && r.wrap.unbind(".fb"), s.unbind(".fb"), a.unbind(".fb")
        },
        bindEvents: function () {
            var t, e = r.current;
            e && (a.bind("orientationchange.fb" + (h ? "" : " resize.fb") + (e.autoCenter && !e.locked ? " scroll.fb" : ""), r.update), (t = e.keys) && s.bind("keydown.fb", function (n) {
                var a = n.which || n.keyCode, s = n.target || n.srcElement;
                return 27 === a && r.coming ? !1 : void!(n.ctrlKey || n.altKey || n.shiftKey || n.metaKey || s && (s.type || i(s).is("[contenteditable]")) || !i.each(t, function (t, s) {
                    return 1 < e.group.length && s[a] !== o ? (r[t](s[a]), n.preventDefault(), !1) : -1 < i.inArray(a, s) ? (r[t](), n.preventDefault(), !1) : void 0
                }))
            }), i.fn.mousewheel && e.mouseWheel && r.wrap.bind("mousewheel.fb", function (t, o, n, a) {
                for (var s = i(t.target || null), l = !1; s.length && !l && !s.is(".fancybox-skin") && !s.is(".fancybox-wrap");)l = s[0] && !(s[0].style.overflow && "hidden" === s[0].style.overflow) && (s[0].clientWidth && s[0].scrollWidth > s[0].clientWidth || s[0].clientHeight && s[0].scrollHeight > s[0].clientHeight), s = i(s).parent();
                0 !== o && !l && 1 < r.group.length && !e.canShrink && (a > 0 || n > 0 ? r.prev(a > 0 ? "down" : "left") : (0 > a || 0 > n) && r.next(0 > a ? "up" : "right"), t.preventDefault())
            }))
        },
        trigger: function (t, e) {
            var o, n = e || r.coming || r.current;
            if (n) {
                if (i.isFunction(n[t]) && (o = n[t].apply(n, Array.prototype.slice.call(arguments, 1))), !1 === o)return !1;
                n.helpers && i.each(n.helpers, function (e, o) {
                    o && r.helpers[e] && i.isFunction(r.helpers[e][t]) && r.helpers[e][t](i.extend(!0, {}, r.helpers[e].defaults, o), n)
                }), s.trigger(t)
            }
        },
        isImage: function (t) {
            return p(t) && t.match(/(^data:image\/.*,)|(\.(jp(e|g|eg)|gif|png|bmp|webp|svg)((\?|#).*)?$)/i)
        },
        isSWF: function (t) {
            return p(t) && t.match(/\.(swf)((\?|#).*)?$/i)
        },
        _start: function (t) {
            var e, o, n = {};
            if (t = u(t), e = r.group[t] || null, !e)return !1;
            if (n = i.extend(!0, {}, r.opts, e), e = n.margin, o = n.padding, "number" === i.type(e) && (n.margin = [e, e, e, e]), "number" === i.type(o) && (n.padding = [o, o, o, o]), n.modal && i.extend(!0, n, {
                    closeBtn: !1,
                    closeClick: !1,
                    nextClick: !1,
                    arrows: !1,
                    mouseWheel: !1,
                    keys: null,
                    helpers: {overlay: {closeClick: !1}}
                }), n.autoSize && (n.autoWidth = n.autoHeight = !0), "auto" === n.width && (n.autoWidth = !0), "auto" === n.height && (n.autoHeight = !0), n.group = r.group, n.index = t, r.coming = n, !1 === r.trigger("beforeLoad"))r.coming = null; else {
                if (o = n.type, e = n.href, !o)return r.coming = null, r.current && r.router && "jumpto" !== r.router ? (r.current.index = t, r[r.router](r.direction)) : !1;
                if (r.isActive = !0, ("image" === o || "swf" === o) && (n.autoHeight = n.autoWidth = !1, n.scrolling = "visible"), "image" === o && (n.aspectRatio = !0), "iframe" === o && h && (n.scrolling = "scroll"), n.wrap = i(n.tpl.wrap).addClass("fancybox-" + (h ? "mobile" : "desktop") + " fancybox-type-" + o + " fancybox-tmp " + n.wrapCSS).appendTo(n.parent || "body"), i.extend(n, {
                        skin: i(".fancybox-skin", n.wrap),
                        outer: i(".fancybox-outer", n.wrap),
                        inner: i(".fancybox-inner", n.wrap)
                    }), i.each(["Top", "Right", "Bottom", "Left"], function (t, e) {
                        n.skin.css("padding" + e, g(n.padding[t]))
                    }), r.trigger("onReady"), "inline" === o || "html" === o) {
                    if (!n.content || !n.content.length)return r._error("content")
                } else if (!e)return r._error("href");
                "image" === o ? r._loadImage() : "ajax" === o ? r._loadAjax() : "iframe" === o ? r._loadIframe() : r._afterLoad()
            }
        },
        _error: function (t) {
            i.extend(r.coming, {
                type: "html",
                autoWidth: !0,
                autoHeight: !0,
                minWidth: 0,
                minHeight: 0,
                scrolling: "no",
                hasError: t,
                content: r.coming.tpl.error
            }), r._afterLoad()
        },
        _loadImage: function () {
            var t = r.imgPreload = new Image;
            t.onload = function () {
                this.onload = this.onerror = null, r.coming.width = this.width / r.opts.pixelRatio, r.coming.height = this.height / r.opts.pixelRatio, r._afterLoad()
            }, t.onerror = function () {
                this.onload = this.onerror = null, r._error("image")
            }, t.src = r.coming.href, !0 !== t.complete && r.showLoading()
        },
        _loadAjax: function () {
            var t = r.coming;
            r.showLoading(), r.ajaxLoad = i.ajax(i.extend({}, t.ajax, {
                url: t.href, error: function (t, e) {
                    r.coming && "abort" !== e ? r._error("ajax", t) : r.hideLoading()
                }, success: function (e, i) {
                    "success" === i && (t.content = e, r._afterLoad())
                }
            }))
        },
        _loadIframe: function () {
            var t = r.coming, e = i(t.tpl.iframe.replace(/\{rnd\}/g, (new Date).getTime())).attr("scrolling", h ? "auto" : t.iframe.scrolling).attr("src", t.href);
            i(t.wrap).bind("onReset", function () {
                try {
                    i(this).find("iframe").hide().attr("src", "//about:blank").end().empty()
                } catch (t) {
                }
            }), t.iframe.preload && (r.showLoading(), e.one("load", function () {
                i(this).data("ready", 1), h || i(this).bind("load.fb", r.update), i(this).parents(".fancybox-wrap").width("100%").removeClass("fancybox-tmp").show(), r._afterLoad()
            })), t.content = e.appendTo(t.inner), t.iframe.preload || r._afterLoad()
        },
        _preloadImages: function () {
            var t, e, i = r.group, o = r.current, n = i.length, a = o.preload ? Math.min(o.preload, n - 1) : 0;
            for (e = 1; a >= e; e += 1)t = i[(o.index + e) % n], "image" === t.type && t.href && ((new Image).src = t.href)
        },
        _afterLoad: function () {
            var t, e, o, n, a, s = r.coming, l = r.current;
            if (r.hideLoading(), s && !1 !== r.isActive)if (!1 === r.trigger("afterLoad", s, l))s.wrap.stop(!0).trigger("onReset").remove(), r.coming = null; else {
                switch (l && (r.trigger("beforeChange", l), l.wrap.stop(!0).removeClass("fancybox-opened").find(".fancybox-item, .fancybox-nav").remove()), r.unbindEvents(), t = s.content, e = s.type, o = s.scrolling, i.extend(r, {
                    wrap: s.wrap,
                    skin: s.skin,
                    outer: s.outer,
                    inner: s.inner,
                    current: s,
                    previous: l
                }), n = s.href, e) {
                    case"inline":
                    case"ajax":
                    case"html":
                        s.selector ? t = i("<div>").html(t).find(s.selector) : d(t) && (t.data("fancybox-placeholder") || t.data("fancybox-placeholder", i('<div class="fancybox-placeholder"></div>').insertAfter(t).hide()), t = t.show().detach(), s.wrap.bind("onReset", function () {
                            i(this).find(t).length && t.hide().replaceAll(t.data("fancybox-placeholder")).data("fancybox-placeholder", !1)
                        }));
                        break;
                    case"image":
                        t = s.tpl.image.replace("{href}", n);
                        break;
                    case"swf":
                        t = '<object id="fancybox-swf" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="100%" height="100%"><param name="movie" value="' + n + '"></param>', a = "", i.each(s.swf, function (e, i) {
                            t += '<param name="' + e + '" value="' + i + '"></param>', a += " " + e + '="' + i + '"'
                        }), t += '<embed src="' + n + '" type="application/x-shockwave-flash" width="100%" height="100%"' + a + "></embed></object>"
                }
                (!d(t) || !t.parent().is(s.inner)) && s.inner.append(t), r.trigger("beforeShow"), s.inner.css("overflow", "yes" === o ? "scroll" : "no" === o ? "hidden" : o), r._setDimension(), r.reposition(), r.isOpen = !1, r.coming = null, r.bindEvents(), r.isOpened ? l.prevMethod && r.transitions[l.prevMethod]() : i(".fancybox-wrap").not(s.wrap).stop(!0).trigger("onReset").remove(), r.transitions[r.isOpened ? s.nextMethod : s.openMethod](), r._preloadImages()
            }
        },
        _setDimension: function () {
            var t, e, o, n, a, s, l, c, h, d = r.getViewport(), p = 0, m = !1, v = !1, m = r.wrap, y = r.skin, b = r.inner, w = r.current, v = w.width, x = w.height, T = w.minWidth, C = w.minHeight, $ = w.maxWidth, k = w.maxHeight, E = w.scrolling, S = w.scrollOutside ? w.scrollbarWidth : 0, I = w.margin, O = u(I[1] + I[3]), D = u(I[0] + I[2]);
            if (m.add(y).add(b).width("auto").height("auto").removeClass("fancybox-tmp"), I = u(y.outerWidth(!0) - y.width()), t = u(y.outerHeight(!0) - y.height()), e = O + I, o = D + t, n = f(v) ? (d.w - e) * u(v) / 100 : v, a = f(x) ? (d.h - o) * u(x) / 100 : x, "iframe" === w.type) {
                if (h = w.content, w.autoHeight && 1 === h.data("ready"))try {
                    h[0].contentWindow.document.location && (b.width(n).height(9999), s = h.contents().find("body"), S && s.css("overflow-x", "hidden"), a = s.outerHeight(!0))
                } catch (A) {
                }
            } else(w.autoWidth || w.autoHeight) && (b.addClass("fancybox-tmp"), w.autoWidth || b.width(n), w.autoHeight || b.height(a), w.autoWidth && (n = b.width()), w.autoHeight && (a = b.height()), b.removeClass("fancybox-tmp"));
            if (v = u(n), x = u(a), c = n / a, T = u(f(T) ? u(T, "w") - e : T), $ = u(f($) ? u($, "w") - e : $), C = u(f(C) ? u(C, "h") - o : C), k = u(f(k) ? u(k, "h") - o : k), s = $, l = k, w.fitToView && ($ = Math.min(d.w - e, $), k = Math.min(d.h - o, k)), e = d.w - O, D = d.h - D, w.aspectRatio ? (v > $ && (v = $, x = u(v / c)), x > k && (x = k, v = u(x * c)), T > v && (v = T, x = u(v / c)), C > x && (x = C, v = u(x * c))) : (v = Math.max(T, Math.min(v, $)), w.autoHeight && "iframe" !== w.type && (b.width(v), x = b.height()), x = Math.max(C, Math.min(x, k))), w.fitToView)if (b.width(v).height(x), m.width(v + I), d = m.width(), O = m.height(), w.aspectRatio)for (; (d > e || O > D) && v > T && x > C && !(19 < p++);)x = Math.max(C, Math.min(k, x - 10)), v = u(x * c), T > v && (v = T, x = u(v / c)), v > $ && (v = $, x = u(v / c)), b.width(v).height(x), m.width(v + I), d = m.width(), O = m.height(); else v = Math.max(T, Math.min(v, v - (d - e))), x = Math.max(C, Math.min(x, x - (O - D)));
            S && "auto" === E && a > x && e > v + I + S && (v += S), b.width(v).height(x), m.width(v + I), d = m.width(), O = m.height(), m = (d > e || O > D) && v > T && x > C, v = w.aspectRatio ? s > v && l > x && n > v && a > x : (s > v || l > x) && (n > v || a > x), i.extend(w, {
                dim: {
                    width: g(d),
                    height: g(O)
                },
                origWidth: n,
                origHeight: a,
                canShrink: m,
                canExpand: v,
                wPadding: I,
                hPadding: t,
                wrapSpace: O - y.outerHeight(!0),
                skinSpace: y.height() - x
            }), !h && w.autoHeight && x > C && k > x && !v && b.height("auto")
        },
        _getPosition: function (t) {
            var e = r.current, i = r.getViewport(), o = e.margin, n = r.wrap.width() + o[1] + o[3], a = r.wrap.height() + o[0] + o[2], o = {
                position: "absolute",
                top: o[0],
                left: o[3]
            };
            return e.autoCenter && e.fixed && !t && a <= i.h && n <= i.w ? o.position = "fixed" : e.locked || (o.top += i.y, o.left += i.x), o.top = g(Math.max(o.top, o.top + (i.h - a) * e.topRatio)), o.left = g(Math.max(o.left, o.left + (i.w - n) * e.leftRatio)), o
        },
        _afterZoomIn: function () {
            var t = r.current;
            t && (r.isOpen = r.isOpened = !0, r.wrap.css("overflow", "visible").addClass("fancybox-opened"), r.update(), (t.closeClick || t.nextClick && 1 < r.group.length) && r.inner.css("cursor", "pointer").bind("click.fb", function (e) {
                !i(e.target).is("a") && !i(e.target).parent().is("a") && (e.preventDefault(), r[t.closeClick ? "close" : "next"]())
            }), t.closeBtn && i(t.tpl.closeBtn).appendTo(r.skin).bind("click.fb", function (t) {
                t.preventDefault(), r.close()
            }), t.arrows && 1 < r.group.length && ((t.loop || 0 < t.index) && i(t.tpl.prev).appendTo(r.outer).bind("click.fb", r.prev), (t.loop || t.index < r.group.length - 1) && i(t.tpl.next).appendTo(r.outer).bind("click.fb", r.next)), r.trigger("afterShow"), t.loop || t.index !== t.group.length - 1 ? r.opts.autoPlay && !r.player.isActive && (r.opts.autoPlay = !1, r.play()) : r.play(!1))
        },
        _afterZoomOut: function (t) {
            t = t || r.current, i(".fancybox-wrap").trigger("onReset").remove(), i.extend(r, {
                group: {},
                opts: {},
                router: !1,
                current: null,
                isActive: !1,
                isOpened: !1,
                isOpen: !1,
                isClosing: !1,
                wrap: null,
                skin: null,
                outer: null,
                inner: null
            }), r.trigger("afterClose", t)
        }
    }), r.transitions = {
        getOrigPosition: function () {
            var t = r.current, e = t.element, i = t.orig, o = {}, n = 50, a = 50, s = t.hPadding, l = t.wPadding, c = r.getViewport();
            return !i && t.isDom && e.is(":visible") && (i = e.find("img:first"), i.length || (i = e)), d(i) ? (o = i.offset(), i.is("img") && (n = i.outerWidth(), a = i.outerHeight())) : (o.top = c.y + (c.h - a) * t.topRatio, o.left = c.x + (c.w - n) * t.leftRatio), ("fixed" === r.wrap.css("position") || t.locked) && (o.top -= c.y, o.left -= c.x), o = {
                top: g(o.top - s * t.topRatio),
                left: g(o.left - l * t.leftRatio),
                width: g(n + l),
                height: g(a + s)
            }
        }, step: function (t, e) {
            var i, o, n = e.prop;
            o = r.current;
            var a = o.wrapSpace, s = o.skinSpace;
            ("width" === n || "height" === n) && (i = e.end === e.start ? 1 : (t - e.start) / (e.end - e.start), r.isClosing && (i = 1 - i), o = "width" === n ? o.wPadding : o.hPadding, o = t - o, r.skin[n](u("width" === n ? o : o - a * i)), r.inner[n](u("width" === n ? o : o - a * i - s * i)))
        }, zoomIn: function () {
            var t = r.current, e = t.pos, o = t.openEffect, n = "elastic" === o, a = i.extend({opacity: 1}, e);
            delete a.position, n ? (e = this.getOrigPosition(), t.openOpacity && (e.opacity = .1)) : "fade" === o && (e.opacity = .1), r.wrap.css(e).animate(a, {
                duration: "none" === o ? 0 : t.openSpeed,
                easing: t.openEasing,
                step: n ? this.step : null,
                complete: r._afterZoomIn
            })
        }, zoomOut: function () {
            var t = r.current, e = t.closeEffect, i = "elastic" === e, o = {opacity: .1};
            i && (o = this.getOrigPosition(), t.closeOpacity && (o.opacity = .1)), r.wrap.animate(o, {
                duration: "none" === e ? 0 : t.closeSpeed,
                easing: t.closeEasing,
                step: i ? this.step : null,
                complete: r._afterZoomOut
            })
        }, changeIn: function () {
            var t, e = r.current, i = e.nextEffect, o = e.pos, n = {opacity: 1}, a = r.direction;
            o.opacity = .1, "elastic" === i && (t = "down" === a || "up" === a ? "top" : "left", "down" === a || "right" === a ? (o[t] = g(u(o[t]) - 200), n[t] = "+=200px") : (o[t] = g(u(o[t]) + 200), n[t] = "-=200px")), "none" === i ? r._afterZoomIn() : r.wrap.css(o).animate(n, {
                duration: e.nextSpeed,
                easing: e.nextEasing,
                complete: r._afterZoomIn
            })
        }, changeOut: function () {
            var t = r.previous, e = t.prevEffect, o = {opacity: .1}, n = r.direction;
            "elastic" === e && (o["down" === n || "up" === n ? "top" : "left"] = ("up" === n || "left" === n ? "-" : "+") + "=200px"), t.wrap.animate(o, {
                duration: "none" === e ? 0 : t.prevSpeed,
                easing: t.prevEasing,
                complete: function () {
                    i(this).trigger("onReset").remove()
                }
            })
        }
    }, r.helpers.overlay = {
        defaults: {closeClick: !0, speedOut: 200, showEarly: !0, css: {}, locked: !h, fixed: !0},
        overlay: null,
        fixed: !1,
        el: i("html"),
        create: function (t) {
            t = i.extend({}, this.defaults, t), this.overlay && this.close(), this.overlay = i('<div class="fancybox-overlay"></div>').appendTo(r.coming ? r.coming.parent : t.parent), this.fixed = !1, t.fixed && r.defaults.fixed && (this.overlay.addClass("fancybox-overlay-fixed"), this.fixed = !0)
        },
        open: function (t) {
            var e = this;
            t = i.extend({}, this.defaults, t), this.overlay ? this.overlay.unbind(".overlay").width("auto").height("auto") : this.create(t), this.fixed || (a.bind("resize.overlay", i.proxy(this.update, this)), this.update()), t.closeClick && this.overlay.bind("click.overlay", function (t) {
                return i(t.target).hasClass("fancybox-overlay") ? (r.isActive ? r.close() : e.close(), !1) : void 0
            }), this.overlay.css(t.css).show()
        },
        close: function () {
            var t, e;
            a.unbind("resize.overlay"), this.el.hasClass("fancybox-lock") && (i(".fancybox-margin").removeClass("fancybox-margin"), t = a.scrollTop(), e = a.scrollLeft(), this.el.removeClass("fancybox-lock"), a.scrollTop(t).scrollLeft(e)), i(".fancybox-overlay").remove().hide(), i.extend(this, {
                overlay: null,
                fixed: !1
            })
        },
        update: function () {
            var t, i = "100%";
            this.overlay.width(i).height("100%"), l ? (t = Math.max(e.documentElement.offsetWidth, e.body.offsetWidth), s.width() > t && (i = s.width())) : s.width() > a.width() && (i = s.width()), this.overlay.width(i).height(s.height())
        },
        onReady: function (t, e) {
            var o = this.overlay;
            i(".fancybox-overlay").stop(!0, !0), o || this.create(t), t.locked && this.fixed && e.fixed && (o || (this.margin = s.height() > a.height() ? i("html").css("margin-right").replace("px", "") : !1), e.locked = this.overlay.append(e.wrap), e.fixed = !1), !0 === t.showEarly && this.beforeShow.apply(this, arguments)
        },
        beforeShow: function (t, e) {
            var o, n;
            e.locked && (!1 !== this.margin && (i("*").filter(function () {
                return "fixed" === i(this).css("position") && !i(this).hasClass("fancybox-overlay") && !i(this).hasClass("fancybox-wrap")
            }).addClass("fancybox-margin"), this.el.addClass("fancybox-margin")), o = a.scrollTop(), n = a.scrollLeft(), this.el.addClass("fancybox-lock"), a.scrollTop(o).scrollLeft(n)), this.open(t)
        },
        onUpdate: function () {
            this.fixed || this.update()
        },
        afterClose: function (t) {
            this.overlay && !r.coming && this.overlay.fadeOut(t.speedOut, i.proxy(this.close, this))
        }
    }, r.helpers.title = {
        defaults: {type: "float", position: "bottom"}, beforeShow: function (t) {
            var e = r.current, o = e.title, n = t.type;
            if (i.isFunction(o) && (o = o.call(e.element, e)), p(o) && "" !== i.trim(o)) {
                switch (e = i('<div class="fancybox-title fancybox-title-' + n + '-wrap">' + o + "</div>"), n) {
                    case"inside":
                        n = r.skin;
                        break;
                    case"outside":
                        n = r.wrap;
                        break;
                    case"over":
                        n = r.inner;
                        break;
                    default:
                        n = r.skin, e.appendTo("body"), l && e.width(e.width()), e.wrapInner('<span class="child"></span>'), r.current.margin[2] += Math.abs(u(e.css("margin-bottom")))
                }
                e["top" === t.position ? "prependTo" : "appendTo"](n)
            }
        }
    }, i.fn.fancybox = function (t) {
        var e, o = i(this), n = this.selector || "", a = function (a) {
            var s, l, c = i(this).blur(), h = e;
            !(a.ctrlKey || a.altKey || a.shiftKey || a.metaKey || c.is(".fancybox-wrap") || (s = t.groupAttr || "data-fancybox-group", l = c.attr(s), l || (s = "rel", l = c.get(0)[s]), l && "" !== l && "nofollow" !== l && (c = n.length ? i(n) : o, c = c.filter("[" + s + '="' + l + '"]'), h = c.index(this)), t.index = h, !1 === r.open(c, t) || !a.preventDefault()))
        };
        return t = t || {}, e = t.index || 0, n && !1 !== t.live ? s.undelegate(n, "click.fb-start").delegate(n + ":not('.fancybox-item, .fancybox-nav')", "click.fb-start", a) : o.unbind("click.fb-start").bind("click.fb-start", a), this.filter("[data-fancybox-start=1]").trigger("click"), this
    }, s.ready(function () {
        var e, a;
        if (i.scrollbarWidth === o && (i.scrollbarWidth = function () {
                var t = i('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo("body"), e = t.children(), e = e.innerWidth() - e.height(99).innerWidth();
                return t.remove(), e
            }), i.support.fixedPosition === o) {
            e = i.support, a = i('<div style="position:fixed;top:20px;"></div>').appendTo("body");
            var s = 20 === a[0].offsetTop || 15 === a[0].offsetTop;
            a.remove(), e.fixedPosition = s
        }
        i.extend(r.defaults, {
            scrollbarWidth: i.scrollbarWidth(),
            fixed: i.support.fixedPosition,
            parent: i("body")
        }), e = i(t).width(), n.addClass("fancybox-lock-test"), a = i(t).width(), n.removeClass("fancybox-lock-test"), i("<style type='text/css'>.fancybox-margin{margin-right:" + (a - e) + "px;}</style>").appendTo("head")
    })
}(window, document, jQuery), function (t) {
    "use strict";
    Array.prototype.unique = function () {
        for (var t = {}, e = [], i = 0, o = this.length; o > i; ++i)t[this[i]] || (t[this[i]] = !0, e.push(this[i]));
        return e
    }, t(function () {
        function e() {
            if ("" !== location.hash) {
                var e = location.hash.replace("#gallery-", ""), i = e.split("-");
                i.filter(function (t) {
                    return parseInt(t)
                });
                var o = t("#gallery-" + i.shift() + " .gallery-item:eq(" + i.shift() + ") a");
                o.length && o.trigger("click")
            }
        }

        t(".gallery a").fancybox({
            afterShow: function () {
                var e = t(this.element).parents(".gallery"), i = e.find(".gallery-item").index(t(this.element).parents(".gallery-item"));
                location.hash = e.attr("id") + "-" + i
            }, beforeShow: function () {
                this.title = t(this.element).parent().parent().find(".wp-caption-text").text()
            }
        }), e(), t('[data-toggle="tooltip"]').tooltip(), t('[data-toggle="ctooltip"]').hover(function () {
            t(this).find('[data-toggle="tooltip"]').tooltip("show")
        }, function () {
            t(this).find('[data-toggle="tooltip"]').tooltip("hide")
        });
        var i = t("#b-autosize-menu li").length;
        13 > i && t("#b-autosize-menu").addClass("b-autosize-height")
    }), t(function () {
        var e = t('[data-toggle="stickmenu"]');
        if (e.length) {
            var i = e.position().top, o = t("#wpadminbar").length;
            o && e.css("top", "32px"), t(window).scroll(function () {
                var o = t(window).scrollTop();
                t(window).width() >= 975 ? o >= i ? e.hasClass("b-main-menu-fixed") || e.addClass("b-main-menu-fixed") : e.hasClass("b-main-menu-fixed") && e.removeClass("b-main-menu-fixed") : e.removeClass("b-main-menu-fixed")
            })
        }
    }), t(function () {
        var e = function () {
            return this._getParams = this.MGET(), this
        };
        e.prototype.getParamByName = function (t) {
            return this._getParams[t] ? this._getParams[t] : !1
        }, e.prototype.setParamByName = function (t, e) {
            return this._getParams[t] = e, this
        }, e.prototype.deleteParamByName = function (t) {
            return this._getParams[t] && delete this._getParams[t], this
        }, e.prototype.MGET = function () {
            var t = {}, e = window.location.search.split(/\?|\&/);
            return e.forEach(function (e) {
                if (e) {
                    var i = e.split("=");
                    t[i[0]] = i[1]
                }
            }), t
        }, e.prototype.getParameterString = function (e) {
            return t.param(t.extend(this._getParams, e))
        }, e.prototype.getUrl = function () {
            var t = location.origin + location.pathname;
            return this.getParameterString() ? t + "?" + this.getParameterString() : t
        }, e.prototype.redirect = function (t) {
            location.href = decodeURIComponent(t)
        }, t(window).on("ssdmaFilterPrice", function (t, i, o) {
            var n = new e;
            n.getParamByName("order") || n.setParamByName("order", "DESC"), n.setParamByName("pmin", i), n.setParamByName("pmax", o), n.setParamByName("orderby", "price"), n.redirect(n.getUrl())
        }), t(".b-unselect").click(function (e) {
            e.preventDefault(), t(window).trigger("ssdmaFilterCheckboxClean")
        }), t(window).on("ssdmaFilterCheckboxClean", function () {
            var t = new e;
            t.deleteParamByName("ids"), t.redirect(t.getUrl())
        }), t(window).on("ssdmaFilterCheckbox", function (t, i, o) {
            var n = new e, a = n.getParamByName("ids");
            a = a ? a.split("-").filter(function (t) {
                return "" != t ? t : void 0
            }) : [], i ? a.push(o) : a.forEach(function (t, e, i) {
                t == o && i.splice(e, 1)
            }), a = a.unique().join("-"), "" == a ? n.deleteParamByName("ids") : n.setParamByName("ids", a), n.redirect(n.getUrl())
        }), t(window).on("ssdmaFilterPriceInit", function () {
            var i = new e, o = t('[data-toggle="slider"]'), n = t("#filter-slider-min"), a = t("#filter-slider-max"), s = parseFloat(o.attr("data-max")), r = parseFloat(i.getParamByName("pmin") && i.getParamByName("pmin") >= 0 ? i.getParamByName("pmin") : 0), l = parseFloat(i.getParamByName("pmax") ? i.getParamByName("pmax") : Math.ceil(s / 2));
            o.slider({
                range: !0, min: 0, max: s, values: [r, l], create: function () {
                    n.val(r), a.val(l)
                }, slide: function (t, e) {
                    n.val(e.values[0]), a.val(e.values[1])
                }, stop: function (e, i) {
                    t(window).trigger("ssdmaFilterPrice", [i.values[0], i.values[1]])
                }
            }), n.change(function () {
                var e = parseFloat(t(this).val()), i = parseFloat(a.val());
                t(window).trigger("ssdmaFilterPrice", [e, i])
            }), a.change(function () {
                var e = parseFloat(t(this).val()), i = parseFloat(n.val());
                t(window).trigger("ssdmaFilterPrice", [i, e])
            })
        }), t(".b-checked-cats input:checkbox").click(function () {
            var e = !1;
            t(this).attr("checked") && (e = !0), t(window).trigger("ssdmaFilterCheckbox", [e, t(this).val()])
        }), t(window).trigger("ssdmaFilterPriceInit")
    })
}(jQuery);
jQuery(function($) {
// All Products page
var body = $("body");
    if(body.hasClass("all-products-page")) {

        $('.all-products-by-alphabet>.item').click(function() {

            // save $(this) in a variable for efficiency
            var $this = $(this);

            if( $this.hasClass("active") ) return false;

            // hide panels
            $('.all-products-lists .products-list').hide();
            $('.all-products-by-alphabet>.active').removeClass('active');

            $('.all-products-lists .products-list>.products-list-head').addClass('active');

            // add active state to new tab
            $this.addClass('active').blur();

            if( $this.attr('data-link') !== "show-all-categories" ) {

                // retrieve href from link (is id of panel to display)
                var panel = $this.attr('data-link');
                // show panel
                $(panel).fadeIn();

            } else {

                $('.all-products-lists .products-list>.products-list-head').removeClass('active');
                $('.all-products-lists .products-list').fadeIn();

            }



        }); // end click

    }
    // END All Products page
});
	(function ($) {
$('#menu_mobile').on('click', function (){
	$('.top-menu-head-mobile').toggle();
	$('#menu_mobile').toggleClass('mobop');
});
	})(jQuery);

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/js/";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(2);
	__webpack_require__(3);
	__webpack_require__(4);
	__webpack_require__(5);
	__webpack_require__(6);
	module.exports = __webpack_require__(7);


/***/ },
/* 1 */
/***/ function(module, exports) {

	module.exports = jQuery;

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {"use strict";

	(function ($) {
		'use strict';

		__webpack_require__(11);
		__webpack_require__(8);

		$('select').selectpicker();

		$('.home-slider').slick({
			dots: true,
			infinite: true,
			speed: 500,
			fade: true,
			cssEase: 'linear'
		});

		$('.js-select_sort').on('change', function () {
			var url = jQuery(this).val();
			if (url) {
				window.location = url;
			}
			return false;
		});
	})(jQuery);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {'use strict';

	(function ($) {
		$('.mobile-slide').slick({
			adaptiveHeight: true,
			vertical: false,
			appendArrows: $('.mobile-slide')
		});
	})(jQuery);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {'use strict';

	/**
	 * Created by sunfun on 03.09.16.
	 */
	(function ($) {
		'use strict';

		__webpack_require__(10);

		var productSlider = function () {
			var $this, $body, ezApi;
			var mq768 = window.matchMedia('(min-width: 768px)');
			return {
				init: function init() {
					$this = this;

					$('.slider-for').on('afterChange init', function () {
						$this.mediaInit(mq768);
					});

					$('.slider-for').slick({
						slidesToShow: 1,
						slidesToScroll: 1,
						arrows: false,
						fade: true,
						asNavFor: '.thumb-list',
						focusOnSelect: false,
						infinite: true,
						cssEase: 'linear'
					});

					$('.product-slider .thumb-list').slick({
						slidesToShow: 3,
						slidesToScroll: 1,
						arrows: true,
						infinite: true,
						//autoplay       : true,
						autoplaySpeed: 2000,
						vertical: true,
						asNavFor: '.slider-for',
						centerMode: false,
						focusOnSelect: true,
						centerPadding: 0,
						responsive: [{
							breakpoint: 768,
							settings: {
								vertical: false
							}
						}, {
							breakpoint: 320,
							settings: {
								vertical: false
							}
						}]
					});

					mq768.addListener(function (b) {
						$this.mediaInit(b);
					});
				},
				mediaInit: function mediaInit(b) {
					if (b.matches) {
						$this.initZoom();
					} else {
						$('.zoomContainer').remove();
					}
				},
				initZoom: function initZoom() {

					ezApi = $('.slider-for .slick-active').ezPlus({
						zoomWindowFadeIn: 500,
						zoomWindowFadeOut: 500,
						lensFadeIn: 500,
						lensFadeOut: 500
					}).data('ezPlus');

					console.log(ezApi);
				}
			};
		}();

		productSlider.init();
	})(jQuery);

	/**
	 * Прилипание слайдера
	 */
	(function ($) {
		var a = document.querySelector('.js-sticky'),
		    b = null,
		    P = 0;
		//	if ( a ) {
		//		window.addEventListener( 'scroll', Ascroll, false );
		//		document.body.addEventListener( 'scroll', Ascroll, false );
		//	}
		/*
	 	function Ascroll() {
	 		if ( window.outerWidth < 968 ) {
	 			return;
	 		}
	 		if ( b == null ) {
	 			var Sa = getComputedStyle( a, '' ), s = '';
	 			for ( var i = 0; i < Sa.length; i++ ) {
	 				if ( Sa[ i ].indexOf( 'overflow' ) == 0 || Sa[ i ].indexOf( 'padding' ) == 0 || Sa[ i ].indexOf( 'border' ) == 0 || Sa[ i ].indexOf( 'outline' ) == 0 || Sa[ i ].indexOf( 'box-shadow' ) == 0 || Sa[ i ].indexOf( 'background' ) == 0 ) {
	 					s += Sa[ i ] + ': ' + Sa.getPropertyValue( Sa[ i ] ) + '; '
	 				}
	 			}
	 			b               = document.createElement( 'div' );
	 			b.style.cssText = s + ' box-sizing: border-box; width: ' + a.offsetWidth + 'px;';
	 			a.insertBefore( b, a.firstChild );
	 			var l = a.childNodes.length;
	 			for ( var i = 1; i < l; i++ ) {
	 				b.appendChild( a.childNodes[ 1 ] );
	 			}
	 			a.style.height  = b.getBoundingClientRect().height + 'px';
	 			a.style.padding = '0';
	 			a.style.border  = '0';
	 		}
	 		var Ra = a.getBoundingClientRect(),
	 			R  = Math.round( Ra.top + b.getBoundingClientRect().height - document.querySelector( '.js-sticky-main' ).getBoundingClientRect().bottom );
	 		if ( (Ra.top - P) <= 0 ) {
	 			if ( (Ra.top - P) <= R ) {
	 				b.className = 'stop';
	 				b.style.top = -R + 'px';
	 			} else {
	 				b.className = 'sticky';
	 				b.style.top = P + 'px';
	 			}
	 		} else {
	 			b.className = '';
	 			b.style.top = '';
	 		}
	 		window.addEventListener( 'resize', function () {
	 			a.children[ 0 ].style.width = getComputedStyle( a, '' ).width
	 		}, false );
	 	}
	 */

		/**
	  * скрол к отзывам
	  */

		$('body').on('click', '[data-scroll="feedback-head"]', function () {

			$('[data-scroll="details"]').tab('show');
			var top = $('#feedback-head').offset().top - 100;
			$('body,html').stop().animate({
				scrollTop: top
			}, 200);
		});

		/**
	  * замена табов на список
	  */
		__webpack_require__(9);

		jQuery('#tabs').tabCollapse({
			tabsClass: 'hidden-sm hidden-xs',
			accordionClass: 'visible-sm visible-xs',
			accordionTemplate: function accordionTemplate(heading, groupId, parentId, active) {
				return '<div class="panel">' + '   <div class="panel-heading">' + '      <h4 class="panel-title">' + '      </h4>' + '   </div>' + '   <div id="' + groupId + '" class="panel-collapse collapse ' + (active ? 'in' : '') + '">' + '       <div class="panel-body js-tabcollapse-panel-body">' + '       </div>' + '   </div>' + '</div>';
			}
		});
	})(jQuery);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {'use strict';

	/**
	 * Created by sunfun on 05.09.16.
	 */
	/**
	 * quantity item btn
	 */
	jQuery(function ($) {
		var options = {
			el: '.js-wrap_quantity',
			add: '[data-quantity="add"]',
			remove: '[data-quantity="remove"]',
			input: 'input'
		};

		var $body = $('body');
		$body.on('click', options.add, function (e) {
			e.preventDefault();

			set(1, this);
		});

		$body.on('click', options.remove, function (e) {
			e.preventDefault();
			set(-1, this);
		});

		function set(change, $this) {
			var $input = $($this).closest(options.el).find(options.input);
			var v = $input.val();
			v = (v = parseInt(v) + change) > 0 ? v : 1;
			$input.val(v).trigger('mouseup');
		}
	});
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {"use strict";

	/**
	 * Created by sunfun on 03.09.16.
	 */
	(function ($) {})(jQuery);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {'use strict';

	/**
	 * Created by sunfun on 05.09.16.
	 */
	(function ($) {
		'use strict';

		function isURL(str) {

			var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
			return regexp.test(str);
		}

		$.fn.sku = function (defaults) {

			var options = $.extend({
				item: '.sku-set',
				sku: '.item-sku',
				error: '.sku-warning',
				productSlider: '.slider-for'
			}, defaults);

			var productSlider = $(options.productSlider);

			var th = $(this);

			var setSKU = function setSKU() {
				th.on('click', options.item, function () {
					if ($(this).hasClass('disabled')) return false;

					var pid = $(this).data('set'),
					    variation = $(this).data('meta'),
					    line = $(this).parents(options.sku),
					    skuval = $('#check-' + pid + '-' + variation).val(),
					    imgSkuBig = $(this).children('img').data('img');
					imgSkuBig = imgSkuBig ? imgSkuBig : skuval;

					if (!$(this).hasClass('active, disabled')) {
						line.find(options.item).removeClass('active');
						line.find('dt').css('color', '');

						$(this).addClass('active');
						$('#set-' + pid).val(skuval);

						line.find(options.error).css('display', 'none');
					}

					if (isURL(imgSkuBig)) {

						if (imgSkuBig.indexOf('_50x50.jpg') > 0) {
							imgSkuBig = imgSkuBig.replace('_50x50.jpg', '');
						}

						productSlider.slick('slickAdd', '<img class="img-responsive" data-zoom-image="' + imgSkuBig + '" src="' + imgSkuBig + '" alt=""/>');

						productSlider.slick('slickGoTo');
					}
				});
			};

			return this.each(setSKU);
		};

		$('form.form-SingleProduct').sku();

		/**
	  * $this is form sku params
	  *
	  * @param $this
	  * @param sticker
	  * @returns {*}
	  */
		function getSku($this, sticker) {

			var options = {
				line: '.item-sku',
				variation: '[name="sku-meta-set[]"]'
			},
			    error = false,
			    foo = [];

			$('.form-SingleProduct').find(options.variation).each(function () {

				if ($(this).val().length == 0 && sticker !== false) {
					error = true;
				} else {
					foo.push($(this).val());
				}
			});

			if (error) return false;

			return { foo: foo };
		}

		var changePriceSku = function () {
			var $this, skuAttr, sku, currency;

			var obj = {
				price: '[data-singleProduct="price"]',
				salePrice: '[data-singleProduct="savePrice"]',
				quantity: '[data-singleProduct="quantity"]',
				save: '[data-singleProduct="save"]',
				savePercent: '[data-singleProduct="savePercent"]',

				box: {
					price: '[data-productPrice="price"]',
					savePercent: '[data-productPrice="savePercent"]',
					quantity: '[data-productPrice="quantity"]'
				}
			};

			function renderSkuActive() {
				var value = getSku($('form.form-SingleProduct'), false);
				if (!value) return false;
				var foo = value.foo;

				$('.sku-set').addClass('disabled');

				$.each(skuAttr, function (skuAttrName, e) {
					var sku = skuAttrName.split(';');
					$('input[value="' + sku[0] + '"]').closest('.sku-set').removeClass('disabled');
					if (foo[0] == sku[0]) {
						$.each(sku, function (i) {
							$('input[value="' + sku[i] + '"]').closest('.sku-set').removeClass('disabled');
						});
					}
				});

				$('.sku-set.disabled.active').removeClass('active').each(function (i, e) {
					var idSkuName = $(e).data('set');
					$('#set-' + idSkuName).val('');
				});
			}

			function changeSku() {

				var value = getSku($(this).parents('form'), false),
				    item = false,
				    skuAttrName = '';
				if (!value) return false;
				var foo = value.foo;

				for (var n in foo) {
					if (foo.hasOwnProperty(n)) {
						skuAttrName += foo[n] + ';';
					}
				}

				skuAttrName = skuAttrName.slice(0, -1);
				item = skuAttr[skuAttrName];

				//fix delete
				if (!item) {
					console.log('no sku');
					return;
				}
			}

			function setSkuPrice(e) {
				var item = e.item,
				    i;
				console.log(item);
				var price = item.price,
				    salePrice = item.salePrice,
				    quantity = item.quantity,
				    savePercent = item.discount,
				    save = item.save;

				//			$( '.form-SingleProduct [name="quantity"]' )
				//				.data( 'price', item._salePrice )
				//				.data( 'oldprice', item._price )
				//				.click();

				$(obj.salePrice).text(salePrice);
				$(obj.price).text(price);

				$(obj.save).text(save);
				$(obj.savePercent).text(savePercent);

				$(obj.quantity).text(quantity);

				if (parseFloat(item._price) > 0) {
					$(obj.box.price).show();
				} else {
					$(obj.box.price).hide();
				}

				if (parseFloat(item._price) - parseFloat(item._salePrice) > 0) {
					$(obj.box.savePercent).show();
				} else {
					$(obj.box.savePercent).hide();
				}

				if (item.quantity < 15) {
					$(obj.box.quantity).show();
				} else {
					$(obj.box.quantity).hide();
				}
			}

			return {
				init: function init() {
					$this = this;
					skuAttr = window.skuAttr;
					sku = window.sku;
					currency = $('[name="currency"]').val();

					$('body').on('click', '.sku-set', changeSku).on('click', '.sku-set', renderSkuActive);
					//					.on( 'cart:skuPrice', setSkuPrice );

					renderSkuActive();
					$('.sku-set.active').click();
				}
			};
		}();

		changePriceSku.init();

		/**
	  * Add product to cart
	  */
		$('[data-singleProduct="addCart"]').on('click', function (e) {
			e.preventDefault();
			addOrder($(this).parents('form'));
		});

		function addOrder($this) {

			var options = {
				item: '[name="quantity"]',
				post_id: '[name="post_id"]',
				shipping: '[name="shipping"]'
			};

			var $sku = getSku($this);
			console.log($sku);
			if ($sku === false) return false;
			adsCart.add({
				post_id: $(options.post_id).val(),
				quantity: $(options.item).val(),
				shipping: $(options.shipping).val(),
				variation: $sku.foo,
				title: $sku.too
			});
		}

		var pageSingleProduct = function () {
			var $this;

			function setTimeShipping(option) {
				$('[data-singleProduct="shipping-info"]').html(option.data('info'));
			}

			function setTotalPrice(option) {
				$('[data-singleProduct="shipping"]').data('price_shipping', option.data('price')).click();
			}

			return {
				init: function init() {
					$this = this;
					$(window).load(function () {
						$('[data-singleProduct="shipping"]').click();
					});

					$('select[data-singleProduct="shipping"]').on('change', function () {
						var option = $(this).find('option:selected');
						setTimeShipping(option);
						setTotalPrice(option);
					});
				}
			};
		}();

		pageSingleProduct.init();
	})(jQuery);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
	 * Bootstrap-select v1.11.2 (http://silviomoreto.github.io/bootstrap-select)
	 *
	 * Copyright 2013-2016 bootstrap-select
	 * Licensed under MIT (https://github.com/silviomoreto/bootstrap-select/blob/master/LICENSE)
	 */

	(function (root, factory) {
	  if (true) {
	    // AMD. Register as an anonymous module unless amdModuleId is set
	    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(1)], __WEBPACK_AMD_DEFINE_RESULT__ = function (a0) {
	      return (factory(a0));
	    }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	  } else if (typeof exports === 'object') {
	    // Node. Does not work with strict CommonJS, but
	    // only CommonJS-like environments that support module.exports,
	    // like Node.
	    module.exports = factory(require("jquery"));
	  } else {
	    factory(jQuery);
	  }
	}(this, function (jQuery) {

	(function ($) {
	  'use strict';

	  //<editor-fold desc="Shims">
	  if (!String.prototype.includes) {
	    (function () {
	      'use strict'; // needed to support `apply`/`call` with `undefined`/`null`
	      var toString = {}.toString;
	      var defineProperty = (function () {
	        // IE 8 only supports `Object.defineProperty` on DOM elements
	        try {
	          var object = {};
	          var $defineProperty = Object.defineProperty;
	          var result = $defineProperty(object, object, object) && $defineProperty;
	        } catch (error) {
	        }
	        return result;
	      }());
	      var indexOf = ''.indexOf;
	      var includes = function (search) {
	        if (this == null) {
	          throw new TypeError();
	        }
	        var string = String(this);
	        if (search && toString.call(search) == '[object RegExp]') {
	          throw new TypeError();
	        }
	        var stringLength = string.length;
	        var searchString = String(search);
	        var searchLength = searchString.length;
	        var position = arguments.length > 1 ? arguments[1] : undefined;
	        // `ToInteger`
	        var pos = position ? Number(position) : 0;
	        if (pos != pos) { // better `isNaN`
	          pos = 0;
	        }
	        var start = Math.min(Math.max(pos, 0), stringLength);
	        // Avoid the `indexOf` call if no match is possible
	        if (searchLength + start > stringLength) {
	          return false;
	        }
	        return indexOf.call(string, searchString, pos) != -1;
	      };
	      if (defineProperty) {
	        defineProperty(String.prototype, 'includes', {
	          'value': includes,
	          'configurable': true,
	          'writable': true
	        });
	      } else {
	        String.prototype.includes = includes;
	      }
	    }());
	  }

	  if (!String.prototype.startsWith) {
	    (function () {
	      'use strict'; // needed to support `apply`/`call` with `undefined`/`null`
	      var defineProperty = (function () {
	        // IE 8 only supports `Object.defineProperty` on DOM elements
	        try {
	          var object = {};
	          var $defineProperty = Object.defineProperty;
	          var result = $defineProperty(object, object, object) && $defineProperty;
	        } catch (error) {
	        }
	        return result;
	      }());
	      var toString = {}.toString;
	      var startsWith = function (search) {
	        if (this == null) {
	          throw new TypeError();
	        }
	        var string = String(this);
	        if (search && toString.call(search) == '[object RegExp]') {
	          throw new TypeError();
	        }
	        var stringLength = string.length;
	        var searchString = String(search);
	        var searchLength = searchString.length;
	        var position = arguments.length > 1 ? arguments[1] : undefined;
	        // `ToInteger`
	        var pos = position ? Number(position) : 0;
	        if (pos != pos) { // better `isNaN`
	          pos = 0;
	        }
	        var start = Math.min(Math.max(pos, 0), stringLength);
	        // Avoid the `indexOf` call if no match is possible
	        if (searchLength + start > stringLength) {
	          return false;
	        }
	        var index = -1;
	        while (++index < searchLength) {
	          if (string.charCodeAt(start + index) != searchString.charCodeAt(index)) {
	            return false;
	          }
	        }
	        return true;
	      };
	      if (defineProperty) {
	        defineProperty(String.prototype, 'startsWith', {
	          'value': startsWith,
	          'configurable': true,
	          'writable': true
	        });
	      } else {
	        String.prototype.startsWith = startsWith;
	      }
	    }());
	  }

	  if (!Object.keys) {
	    Object.keys = function (
	      o, // object
	      k, // key
	      r  // result array
	      ){
	      // initialize object and result
	      r=[];
	      // iterate over object keys
	      for (k in o)
	          // fill result array with non-prototypical keys
	        r.hasOwnProperty.call(o, k) && r.push(k);
	      // return result
	      return r;
	    };
	  }

	  // set data-selected on select element if the value has been programmatically selected
	  // prior to initialization of bootstrap-select
	  // * consider removing or replacing an alternative method *
	  var valHooks = {
	    useDefault: false,
	    _set: $.valHooks.select.set
	  };

	  $.valHooks.select.set = function(elem, value) {
	    if (value && !valHooks.useDefault) $(elem).data('selected', true);

	    return valHooks._set.apply(this, arguments);
	  };

	  var changed_arguments = null;
	  $.fn.triggerNative = function (eventName) {
	    var el = this[0],
	        event;

	    if (el.dispatchEvent) { // for modern browsers & IE9+
	      if (typeof Event === 'function') {
	        // For modern browsers
	        event = new Event(eventName, {
	          bubbles: true
	        });
	      } else {
	        // For IE since it doesn't support Event constructor
	        event = document.createEvent('Event');
	        event.initEvent(eventName, true, false);
	      }

	      el.dispatchEvent(event);
	    } else if (el.fireEvent) { // for IE8
	      event = document.createEventObject();
	      event.eventType = eventName;
	      el.fireEvent('on' + eventName, event);
	    } else {
	      // fall back to jQuery.trigger
	      this.trigger(eventName);
	    }
	  };
	  //</editor-fold>

	  // Case insensitive contains search
	  $.expr.pseudos.icontains = function (obj, index, meta) {
	    var $obj = $(obj);
	    var haystack = ($obj.data('tokens') || $obj.text()).toString().toUpperCase();
	    return haystack.includes(meta[3].toUpperCase());
	  };

	  // Case insensitive begins search
	  $.expr.pseudos.ibegins = function (obj, index, meta) {
	    var $obj = $(obj);
	    var haystack = ($obj.data('tokens') || $obj.text()).toString().toUpperCase();
	    return haystack.startsWith(meta[3].toUpperCase());
	  };

	  // Case and accent insensitive contains search
	  $.expr.pseudos.aicontains = function (obj, index, meta) {
	    var $obj = $(obj);
	    var haystack = ($obj.data('tokens') || $obj.data('normalizedText') || $obj.text()).toString().toUpperCase();
	    return haystack.includes(meta[3].toUpperCase());
	  };

	  // Case and accent insensitive begins search
	  $.expr.pseudos.aibegins = function (obj, index, meta) {
	    var $obj = $(obj);
	    var haystack = ($obj.data('tokens') || $obj.data('normalizedText') || $obj.text()).toString().toUpperCase();
	    return haystack.startsWith(meta[3].toUpperCase());
	  };

	  /**
	   * Remove all diatrics from the given text.
	   * @access private
	   * @param {String} text
	   * @returns {String}
	   */
	  function normalizeToBase(text) {
	    var rExps = [
	      {re: /[\xC0-\xC6]/g, ch: "A"},
	      {re: /[\xE0-\xE6]/g, ch: "a"},
	      {re: /[\xC8-\xCB]/g, ch: "E"},
	      {re: /[\xE8-\xEB]/g, ch: "e"},
	      {re: /[\xCC-\xCF]/g, ch: "I"},
	      {re: /[\xEC-\xEF]/g, ch: "i"},
	      {re: /[\xD2-\xD6]/g, ch: "O"},
	      {re: /[\xF2-\xF6]/g, ch: "o"},
	      {re: /[\xD9-\xDC]/g, ch: "U"},
	      {re: /[\xF9-\xFC]/g, ch: "u"},
	      {re: /[\xC7-\xE7]/g, ch: "c"},
	      {re: /[\xD1]/g, ch: "N"},
	      {re: /[\xF1]/g, ch: "n"}
	    ];
	    $.each(rExps, function () {
	      text = text.replace(this.re, this.ch);
	    });
	    return text;
	  }


	  function htmlEscape(html) {
	    var escapeMap = {
	      '&': '&amp;',
	      '<': '&lt;',
	      '>': '&gt;',
	      '"': '&quot;',
	      "'": '&#x27;',
	      '`': '&#x60;'
	    };
	    var source = '(?:' + Object.keys(escapeMap).join('|') + ')',
	        testRegexp = new RegExp(source),
	        replaceRegexp = new RegExp(source, 'g'),
	        string = html == null ? '' : '' + html;
	    return testRegexp.test(string) ? string.replace(replaceRegexp, function (match) {
	      return escapeMap[match];
	    }) : string;
	  }

	  var Selectpicker = function (element, options, e) {
	    // bootstrap-select has been initialized - revert valHooks.select.set back to its original function
	    if (!valHooks.useDefault) {
	      $.valHooks.select.set = valHooks._set;
	      valHooks.useDefault = true;
	    }

	    if (e) {
	      e.stopPropagation();
	      e.preventDefault();
	    }

	    this.$element = $(element);
	    this.$newElement = null;
	    this.$button = null;
	    this.$menu = null;
	    this.$lis = null;
	    this.options = options;

	    // If we have no title yet, try to pull it from the html title attribute (jQuery doesnt' pick it up as it's not a
	    // data-attribute)
	    if (this.options.title === null) {
	      this.options.title = this.$element.attr('title');
	    }

	    //Expose public methods
	    this.val = Selectpicker.prototype.val;
	    this.render = Selectpicker.prototype.render;
	    this.refresh = Selectpicker.prototype.refresh;
	    this.setStyle = Selectpicker.prototype.setStyle;
	    this.selectAll = Selectpicker.prototype.selectAll;
	    this.deselectAll = Selectpicker.prototype.deselectAll;
	    this.destroy = Selectpicker.prototype.destroy;
	    this.remove = Selectpicker.prototype.remove;
	    this.show = Selectpicker.prototype.show;
	    this.hide = Selectpicker.prototype.hide;

	    this.init();
	  };

	  Selectpicker.VERSION = '1.11.2';

	  // part of this is duplicated in i18n/defaults-en_US.js. Make sure to update both.
	  Selectpicker.DEFAULTS = {
	    noneSelectedText: 'Nothing selected',
	    noneResultsText: 'No results matched {0}',
	    countSelectedText: function (numSelected, numTotal) {
	      return (numSelected == 1) ? "{0} item selected" : "{0} items selected";
	    },
	    maxOptionsText: function (numAll, numGroup) {
	      return [
	        (numAll == 1) ? 'Limit reached ({n} item max)' : 'Limit reached ({n} items max)',
	        (numGroup == 1) ? 'Group limit reached ({n} item max)' : 'Group limit reached ({n} items max)'
	      ];
	    },
	    selectAllText: 'Select All',
	    deselectAllText: 'Deselect All',
	    doneButton: false,
	    doneButtonText: 'Close',
	    multipleSeparator: ', ',
	    styleBase: 'btn',
	    style: 'btn-default',
	    size: 'auto',
	    title: null,
	    selectedTextFormat: 'values',
	    width: false,
	    container: false,
	    hideDisabled: false,
	    showSubtext: false,
	    showIcon: true,
	    showContent: true,
	    dropupAuto: true,
	    header: false,
	    liveSearch: false,
	    liveSearchPlaceholder: null,
	    liveSearchNormalize: false,
	    liveSearchStyle: 'contains',
	    actionsBox: false,
	    iconBase: 'glyphicon',
	    tickIcon: 'glyphicon-ok',
	    showTick: false,
	    template: {
	      caret: '<span class="caret"></span>'
	    },
	    maxOptions: false,
	    mobile: false,
	    selectOnTab: false,
	    dropdownAlignRight: false
	  };

	  Selectpicker.prototype = {

	    constructor: Selectpicker,

	    init: function () {
	      var that = this,
	          id = this.$element.attr('id');

	      this.$element.addClass('bs-select-hidden');

	      // store originalIndex (key) and newIndex (value) in this.liObj for fast accessibility
	      // allows us to do this.$lis.eq(that.liObj[index]) instead of this.$lis.filter('[data-original-index="' + index + '"]')
	      this.liObj = {};
	      this.multiple = this.$element.prop('multiple');
	      this.autofocus = this.$element.prop('autofocus');
	      this.$newElement = this.createView();
	      this.$element
	        .after(this.$newElement)
	        .appendTo(this.$newElement);
	      this.$button = this.$newElement.children('button');
	      this.$menu = this.$newElement.children('.dropdown-menu');
	      this.$menuInner = this.$menu.children('.inner');
	      this.$searchbox = this.$menu.find('input');

	      this.$element.removeClass('bs-select-hidden');

	      if (this.options.dropdownAlignRight === true) this.$menu.addClass('dropdown-menu-right');

	      if (typeof id !== 'undefined') {
	        this.$button.attr('data-id', id);
	        $('label[for="' + id + '"]').click(function (e) {
	          e.preventDefault();
	          that.$button.focus();
	        });
	      }

	      this.checkDisabled();
	      this.clickListener();
	      if (this.options.liveSearch) this.liveSearchListener();
	      this.render();
	      this.setStyle();
	      this.setWidth();
	      if (this.options.container) this.selectPosition();
	      this.$menu.data('this', this);
	      this.$newElement.data('this', this);
	      if (this.options.mobile) this.mobile();

	      this.$newElement.on({
	        'hide.bs.dropdown': function (e) {
	          that.$menuInner.attr('aria-expanded', false);
	          that.$element.trigger('hide.bs.select', e);
	        },
	        'hidden.bs.dropdown': function (e) {
	          that.$element.trigger('hidden.bs.select', e);
	        },
	        'show.bs.dropdown': function (e) {
	          that.$menuInner.attr('aria-expanded', true);
	          that.$element.trigger('show.bs.select', e);
	        },
	        'shown.bs.dropdown': function (e) {
	          that.$element.trigger('shown.bs.select', e);
	        }
	      });

	      if (that.$element[0].hasAttribute('required')) {
	        this.$element.on('invalid', function () {
	          that.$button
	            .addClass('bs-invalid')
	            .focus();

	          that.$element.on({
	            'focus.bs.select': function () {
	              that.$button.focus();
	              that.$element.off('focus.bs.select');
	            },
	            'shown.bs.select': function () {
	              that.$element
	                .val(that.$element.val()) // set the value to hide the validation message in Chrome when menu is opened
	                .off('shown.bs.select');
	            },
	            'rendered.bs.select': function () {
	              // if select is no longer invalid, remove the bs-invalid class
	              if (this.validity.valid) that.$button.removeClass('bs-invalid');
	              that.$element.off('rendered.bs.select');
	            }
	          });
	        });
	      }

	      setTimeout(function () {
	        that.$element.trigger('loaded.bs.select');
	      });
	    },

	    createDropdown: function () {
	      // Options
	      // If we are multiple or showTick option is set, then add the show-tick class
	      var showTick = (this.multiple || this.options.showTick) ? ' show-tick' : '',
	          inputGroup = this.$element.parent().hasClass('input-group') ? ' input-group-btn' : '',
	          autofocus = this.autofocus ? ' autofocus' : '';
	      // Elements
	      var header = this.options.header ? '<div class="popover-title"><button type="button" class="close" aria-hidden="true">&times;</button>' + this.options.header + '</div>' : '';
	      var searchbox = this.options.liveSearch ?
	      '<div class="bs-searchbox">' +
	      '<input type="text" class="form-control" autocomplete="off"' +
	      (null === this.options.liveSearchPlaceholder ? '' : ' placeholder="' + htmlEscape(this.options.liveSearchPlaceholder) + '"') + ' role="textbox" aria-label="Search">' +
	      '</div>'
	          : '';
	      var actionsbox = this.multiple && this.options.actionsBox ?
	      '<div class="bs-actionsbox">' +
	      '<div class="btn-group btn-group-sm btn-block">' +
	      '<button type="button" class="actions-btn bs-select-all btn btn-default">' +
	      this.options.selectAllText +
	      '</button>' +
	      '<button type="button" class="actions-btn bs-deselect-all btn btn-default">' +
	      this.options.deselectAllText +
	      '</button>' +
	      '</div>' +
	      '</div>'
	          : '';
	      var donebutton = this.multiple && this.options.doneButton ?
	      '<div class="bs-donebutton">' +
	      '<div class="btn-group btn-block">' +
	      '<button type="button" class="btn btn-sm btn-default">' +
	      this.options.doneButtonText +
	      '</button>' +
	      '</div>' +
	      '</div>'
	          : '';
	      var drop =
	          '<div class="btn-group bootstrap-select' + showTick + inputGroup + '">' +
	          '<button type="button" class="' + this.options.styleBase + ' dropdown-toggle" data-toggle="dropdown"' + autofocus + ' role="button">' +
	          '<span class="filter-option pull-left"></span>&nbsp;' +
	          '<span class="bs-caret">' +
	          this.options.template.caret +
	          '</span>' +
	          '</button>' +
	          '<div class="dropdown-menu open" role="combobox">' +
	          header +
	          searchbox +
	          actionsbox +
	          '<ul class="dropdown-menu inner" role="listbox" aria-expanded="false">' +
	          '</ul>' +
	          donebutton +
	          '</div>' +
	          '</div>';

	      return $(drop);
	    },

	    createView: function () {
	      var $drop = this.createDropdown(),
	          li = this.createLi();

	      $drop.find('ul')[0].innerHTML = li;
	      return $drop;
	    },

	    reloadLi: function () {
	      //Remove all children.
	      this.destroyLi();
	      //Re build
	      var li = this.createLi();
	      this.$menuInner[0].innerHTML = li;
	    },

	    destroyLi: function () {
	      this.$menu.find('li').remove();
	    },

	    createLi: function () {
	      var that = this,
	          _li = [],
	          optID = 0,
	          titleOption = document.createElement('option'),
	          liIndex = -1; // increment liIndex whenever a new <li> element is created to ensure liObj is correct

	      // Helper functions
	      /**
	       * @param content
	       * @param [index]
	       * @param [classes]
	       * @param [optgroup]
	       * @returns {string}
	       */
	      var generateLI = function (content, index, classes, optgroup) {
	        return '<li' +
	            ((typeof classes !== 'undefined' & '' !== classes) ? ' class="' + classes + '"' : '') +
	            ((typeof index !== 'undefined' & null !== index) ? ' data-original-index="' + index + '"' : '') +
	            ((typeof optgroup !== 'undefined' & null !== optgroup) ? 'data-optgroup="' + optgroup + '"' : '') +
	            '>' + content + '</li>';
	      };

	      /**
	       * @param text
	       * @param [classes]
	       * @param [inline]
	       * @param [tokens]
	       * @returns {string}
	       */
	      var generateA = function (text, classes, inline, tokens) {
	        return '<a tabindex="0"' +
	            (typeof classes !== 'undefined' ? ' class="' + classes + '"' : '') +
	            (typeof inline !== 'undefined' ? ' style="' + inline + '"' : '') +
	            (that.options.liveSearchNormalize ? ' data-normalized-text="' + normalizeToBase(htmlEscape(text)) + '"' : '') +
	            (typeof tokens !== 'undefined' || tokens !== null ? ' data-tokens="' + tokens + '"' : '') +
	            ' role="option">' + text +
	            '<span class="' + that.options.iconBase + ' ' + that.options.tickIcon + ' check-mark"></span>' +
	            '</a>';
	      };

	      if (this.options.title && !this.multiple) {
	        // this option doesn't create a new <li> element, but does add a new option, so liIndex is decreased
	        // since liObj is recalculated on every refresh, liIndex needs to be decreased even if the titleOption is already appended
	        liIndex--;

	        if (!this.$element.find('.bs-title-option').length) {
	          // Use native JS to prepend option (faster)
	          var element = this.$element[0];
	          titleOption.className = 'bs-title-option';
	          titleOption.appendChild(document.createTextNode(this.options.title));
	          titleOption.value = '';
	          element.insertBefore(titleOption, element.firstChild);
	          // Check if selected or data-selected attribute is already set on an option. If not, select the titleOption option.
	          // the selected item may have been changed by user or programmatically before the bootstrap select plugin runs,
	          // if so, the select will have the data-selected attribute
	          var $opt = $(element.options[element.selectedIndex]);
	          if ($opt.attr('selected') === undefined && this.$element.data('selected') === undefined) {
	            titleOption.selected = true;
	          }
	        }
	      }

	      this.$element.find('option').each(function (index) {
	        var $this = $(this);

	        liIndex++;

	        if ($this.hasClass('bs-title-option')) return;

	        // Get the class and text for the option
	        var optionClass = this.className || '',
	            inline = this.style.cssText,
	            text = $this.data('content') ? $this.data('content') : $this.html(),
	            tokens = $this.data('tokens') ? $this.data('tokens') : null,
	            subtext = typeof $this.data('subtext') !== 'undefined' ? '<small class="text-muted">' + $this.data('subtext') + '</small>' : '',
	            icon = typeof $this.data('icon') !== 'undefined' ? '<span class="' + that.options.iconBase + ' ' + $this.data('icon') + '"></span> ' : '',
	            $parent = $this.parent(),
	            isOptgroup = $parent[0].tagName === 'OPTGROUP',
	            isOptgroupDisabled = isOptgroup && $parent[0].disabled,
	            isDisabled = this.disabled || isOptgroupDisabled;

	        if (icon !== '' && isDisabled) {
	          icon = '<span>' + icon + '</span>';
	        }

	        if (that.options.hideDisabled && (isDisabled && !isOptgroup || isOptgroupDisabled)) {
	          liIndex--;
	          return;
	        }

	        if (!$this.data('content')) {
	          // Prepend any icon and append any subtext to the main text.
	          text = icon + '<span class="text">' + text + subtext + '</span>';
	        }

	        if (isOptgroup && $this.data('divider') !== true) {
	          if (that.options.hideDisabled && isDisabled) {
	            if ($parent.data('allOptionsDisabled') === undefined) {
	              var $options = $parent.children();
	              $parent.data('allOptionsDisabled', $options.filter(':disabled').length === $options.length);
	            }

	            if ($parent.data('allOptionsDisabled')) {
	              liIndex--;
	              return;
	            }
	          }

	          var optGroupClass = ' ' + $parent[0].className || '';

	          if ($this.index() === 0) { // Is it the first option of the optgroup?
	            optID += 1;

	            // Get the opt group label
	            var label = $parent[0].label,
	                labelSubtext = typeof $parent.data('subtext') !== 'undefined' ? '<small class="text-muted">' + $parent.data('subtext') + '</small>' : '',
	                labelIcon = $parent.data('icon') ? '<span class="' + that.options.iconBase + ' ' + $parent.data('icon') + '"></span> ' : '';

	            label = labelIcon + '<span class="text">' + label + labelSubtext + '</span>';

	            if (index !== 0 && _li.length > 0) { // Is it NOT the first option of the select && are there elements in the dropdown?
	              liIndex++;
	              _li.push(generateLI('', null, 'divider', optID + 'div'));
	            }
	            liIndex++;
	            _li.push(generateLI(label, null, 'dropdown-header' + optGroupClass, optID));
	          }

	          if (that.options.hideDisabled && isDisabled) {
	            liIndex--;
	            return;
	          }

	          _li.push(generateLI(generateA(text, 'opt ' + optionClass + optGroupClass, inline, tokens), index, '', optID));
	        } else if ($this.data('divider') === true) {
	          _li.push(generateLI('', index, 'divider'));
	        } else if ($this.data('hidden') === true) {
	          _li.push(generateLI(generateA(text, optionClass, inline, tokens), index, 'hidden is-hidden'));
	        } else {
	          var showDivider = this.previousElementSibling && this.previousElementSibling.tagName === 'OPTGROUP';

	          // if previous element is not an optgroup and hideDisabled is true
	          if (!showDivider && that.options.hideDisabled) {
	            // get previous elements
	            var $prev = $(this).prevAll();

	            for (var i = 0; i < $prev.length; i++) {
	              // find the first element in the previous elements that is an optgroup
	              if ($prev[i].tagName === 'OPTGROUP') {
	                var optGroupDistance = 0;

	                // loop through the options in between the current option and the optgroup
	                // and check if they are hidden or disabled
	                for (var d = 0; d < i; d++) {
	                  var prevOption = $prev[d];
	                  if (prevOption.disabled || $(prevOption).data('hidden') === true) optGroupDistance++;
	                }

	                // if all of the options between the current option and the optgroup are hidden or disabled, show the divider
	                if (optGroupDistance === i) showDivider = true;

	                break;
	              }
	            }
	          }

	          if (showDivider) {
	            liIndex++;
	            _li.push(generateLI('', null, 'divider', optID + 'div'));
	          }
	          _li.push(generateLI(generateA(text, optionClass, inline, tokens), index));
	        }

	        that.liObj[index] = liIndex;
	      });

	      //If we are not multiple, we don't have a selected item, and we don't have a title, select the first element so something is set in the button
	      if (!this.multiple && this.$element.find('option:selected').length === 0 && !this.options.title) {
	        this.$element.find('option').eq(0).prop('selected', true).attr('selected', 'selected');
	      }

	      return _li.join('');
	    },

	    findLis: function () {
	      if (this.$lis == null) this.$lis = this.$menu.find('li');
	      return this.$lis;
	    },

	    /**
	     * @param [updateLi] defaults to true
	     */
	    render: function (updateLi) {
	      var that = this,
	          notDisabled;

	      //Update the LI to match the SELECT
	      if (updateLi !== false) {
	        this.$element.find('option').each(function (index) {
	          var $lis = that.findLis().eq(that.liObj[index]);

	          that.setDisabled(index, this.disabled || this.parentNode.tagName === 'OPTGROUP' && this.parentNode.disabled, $lis);
	          that.setSelected(index, this.selected, $lis);
	        });
	      }

	      this.togglePlaceholder();

	      this.tabIndex();

	      var selectedItems = this.$element.find('option').map(function () {
	        if (this.selected) {
	          if (that.options.hideDisabled && (this.disabled || this.parentNode.tagName === 'OPTGROUP' && this.parentNode.disabled)) return;

	          var $this = $(this),
	              icon = $this.data('icon') && that.options.showIcon ? '<i class="' + that.options.iconBase + ' ' + $this.data('icon') + '"></i> ' : '',
	              subtext;

	          if (that.options.showSubtext && $this.data('subtext') && !that.multiple) {
	            subtext = ' <small class="text-muted">' + $this.data('subtext') + '</small>';
	          } else {
	            subtext = '';
	          }
	          if (typeof $this.attr('title') !== 'undefined') {
	            return $this.attr('title');
	          } else if ($this.data('content') && that.options.showContent) {
	            return $this.data('content');
	          } else {
	            return icon + $this.html() + subtext;
	          }
	        }
	      }).toArray();

	      //Fixes issue in IE10 occurring when no default option is selected and at least one option is disabled
	      //Convert all the values into a comma delimited string
	      var title = !this.multiple ? selectedItems[0] : selectedItems.join(this.options.multipleSeparator);

	      //If this is multi select, and the selectText type is count, the show 1 of 2 selected etc..
	      if (this.multiple && this.options.selectedTextFormat.indexOf('count') > -1) {
	        var max = this.options.selectedTextFormat.split('>');
	        if ((max.length > 1 && selectedItems.length > max[1]) || (max.length == 1 && selectedItems.length >= 2)) {
	          notDisabled = this.options.hideDisabled ? ', [disabled]' : '';
	          var totalCount = this.$element.find('option').not('[data-divider="true"], [data-hidden="true"]' + notDisabled).length,
	              tr8nText = (typeof this.options.countSelectedText === 'function') ? this.options.countSelectedText(selectedItems.length, totalCount) : this.options.countSelectedText;
	          title = tr8nText.replace('{0}', selectedItems.length.toString()).replace('{1}', totalCount.toString());
	        }
	      }

	      if (this.options.title == undefined) {
	        this.options.title = this.$element.attr('title');
	      }

	      if (this.options.selectedTextFormat == 'static') {
	        title = this.options.title;
	      }

	      //If we dont have a title, then use the default, or if nothing is set at all, use the not selected text
	      if (!title) {
	        title = typeof this.options.title !== 'undefined' ? this.options.title : this.options.noneSelectedText;
	      }

	      //strip all html-tags and trim the result
	      this.$button.attr('title', $.trim(title.replace(/<[^>]*>?/g, '')));
	      this.$button.children('.filter-option').html(title);

	      this.$element.trigger('rendered.bs.select');
	    },

	    /**
	     * @param [style]
	     * @param [status]
	     */
	    setStyle: function (style, status) {
	      if (this.$element.attr('class')) {
	        this.$newElement.addClass(this.$element.attr('class').replace(/selectpicker|mobile-device|bs-select-hidden|validate\[.*\]/gi, ''));
	      }

	      var buttonClass = style ? style : this.options.style;

	      if (status == 'add') {
	        this.$button.addClass(buttonClass);
	      } else if (status == 'remove') {
	        this.$button.removeClass(buttonClass);
	      } else {
	        this.$button.removeClass(this.options.style);
	        this.$button.addClass(buttonClass);
	      }
	    },

	    liHeight: function (refresh) {
	      if (!refresh && (this.options.size === false || this.sizeInfo)) return;

	      var newElement = document.createElement('div'),
	          menu = document.createElement('div'),
	          menuInner = document.createElement('ul'),
	          divider = document.createElement('li'),
	          li = document.createElement('li'),
	          a = document.createElement('a'),
	          text = document.createElement('span'),
	          header = this.options.header && this.$menu.find('.popover-title').length > 0 ? this.$menu.find('.popover-title')[0].cloneNode(true) : null,
	          search = this.options.liveSearch ? document.createElement('div') : null,
	          actions = this.options.actionsBox && this.multiple && this.$menu.find('.bs-actionsbox').length > 0 ? this.$menu.find('.bs-actionsbox')[0].cloneNode(true) : null,
	          doneButton = this.options.doneButton && this.multiple && this.$menu.find('.bs-donebutton').length > 0 ? this.$menu.find('.bs-donebutton')[0].cloneNode(true) : null;

	      text.className = 'text';
	      newElement.className = this.$menu[0].parentNode.className + ' open';
	      menu.className = 'dropdown-menu open';
	      menuInner.className = 'dropdown-menu inner';
	      divider.className = 'divider';

	      text.appendChild(document.createTextNode('Inner text'));
	      a.appendChild(text);
	      li.appendChild(a);
	      menuInner.appendChild(li);
	      menuInner.appendChild(divider);
	      if (header) menu.appendChild(header);
	      if (search) {
	        // create a span instead of input as creating an input element is slower
	        var input = document.createElement('span');
	        search.className = 'bs-searchbox';
	        input.className = 'form-control';
	        search.appendChild(input);
	        menu.appendChild(search);
	      }
	      if (actions) menu.appendChild(actions);
	      menu.appendChild(menuInner);
	      if (doneButton) menu.appendChild(doneButton);
	      newElement.appendChild(menu);

	      document.body.appendChild(newElement);

	      var liHeight = a.offsetHeight,
	          headerHeight = header ? header.offsetHeight : 0,
	          searchHeight = search ? search.offsetHeight : 0,
	          actionsHeight = actions ? actions.offsetHeight : 0,
	          doneButtonHeight = doneButton ? doneButton.offsetHeight : 0,
	          dividerHeight = $(divider).outerHeight(true),
	          // fall back to jQuery if getComputedStyle is not supported
	          menuStyle = typeof getComputedStyle === 'function' ? getComputedStyle(menu) : false,
	          $menu = menuStyle ? null : $(menu),
	          menuPadding = {
	            vert: parseInt(menuStyle ? menuStyle.paddingTop : $menu.css('paddingTop')) +
	                  parseInt(menuStyle ? menuStyle.paddingBottom : $menu.css('paddingBottom')) +
	                  parseInt(menuStyle ? menuStyle.borderTopWidth : $menu.css('borderTopWidth')) +
	                  parseInt(menuStyle ? menuStyle.borderBottomWidth : $menu.css('borderBottomWidth')),
	            horiz: parseInt(menuStyle ? menuStyle.paddingLeft : $menu.css('paddingLeft')) +
	                  parseInt(menuStyle ? menuStyle.paddingRight : $menu.css('paddingRight')) +
	                  parseInt(menuStyle ? menuStyle.borderLeftWidth : $menu.css('borderLeftWidth')) +
	                  parseInt(menuStyle ? menuStyle.borderRightWidth : $menu.css('borderRightWidth'))
	          },
	          menuExtras =  {
	            vert: menuPadding.vert +
	                  parseInt(menuStyle ? menuStyle.marginTop : $menu.css('marginTop')) +
	                  parseInt(menuStyle ? menuStyle.marginBottom : $menu.css('marginBottom')) + 2,
	            horiz: menuPadding.horiz +
	                  parseInt(menuStyle ? menuStyle.marginLeft : $menu.css('marginLeft')) +
	                  parseInt(menuStyle ? menuStyle.marginRight : $menu.css('marginRight')) + 2
	          }

	      document.body.removeChild(newElement);

	      this.sizeInfo = {
	        liHeight: liHeight,
	        headerHeight: headerHeight,
	        searchHeight: searchHeight,
	        actionsHeight: actionsHeight,
	        doneButtonHeight: doneButtonHeight,
	        dividerHeight: dividerHeight,
	        menuPadding: menuPadding,
	        menuExtras: menuExtras
	      };
	    },

	    setSize: function () {
	      this.findLis();
	      this.liHeight();

	      if (this.options.header) this.$menu.css('padding-top', 0);
	      if (this.options.size === false) return;

	      var that = this,
	          $menu = this.$menu,
	          $menuInner = this.$menuInner,
	          $window = $(window),
	          selectHeight = this.$newElement[0].offsetHeight,
	          selectWidth = this.$newElement[0].offsetWidth,
	          liHeight = this.sizeInfo['liHeight'],
	          headerHeight = this.sizeInfo['headerHeight'],
	          searchHeight = this.sizeInfo['searchHeight'],
	          actionsHeight = this.sizeInfo['actionsHeight'],
	          doneButtonHeight = this.sizeInfo['doneButtonHeight'],
	          divHeight = this.sizeInfo['dividerHeight'],
	          menuPadding = this.sizeInfo['menuPadding'],
	          menuExtras = this.sizeInfo['menuExtras'],
	          notDisabled = this.options.hideDisabled ? '.disabled' : '',
	          menuHeight,
	          menuWidth,
	          getHeight,
	          getWidth,
	          selectOffsetTop,
	          selectOffsetBot,
	          selectOffsetLeft,
	          selectOffsetRight,
	          getPos = function() {
	            var pos = that.$newElement.offset(),
	                $container = $(that.options.container),
	                containerPos;

	            if (that.options.container && !$container.is('body')) {
	              containerPos = $container.offset();
	              containerPos.top += parseInt($container.css('borderTopWidth'));
	              containerPos.left += parseInt($container.css('borderLeftWidth'));
	            } else {
	              containerPos = { top: 0, left: 0 };
	            }

	            selectOffsetTop = pos.top - containerPos.top - $window.scrollTop();
	            selectOffsetBot = $window.height() - selectOffsetTop - selectHeight - containerPos.top;
	            selectOffsetLeft = pos.left - containerPos.left - $window.scrollLeft();
	            selectOffsetRight = $window.width() - selectOffsetLeft - selectWidth - containerPos.left;
	          };

	      getPos();

	      if (this.options.size === 'auto') {
	        var getSize = function () {
	          var minHeight,
	              hasClass = function (className, include) {
	                return function (element) {
	                    if (include) {
	                        return (element.classList ? element.classList.contains(className) : $(element).hasClass(className));
	                    } else {
	                        return !(element.classList ? element.classList.contains(className) : $(element).hasClass(className));
	                    }
	                };
	              },
	              lis = that.$menuInner[0].getElementsByTagName('li'),
	              lisVisible = Array.prototype.filter ? Array.prototype.filter.call(lis, hasClass('hidden', false)) : that.$lis.not('.hidden'),
	              optGroup = Array.prototype.filter ? Array.prototype.filter.call(lisVisible, hasClass('dropdown-header', true)) : lisVisible.filter('.dropdown-header');

	          getPos();
	          menuHeight = selectOffsetBot - menuExtras.vert;
	          menuWidth = selectOffsetRight - menuExtras.horiz;

	          if (that.options.container) {
	            if (!$menu.data('height')) $menu.data('height', $menu.height());
	            getHeight = $menu.data('height');

	            if (!$menu.data('width')) $menu.data('width', $menu.width());
	            getWidth = $menu.data('width');
	          } else {
	            getHeight = $menu.height();
	            getWidth = $menu.width();
	          }

	          if (that.options.dropupAuto) {
	            that.$newElement.toggleClass('dropup', selectOffsetTop > selectOffsetBot && (menuHeight - menuExtras.vert) < getHeight);
	          }

	          if (that.$newElement.hasClass('dropup')) {
	            menuHeight = selectOffsetTop - menuExtras.vert;
	          }

	          if (that.options.dropdownAlignRight === 'auto') {
	            $menu.toggleClass('dropdown-menu-right', selectOffsetLeft > selectOffsetRight && (menuWidth - menuExtras.horiz) < (getWidth - selectWidth));
	          }

	          if ((lisVisible.length + optGroup.length) > 3) {
	            minHeight = liHeight * 3 + menuExtras.vert - 2;
	          } else {
	            minHeight = 0;
	          }

	          $menu.css({
	            'max-height': menuHeight + 'px',
	            'overflow': 'hidden',
	            'min-height': minHeight + headerHeight + searchHeight + actionsHeight + doneButtonHeight + 'px'
	          });
	          $menuInner.css({
	            'max-height': menuHeight - headerHeight - searchHeight - actionsHeight - doneButtonHeight - menuPadding.vert + 'px',
	            'overflow-y': 'auto',
	            'min-height': Math.max(minHeight - menuPadding.vert, 0) + 'px'
	          });
	        };
	        getSize();
	        this.$searchbox.off('input.getSize propertychange.getSize').on('input.getSize propertychange.getSize', getSize);
	        $window.off('resize.getSize scroll.getSize').on('resize.getSize scroll.getSize', getSize);
	      } else if (this.options.size && this.options.size != 'auto' && this.$lis.not(notDisabled).length > this.options.size) {
	        var optIndex = this.$lis.not('.divider').not(notDisabled).children().slice(0, this.options.size).last().parent().index(),
	            divLength = this.$lis.slice(0, optIndex + 1).filter('.divider').length;
	        menuHeight = liHeight * this.options.size + divLength * divHeight + menuPadding.vert;

	        if (that.options.container) {
	          if (!$menu.data('height')) $menu.data('height', $menu.height());
	          getHeight = $menu.data('height');
	        } else {
	          getHeight = $menu.height();
	        }

	        if (that.options.dropupAuto) {
	          //noinspection JSUnusedAssignment
	          this.$newElement.toggleClass('dropup', selectOffsetTop > selectOffsetBot && (menuHeight - menuExtras.vert) < getHeight);
	        }
	        $menu.css({
	          'max-height': menuHeight + headerHeight + searchHeight + actionsHeight + doneButtonHeight + 'px',
	          'overflow': 'hidden',
	          'min-height': ''
	        });
	        $menuInner.css({
	          'max-height': menuHeight - menuPadding.vert + 'px',
	          'overflow-y': 'auto',
	          'min-height': ''
	        });
	      }
	    },

	    setWidth: function () {
	      if (this.options.width === 'auto') {
	        this.$menu.css('min-width', '0');

	        // Get correct width if element is hidden
	        var $selectClone = this.$menu.parent().clone().appendTo('body'),
	            $selectClone2 = this.options.container ? this.$newElement.clone().appendTo('body') : $selectClone,
	            ulWidth = $selectClone.children('.dropdown-menu').outerWidth(),
	            btnWidth = $selectClone2.css('width', 'auto').children('button').outerWidth();

	        $selectClone.remove();
	        $selectClone2.remove();

	        // Set width to whatever's larger, button title or longest option
	        this.$newElement.css('width', Math.max(ulWidth, btnWidth) + 'px');
	      } else if (this.options.width === 'fit') {
	        // Remove inline min-width so width can be changed from 'auto'
	        this.$menu.css('min-width', '');
	        this.$newElement.css('width', '').addClass('fit-width');
	      } else if (this.options.width) {
	        // Remove inline min-width so width can be changed from 'auto'
	        this.$menu.css('min-width', '');
	        this.$newElement.css('width', this.options.width);
	      } else {
	        // Remove inline min-width/width so width can be changed
	        this.$menu.css('min-width', '');
	        this.$newElement.css('width', '');
	      }
	      // Remove fit-width class if width is changed programmatically
	      if (this.$newElement.hasClass('fit-width') && this.options.width !== 'fit') {
	        this.$newElement.removeClass('fit-width');
	      }
	    },

	    selectPosition: function () {
	      this.$bsContainer = $('<div class="bs-container" />');

	      var that = this,
	          $container = $(this.options.container),
	          pos,
	          containerPos,
	          actualHeight,
	          getPlacement = function ($element) {
	            that.$bsContainer.addClass($element.attr('class').replace(/form-control|fit-width/gi, '')).toggleClass('dropup', $element.hasClass('dropup'));
	            pos = $element.offset();

	            if (!$container.is('body')) {
	              containerPos = $container.offset();
	              containerPos.top += parseInt($container.css('borderTopWidth')) - $container.scrollTop();
	              containerPos.left += parseInt($container.css('borderLeftWidth')) - $container.scrollLeft();
	            } else {
	              containerPos = { top: 0, left: 0 };
	            }

	            actualHeight = $element.hasClass('dropup') ? 0 : $element[0].offsetHeight;

	            that.$bsContainer.css({
	              'top': pos.top - containerPos.top + actualHeight,
	              'left': pos.left - containerPos.left,
	              'width': $element[0].offsetWidth
	            });
	          };

	      this.$button.on('click', function () {
	        var $this = $(this);

	        if (that.isDisabled()) {
	          return;
	        }

	        getPlacement(that.$newElement);

	        that.$bsContainer
	          .appendTo(that.options.container)
	          .toggleClass('open', !$this.hasClass('open'))
	          .append(that.$menu);
	      });

	      $(window).on('resize scroll', function () {
	        getPlacement(that.$newElement);
	      });

	      this.$element.on('hide.bs.select', function () {
	        that.$menu.data('height', that.$menu.height());
	        that.$bsContainer.detach();
	      });
	    },

	    /**
	     * @param {number} index - the index of the option that is being changed
	     * @param {boolean} selected - true if the option is being selected, false if being deselected
	     * @param {JQuery} $lis - the 'li' element that is being modified
	     */
	    setSelected: function (index, selected, $lis) {
	      if (!$lis) {
	        this.togglePlaceholder(); // check if setSelected is being called by changing the value of the select
	        $lis = this.findLis().eq(this.liObj[index]);
	      }

	      $lis.toggleClass('selected', selected).find('a').attr('aria-selected', selected);
	    },

	    /**
	     * @param {number} index - the index of the option that is being disabled
	     * @param {boolean} disabled - true if the option is being disabled, false if being enabled
	     * @param {JQuery} $lis - the 'li' element that is being modified
	     */
	    setDisabled: function (index, disabled, $lis) {
	      if (!$lis) {
	        $lis = this.findLis().eq(this.liObj[index]);
	      }

	      if (disabled) {
	        $lis.addClass('disabled').children('a').attr('href', '#').attr('tabindex', -1).attr('aria-disabled', true);
	      } else {
	        $lis.removeClass('disabled').children('a').removeAttr('href').attr('tabindex', 0).attr('aria-disabled', false);
	      }
	    },

	    isDisabled: function () {
	      return this.$element[0].disabled;
	    },

	    checkDisabled: function () {
	      var that = this;

	      if (this.isDisabled()) {
	        this.$newElement.addClass('disabled');
	        this.$button.addClass('disabled').attr('tabindex', -1);
	      } else {
	        if (this.$button.hasClass('disabled')) {
	          this.$newElement.removeClass('disabled');
	          this.$button.removeClass('disabled');
	        }

	        if (this.$button.attr('tabindex') == -1 && !this.$element.data('tabindex')) {
	          this.$button.removeAttr('tabindex');
	        }
	      }

	      this.$button.click(function () {
	        return !that.isDisabled();
	      });
	    },

	    togglePlaceholder: function () {
	      var value = this.$element.val();
	      this.$button.toggleClass('bs-placeholder', value === null || value === '');
	    },

	    tabIndex: function () {
	      if (this.$element.data('tabindex') !== this.$element.attr('tabindex') && 
	        (this.$element.attr('tabindex') !== -98 && this.$element.attr('tabindex') !== '-98')) {
	        this.$element.data('tabindex', this.$element.attr('tabindex'));
	        this.$button.attr('tabindex', this.$element.data('tabindex'));
	      }

	      this.$element.attr('tabindex', -98);
	    },

	    clickListener: function () {
	      var that = this,
	          $document = $(document);

	      this.$newElement.on('touchstart.dropdown', '.dropdown-menu', function (e) {
	        e.stopPropagation();
	      });

	      $document.data('spaceSelect', false);

	      this.$button.on('keyup', function (e) {
	        if (/(32)/.test(e.keyCode.toString(10)) && $document.data('spaceSelect')) {
	            e.preventDefault();
	            $document.data('spaceSelect', false);
	        }
	      });

	      this.$button.on('click', function () {
	        that.setSize();
	      });

	      this.$element.on('shown.bs.select', function () {
	        if (!that.options.liveSearch && !that.multiple) {
	          that.$menuInner.find('.selected a').focus();
	        } else if (!that.multiple) {
	          var selectedIndex = that.liObj[that.$element[0].selectedIndex];

	          if (typeof selectedIndex !== 'number' || that.options.size === false) return;

	          // scroll to selected option
	          var offset = that.$lis.eq(selectedIndex)[0].offsetTop - that.$menuInner[0].offsetTop;
	          offset = offset - that.$menuInner[0].offsetHeight/2 + that.sizeInfo.liHeight/2;
	          that.$menuInner[0].scrollTop = offset;
	        }
	      });

	      this.$menuInner.on('click', 'li a', function (e) {
	        var $this = $(this),
	            clickedIndex = $this.parent().data('originalIndex'),
	            prevValue = that.$element.val(),
	            prevIndex = that.$element.prop('selectedIndex'),
	            triggerChange = true;

	        // Don't close on multi choice menu
	        if (that.multiple && that.options.maxOptions !== 1) {
	          e.stopPropagation();
	        }

	        e.preventDefault();

	        //Don't run if we have been disabled
	        if (!that.isDisabled() && !$this.parent().hasClass('disabled')) {
	          var $options = that.$element.find('option'),
	              $option = $options.eq(clickedIndex),
	              state = $option.prop('selected'),
	              $optgroup = $option.parent('optgroup'),
	              maxOptions = that.options.maxOptions,
	              maxOptionsGrp = $optgroup.data('maxOptions') || false;

	          if (!that.multiple) { // Deselect all others if not multi select box
	            $options.prop('selected', false);
	            $option.prop('selected', true);
	            that.$menuInner.find('.selected').removeClass('selected').find('a').attr('aria-selected', false);
	            that.setSelected(clickedIndex, true);
	          } else { // Toggle the one we have chosen if we are multi select.
	            $option.prop('selected', !state);
	            that.setSelected(clickedIndex, !state);
	            $this.blur();

	            if (maxOptions !== false || maxOptionsGrp !== false) {
	              var maxReached = maxOptions < $options.filter(':selected').length,
	                  maxReachedGrp = maxOptionsGrp < $optgroup.find('option:selected').length;

	              if ((maxOptions && maxReached) || (maxOptionsGrp && maxReachedGrp)) {
	                if (maxOptions && maxOptions == 1) {
	                  $options.prop('selected', false);
	                  $option.prop('selected', true);
	                  that.$menuInner.find('.selected').removeClass('selected');
	                  that.setSelected(clickedIndex, true);
	                } else if (maxOptionsGrp && maxOptionsGrp == 1) {
	                  $optgroup.find('option:selected').prop('selected', false);
	                  $option.prop('selected', true);
	                  var optgroupID = $this.parent().data('optgroup');
	                  that.$menuInner.find('[data-optgroup="' + optgroupID + '"]').removeClass('selected');
	                  that.setSelected(clickedIndex, true);
	                } else {
	                  var maxOptionsText = typeof that.options.maxOptionsText === 'string' ? [that.options.maxOptionsText, that.options.maxOptionsText] : that.options.maxOptionsText,
	                      maxOptionsArr = typeof maxOptionsText === 'function' ? maxOptionsText(maxOptions, maxOptionsGrp) : maxOptionsText,
	                      maxTxt = maxOptionsArr[0].replace('{n}', maxOptions),
	                      maxTxtGrp = maxOptionsArr[1].replace('{n}', maxOptionsGrp),
	                      $notify = $('<div class="notify"></div>');
	                  // If {var} is set in array, replace it
	                  /** @deprecated */
	                  if (maxOptionsArr[2]) {
	                    maxTxt = maxTxt.replace('{var}', maxOptionsArr[2][maxOptions > 1 ? 0 : 1]);
	                    maxTxtGrp = maxTxtGrp.replace('{var}', maxOptionsArr[2][maxOptionsGrp > 1 ? 0 : 1]);
	                  }

	                  $option.prop('selected', false);

	                  that.$menu.append($notify);

	                  if (maxOptions && maxReached) {
	                    $notify.append($('<div>' + maxTxt + '</div>'));
	                    triggerChange = false;
	                    that.$element.trigger('maxReached.bs.select');
	                  }

	                  if (maxOptionsGrp && maxReachedGrp) {
	                    $notify.append($('<div>' + maxTxtGrp + '</div>'));
	                    triggerChange = false;
	                    that.$element.trigger('maxReachedGrp.bs.select');
	                  }

	                  setTimeout(function () {
	                    that.setSelected(clickedIndex, false);
	                  }, 10);

	                  $notify.delay(750).fadeOut(300, function () {
	                    $(this).remove();
	                  });
	                }
	              }
	            }
	          }

	          if (!that.multiple || (that.multiple && that.options.maxOptions === 1)) {
	            that.$button.focus();
	          } else if (that.options.liveSearch) {
	            that.$searchbox.focus();
	          }

	          // Trigger select 'change'
	          if (triggerChange) {
	            if ((prevValue != that.$element.val() && that.multiple) || (prevIndex != that.$element.prop('selectedIndex') && !that.multiple)) {
	              // $option.prop('selected') is current option state (selected/unselected). state is previous option state.
	              changed_arguments = [clickedIndex, $option.prop('selected'), state];
	              that.$element
	                .triggerNative('change');
	            }
	          }
	        }
	      });

	      this.$menu.on('click', 'li.disabled a, .popover-title, .popover-title :not(.close)', function (e) {
	        if (e.currentTarget == this) {
	          e.preventDefault();
	          e.stopPropagation();
	          if (that.options.liveSearch && !$(e.target).hasClass('close')) {
	            that.$searchbox.focus();
	          } else {
	            that.$button.focus();
	          }
	        }
	      });

	      this.$menuInner.on('click', '.divider, .dropdown-header', function (e) {
	        e.preventDefault();
	        e.stopPropagation();
	        if (that.options.liveSearch) {
	          that.$searchbox.focus();
	        } else {
	          that.$button.focus();
	        }
	      });

	      this.$menu.on('click', '.popover-title .close', function () {
	        that.$button.click();
	      });

	      this.$searchbox.on('click', function (e) {
	        e.stopPropagation();
	      });

	      this.$menu.on('click', '.actions-btn', function (e) {
	        if (that.options.liveSearch) {
	          that.$searchbox.focus();
	        } else {
	          that.$button.focus();
	        }

	        e.preventDefault();
	        e.stopPropagation();

	        if ($(this).hasClass('bs-select-all')) {
	          that.selectAll();
	        } else {
	          that.deselectAll();
	        }
	      });

	      this.$element.change(function () {
	        that.render(false);
	        that.$element.trigger('changed.bs.select', changed_arguments);
	        changed_arguments = null;
	      });
	    },

	    liveSearchListener: function () {
	      var that = this,
	          $no_results = $('<li class="no-results"></li>');

	      this.$button.on('click.dropdown.data-api touchstart.dropdown.data-api', function () {
	        that.$menuInner.find('.active').removeClass('active');
	        if (!!that.$searchbox.val()) {
	          that.$searchbox.val('');
	          that.$lis.not('.is-hidden').removeClass('hidden');
	          if (!!$no_results.parent().length) $no_results.remove();
	        }
	        if (!that.multiple) that.$menuInner.find('.selected').addClass('active');
	        setTimeout(function () {
	          that.$searchbox.focus();
	        }, 10);
	      });

	      this.$searchbox.on('click.dropdown.data-api focus.dropdown.data-api touchend.dropdown.data-api', function (e) {
	        e.stopPropagation();
	      });

	      this.$searchbox.on('input propertychange', function () {
	        if (that.$searchbox.val()) {
	          var $searchBase = that.$lis.not('.is-hidden').removeClass('hidden').children('a');
	          if (that.options.liveSearchNormalize) {
	            $searchBase = $searchBase.not(':a' + that._searchStyle() + '("' + normalizeToBase(that.$searchbox.val()) + '")');
	          } else {
	            $searchBase = $searchBase.not(':' + that._searchStyle() + '("' + that.$searchbox.val() + '")');
	          }
	          $searchBase.parent().addClass('hidden');

	          that.$lis.filter('.dropdown-header').each(function () {
	            var $this = $(this),
	                optgroup = $this.data('optgroup');

	            if (that.$lis.filter('[data-optgroup=' + optgroup + ']').not($this).not('.hidden').length === 0) {
	              $this.addClass('hidden');
	              that.$lis.filter('[data-optgroup=' + optgroup + 'div]').addClass('hidden');
	            }
	          });

	          var $lisVisible = that.$lis.not('.hidden');

	          // hide divider if first or last visible, or if followed by another divider
	          $lisVisible.each(function (index) {
	            var $this = $(this);

	            if ($this.hasClass('divider') && (
	              $this.index() === $lisVisible.first().index() ||
	              $this.index() === $lisVisible.last().index() ||
	              $lisVisible.eq(index + 1).hasClass('divider'))) {
	              $this.addClass('hidden');
	            }
	          });

	          if (!that.$lis.not('.hidden, .no-results').length) {
	            if (!!$no_results.parent().length) {
	              $no_results.remove();
	            }
	            $no_results.html(that.options.noneResultsText.replace('{0}', '"' + htmlEscape(that.$searchbox.val()) + '"')).show();
	            that.$menuInner.append($no_results);
	          } else if (!!$no_results.parent().length) {
	            $no_results.remove();
	          }
	        } else {
	          that.$lis.not('.is-hidden').removeClass('hidden');
	          if (!!$no_results.parent().length) {
	            $no_results.remove();
	          }
	        }

	        that.$lis.filter('.active').removeClass('active');
	        if (that.$searchbox.val()) that.$lis.not('.hidden, .divider, .dropdown-header').eq(0).addClass('active').children('a').focus();
	        $(this).focus();
	      });
	    },

	    _searchStyle: function () {
	      var styles = {
	        begins: 'ibegins',
	        startsWith: 'ibegins'
	      };

	      return styles[this.options.liveSearchStyle] || 'icontains';
	    },

	    val: function (value) {
	      if (typeof value !== 'undefined') {
	        this.$element.val(value);
	        this.render();

	        return this.$element;
	      } else {
	        return this.$element.val();
	      }
	    },

	    changeAll: function (status) {
	      if (!this.multiple) return;
	      if (typeof status === 'undefined') status = true;

	      this.findLis();

	      var $options = this.$element.find('option'),
	          $lisVisible = this.$lis.not('.divider, .dropdown-header, .disabled, .hidden'),
	          lisVisLen = $lisVisible.length,
	          selectedOptions = [];
	          
	      if (status) {
	        if ($lisVisible.filter('.selected').length === $lisVisible.length) return;
	      } else {
	        if ($lisVisible.filter('.selected').length === 0) return;
	      }
	          
	      $lisVisible.toggleClass('selected', status);

	      for (var i = 0; i < lisVisLen; i++) {
	        var origIndex = $lisVisible[i].getAttribute('data-original-index');
	        selectedOptions[selectedOptions.length] = $options.eq(origIndex)[0];
	      }

	      $(selectedOptions).prop('selected', status);

	      this.render(false);

	      this.togglePlaceholder();

	      this.$element
	        .triggerNative('change');
	    },

	    selectAll: function () {
	      return this.changeAll(true);
	    },

	    deselectAll: function () {
	      return this.changeAll(false);
	    },

	    toggle: function (e) {
	      e = e || window.event;

	      if (e) e.stopPropagation();

	      this.$button.trigger('click');
	    },

	    keydown: function (e) {
	      var $this = $(this),
	          $parent = $this.is('input') ? $this.parent().parent() : $this.parent(),
	          $items,
	          that = $parent.data('this'),
	          index,
	          next,
	          first,
	          last,
	          prev,
	          nextPrev,
	          prevIndex,
	          isActive,
	          selector = ':not(.disabled, .hidden, .dropdown-header, .divider)',
	          keyCodeMap = {
	            32: ' ',
	            48: '0',
	            49: '1',
	            50: '2',
	            51: '3',
	            52: '4',
	            53: '5',
	            54: '6',
	            55: '7',
	            56: '8',
	            57: '9',
	            59: ';',
	            65: 'a',
	            66: 'b',
	            67: 'c',
	            68: 'd',
	            69: 'e',
	            70: 'f',
	            71: 'g',
	            72: 'h',
	            73: 'i',
	            74: 'j',
	            75: 'k',
	            76: 'l',
	            77: 'm',
	            78: 'n',
	            79: 'o',
	            80: 'p',
	            81: 'q',
	            82: 'r',
	            83: 's',
	            84: 't',
	            85: 'u',
	            86: 'v',
	            87: 'w',
	            88: 'x',
	            89: 'y',
	            90: 'z',
	            96: '0',
	            97: '1',
	            98: '2',
	            99: '3',
	            100: '4',
	            101: '5',
	            102: '6',
	            103: '7',
	            104: '8',
	            105: '9'
	          };

	      if (that.options.liveSearch) $parent = $this.parent().parent();

	      if (that.options.container) $parent = that.$menu;

	      $items = $('[role="listbox"] li', $parent);

	      isActive = that.$newElement.hasClass('open');

	      if (!isActive && (e.keyCode >= 48 && e.keyCode <= 57 || e.keyCode >= 96 && e.keyCode <= 105 || e.keyCode >= 65 && e.keyCode <= 90)) {
	        if (!that.options.container) {
	          that.setSize();
	          that.$menu.parent().addClass('open');
	          isActive = true;
	        } else {
	          that.$button.trigger('click');
	        }
	        that.$searchbox.focus();
	        return;
	      }

	      if (that.options.liveSearch) {
	        if (/(^9$|27)/.test(e.keyCode.toString(10)) && isActive) {
	          e.preventDefault();
	          e.stopPropagation();
	          that.$button.click().focus();
	        }
	        // $items contains li elements when liveSearch is enabled
	        $items = $('[role="listbox"] li' + selector, $parent);
	        if (!$this.val() && !/(38|40)/.test(e.keyCode.toString(10))) {
	          if ($items.filter('.active').length === 0) {
	            $items = that.$menuInner.find('li');
	            if (that.options.liveSearchNormalize) {
	              $items = $items.filter(':a' + that._searchStyle() + '(' + normalizeToBase(keyCodeMap[e.keyCode]) + ')');
	            } else {
	              $items = $items.filter(':' + that._searchStyle() + '(' + keyCodeMap[e.keyCode] + ')');
	            }
	          }
	        }
	      }

	      if (!$items.length) return;

	      if (/(38|40)/.test(e.keyCode.toString(10))) {
	        index = $items.index($items.find('a').filter(':focus').parent());
	        first = $items.filter(selector).first().index();
	        last = $items.filter(selector).last().index();
	        next = $items.eq(index).nextAll(selector).eq(0).index();
	        prev = $items.eq(index).prevAll(selector).eq(0).index();
	        nextPrev = $items.eq(next).prevAll(selector).eq(0).index();

	        if (that.options.liveSearch) {
	          $items.each(function (i) {
	            if (!$(this).hasClass('disabled')) {
	              $(this).data('index', i);
	            }
	          });
	          index = $items.index($items.filter('.active'));
	          first = $items.first().data('index');
	          last = $items.last().data('index');
	          next = $items.eq(index).nextAll().eq(0).data('index');
	          prev = $items.eq(index).prevAll().eq(0).data('index');
	          nextPrev = $items.eq(next).prevAll().eq(0).data('index');
	        }

	        prevIndex = $this.data('prevIndex');

	        if (e.keyCode == 38) {
	          if (that.options.liveSearch) index--;
	          if (index != nextPrev && index > prev) index = prev;
	          if (index < first) index = first;
	          if (index == prevIndex) index = last;
	        } else if (e.keyCode == 40) {
	          if (that.options.liveSearch) index++;
	          if (index == -1) index = 0;
	          if (index != nextPrev && index < next) index = next;
	          if (index > last) index = last;
	          if (index == prevIndex) index = first;
	        }

	        $this.data('prevIndex', index);

	        if (!that.options.liveSearch) {
	          $items.eq(index).children('a').focus();
	        } else {
	          e.preventDefault();
	          if (!$this.hasClass('dropdown-toggle')) {
	            $items.removeClass('active').eq(index).addClass('active').children('a').focus();
	            $this.focus();
	          }
	        }

	      } else if (!$this.is('input')) {
	        var keyIndex = [],
	            count,
	            prevKey;

	        $items.each(function () {
	          if (!$(this).hasClass('disabled')) {
	            if ($.trim($(this).children('a').text().toLowerCase()).substring(0, 1) == keyCodeMap[e.keyCode]) {
	              keyIndex.push($(this).index());
	            }
	          }
	        });

	        count = $(document).data('keycount');
	        count++;
	        $(document).data('keycount', count);

	        prevKey = $.trim($(':focus').text().toLowerCase()).substring(0, 1);

	        if (prevKey != keyCodeMap[e.keyCode]) {
	          count = 1;
	          $(document).data('keycount', count);
	        } else if (count >= keyIndex.length) {
	          $(document).data('keycount', 0);
	          if (count > keyIndex.length) count = 1;
	        }

	        $items.eq(keyIndex[count - 1]).children('a').focus();
	      }

	      // Select focused option if "Enter", "Spacebar" or "Tab" (when selectOnTab is true) are pressed inside the menu.
	      if ((/(13|32)/.test(e.keyCode.toString(10)) || (/(^9$)/.test(e.keyCode.toString(10)) && that.options.selectOnTab)) && isActive) {
	        if (!/(32)/.test(e.keyCode.toString(10))) e.preventDefault();
	        if (!that.options.liveSearch) {
	          var elem = $(':focus');
	          elem.click();
	          // Bring back focus for multiselects
	          elem.focus();
	          // Prevent screen from scrolling if the user hit the spacebar
	          e.preventDefault();
	          // Fixes spacebar selection of dropdown items in FF & IE
	          $(document).data('spaceSelect', true);
	        } else if (!/(32)/.test(e.keyCode.toString(10))) {
	          that.$menuInner.find('.active a').click();
	          $this.focus();
	        }
	        $(document).data('keycount', 0);
	      }

	      if ((/(^9$|27)/.test(e.keyCode.toString(10)) && isActive && (that.multiple || that.options.liveSearch)) || (/(27)/.test(e.keyCode.toString(10)) && !isActive)) {
	        that.$menu.parent().removeClass('open');
	        if (that.options.container) that.$newElement.removeClass('open');
	        that.$button.focus();
	      }
	    },

	    mobile: function () {
	      this.$element.addClass('mobile-device');
	    },

	    refresh: function () {
	      this.$lis = null;
	      this.liObj = {};
	      this.reloadLi();
	      this.render();
	      this.checkDisabled();
	      this.liHeight(true);
	      this.setStyle();
	      this.setWidth();
	      if (this.$lis) this.$searchbox.trigger('propertychange');

	      this.$element.trigger('refreshed.bs.select');
	    },

	    hide: function () {
	      this.$newElement.hide();
	    },

	    show: function () {
	      this.$newElement.show();
	    },

	    remove: function () {
	      this.$newElement.remove();
	      this.$element.remove();
	    },

	    destroy: function () {
	      this.$newElement.before(this.$element).remove();

	      if (this.$bsContainer) {
	        this.$bsContainer.remove();
	      } else {
	        this.$menu.remove();
	      }

	      this.$element
	        .off('.bs.select')
	        .removeData('selectpicker')
	        .removeClass('bs-select-hidden selectpicker');
	    }
	  };

	  // SELECTPICKER PLUGIN DEFINITION
	  // ==============================
	  function Plugin(option, event) {
	    // get the args of the outer function..
	    var args = arguments;
	    // The arguments of the function are explicitly re-defined from the argument list, because the shift causes them
	    // to get lost/corrupted in android 2.3 and IE9 #715 #775
	    var _option = option,
	        _event = event;
	    [].shift.apply(args);

	    var value;
	    var chain = this.each(function () {
	      var $this = $(this);
	      if ($this.is('select')) {
	        var data = $this.data('selectpicker'),
	            options = typeof _option == 'object' && _option;

	        if (!data) {
	          var config = $.extend({}, Selectpicker.DEFAULTS, $.fn.selectpicker.defaults || {}, $this.data(), options);
	          config.template = $.extend({}, Selectpicker.DEFAULTS.template, ($.fn.selectpicker.defaults ? $.fn.selectpicker.defaults.template : {}), $this.data().template, options.template);
	          $this.data('selectpicker', (data = new Selectpicker(this, config, _event)));
	        } else if (options) {
	          for (var i in options) {
	            if (options.hasOwnProperty(i)) {
	              data.options[i] = options[i];
	            }
	          }
	        }

	        if (typeof _option == 'string') {
	          if (data[_option] instanceof Function) {
	            value = data[_option].apply(data, args);
	          } else {
	            value = data.options[_option];
	          }
	        }
	      }
	    });

	    if (typeof value !== 'undefined') {
	      //noinspection JSUnusedAssignment
	      return value;
	    } else {
	      return chain;
	    }
	  }

	  var old = $.fn.selectpicker;
	  $.fn.selectpicker = Plugin;
	  $.fn.selectpicker.Constructor = Selectpicker;

	  // SELECTPICKER NO CONFLICT
	  // ========================
	  $.fn.selectpicker.noConflict = function () {
	    $.fn.selectpicker = old;
	    return this;
	  };

	  $(document)
	      .data('keycount', 0)
	      .on('keydown.bs.select', '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="listbox"], .bs-searchbox input', Selectpicker.prototype.keydown)
	      .on('focusin.modal', '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="listbox"], .bs-searchbox input', function (e) {
	        e.stopPropagation();
	      });

	  // SELECTPICKER DATA-API
	  // =====================
	  $(window).on('load.bs.select.data-api', function () {
	    $('.selectpicker').each(function () {
	      var $selectpicker = $(this);
	      Plugin.call($selectpicker, $selectpicker.data());
	    })
	  });
	})(jQuery);


	}));


/***/ },
/* 9 */
/***/ function(module, exports) {

	!function ($) {

	    "use strict";

	    // TABCOLLAPSE CLASS DEFINITION
	    // ======================

	    var TabCollapse = function (el, options) {
	        this.options   = options;
	        this.$tabs  = $(el);

	        this._accordionVisible = false; //content is attached to tabs at first
	        this._initAccordion();
	        this._checkStateOnResize();


	        // checkState() has gone to setTimeout for making it possible to attach listeners to
	        // shown-accordion.bs.tabcollapse event on page load.
	        // See https://github.com/flatlogic/bootstrap-tabcollapse/issues/23
	        var that = this;
	        setTimeout(function() {
	          that.checkState();
	        }, 0);
	    };

	    TabCollapse.DEFAULTS = {
	        accordionClass: 'visible-xs',
	        tabsClass: 'hidden-xs',
	        accordionTemplate: function(heading, groupId, parentId, active) {
	            return  '<div class="panel panel-default">' +
	                    '   <div class="panel-heading">' +
	                    '      <h4 class="panel-title">' +
	                    '      </h4>' +
	                    '   </div>' +
	                    '   <div id="' + groupId + '" class="panel-collapse collapse ' + (active ? 'in' : '') + '">' +
	                    '       <div class="panel-body js-tabcollapse-panel-body">' +
	                    '       </div>' +
	                    '   </div>' +
	                    '</div>'

	        }
	    };

	    TabCollapse.prototype.checkState = function(){
	        if (this.$tabs.is(':visible') && this._accordionVisible){
	            this.showTabs();
	            this._accordionVisible = false;
	        } else if (this.$accordion.is(':visible') && !this._accordionVisible){
	            this.showAccordion();
	            this._accordionVisible = true;
	        }
	    };

	    TabCollapse.prototype.showTabs = function(){
	        var view = this;
	        this.$tabs.trigger($.Event('show-tabs.bs.tabcollapse'));

	        var $panelHeadings = this.$accordion.find('.js-tabcollapse-panel-heading').detach();

	        $panelHeadings.each(function() {
	            var $panelHeading = $(this),
	            $parentLi = $panelHeading.data('bs.tabcollapse.parentLi');

	            var $oldHeading = view._panelHeadingToTabHeading($panelHeading);

	            $parentLi.removeClass('active');
	            if ($parentLi.parent().hasClass('dropdown-menu') && !$parentLi.siblings('li').hasClass('active')) {
	                $parentLi.parent().parent().removeClass('active');
	            }

	            if (!$oldHeading.hasClass('collapsed')) {
	                $parentLi.addClass('active');
	                if ($parentLi.parent().hasClass('dropdown-menu')) {
	                    $parentLi.parent().parent().addClass('active');
	                }
	            } else {
	                $oldHeading.removeClass('collapsed');
	            }

	            $parentLi.append($panelHeading);
	        });

	        if (!$('li').hasClass('active')) {
	            $('li').first().addClass('active')
	        }

	        var $panelBodies = this.$accordion.find('.js-tabcollapse-panel-body');
	        $panelBodies.each(function(){
	            var $panelBody = $(this),
	                $tabPane = $panelBody.data('bs.tabcollapse.tabpane');
	            $tabPane.append($panelBody.contents().detach());
	        });
	        this.$accordion.html('');

	        if(this.options.updateLinks) {
	            var $tabContents = this.getTabContentElement();
	            $tabContents.find('[data-toggle-was="tab"], [data-toggle-was="pill"]').each(function() {
	                var $el = $(this);
	                var href = $el.attr('href').replace(/-collapse$/g, '');
	                $el.attr({
	                    'data-toggle': $el.attr('data-toggle-was'),
	                    'data-toggle-was': '',
	                    'data-parent': '',
	                    href: href
	                });
	            });
	        }

	        this.$tabs.trigger($.Event('shown-tabs.bs.tabcollapse'));
	    };

	    TabCollapse.prototype.getTabContentElement = function(){
	        var $tabContents = $(this.options.tabContentSelector);
	        if($tabContents.length === 0) {
	            $tabContents = this.$tabs.siblings('.tab-content');
	        }
	        return $tabContents;
	    };

	    TabCollapse.prototype.showAccordion = function(){
	        this.$tabs.trigger($.Event('show-accordion.bs.tabcollapse'));

	        var $headings = this.$tabs.find('li:not(.dropdown) [data-toggle="tab"], li:not(.dropdown) [data-toggle="pill"]'),
	            view = this;
	        $headings.each(function(){
	            var $heading = $(this),
	                $parentLi = $heading.parent();
	            $heading.data('bs.tabcollapse.parentLi', $parentLi);
	            view.$accordion.append(view._createAccordionGroup(view.$accordion.attr('id'), $heading.detach()));
	        });

	        if(this.options.updateLinks) {
	            var parentId = this.$accordion.attr('id');
	            var $selector = this.$accordion.find('.js-tabcollapse-panel-body');
	            $selector.find('[data-toggle="tab"], [data-toggle="pill"]').each(function() {
	                var $el = $(this);
	                var href = $el.attr('href') + '-collapse';
	                $el.attr({
	                    'data-toggle-was': $el.attr('data-toggle'),
	                    'data-toggle': 'collapse',
	                    'data-parent': '#' + parentId,
	                    href: href
	                });
	            });
	        }

	        this.$tabs.trigger($.Event('shown-accordion.bs.tabcollapse'));
	    };

	    TabCollapse.prototype._panelHeadingToTabHeading = function($heading) {
	        var href = $heading.attr('href').replace(/-collapse$/g, '');
	        $heading.attr({
	            'data-toggle': 'tab',
	            'href': href,
	            'data-parent': ''
	        });
	        return $heading;
	    };

	    TabCollapse.prototype._tabHeadingToPanelHeading = function($heading, groupId, parentId, active) {
	        $heading.addClass('js-tabcollapse-panel-heading ' + (active ? '' : 'collapsed'));
	        $heading.attr({
	            'data-toggle': 'collapse',
	            'data-parent': '#' + parentId,
	            'href': '#' + groupId
	        });
	        return $heading;
	    };

	    TabCollapse.prototype._checkStateOnResize = function(){
	        var view = this;
	        $(window).resize(function(){
	            clearTimeout(view._resizeTimeout);
	            view._resizeTimeout = setTimeout(function(){
	                view.checkState();
	            }, 100);
	        });
	    };


	    TabCollapse.prototype._initAccordion = function(){
	        var randomString = function() {
	            var result = "",
	                possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	            for( var i=0; i < 5; i++ ) {
	                result += possible.charAt(Math.floor(Math.random() * possible.length));
	            }
	            return result;
	        };

	        var srcId = this.$tabs.attr('id'),
	            accordionId = (srcId ? srcId : randomString()) + '-accordion';

	        this.$accordion = $('<div class="panel-group ' + this.options.accordionClass + '" id="' + accordionId +'"></div>');
	        this.$tabs.after(this.$accordion);
	        this.$tabs.addClass(this.options.tabsClass);
	        this.getTabContentElement().addClass(this.options.tabsClass);
	    };

	    TabCollapse.prototype._createAccordionGroup = function(parentId, $heading){
	        var tabSelector = $heading.attr('data-target'),
	            active = $heading.data('bs.tabcollapse.parentLi').is('.active');

	        if (!tabSelector) {
	            tabSelector = $heading.attr('href');
	            tabSelector = tabSelector && tabSelector.replace(/.*(?=#[^\s]*$)/, ''); //strip for ie7
	        }

	        var $tabPane = $(tabSelector),
	            groupId = $tabPane.attr('id') + '-collapse',
	            $panel = $(this.options.accordionTemplate($heading, groupId, parentId, active));
	        $panel.find('.panel-heading > .panel-title').append(this._tabHeadingToPanelHeading($heading, groupId, parentId, active));
	        $panel.find('.panel-body').append($tabPane.contents().detach())
	            .data('bs.tabcollapse.tabpane', $tabPane);

	        return $panel;
	    };



	    // TABCOLLAPSE PLUGIN DEFINITION
	    // =======================

	    $.fn.tabCollapse = function (option) {
	        return this.each(function () {
	            var $this   = $(this);
	            var data    = $this.data('bs.tabcollapse');
	            var options = $.extend({}, TabCollapse.DEFAULTS, $this.data(), typeof option === 'object' && option);

	            if (!data) $this.data('bs.tabcollapse', new TabCollapse(this, options));
	        });
	    };

	    $.fn.tabCollapse.Constructor = TabCollapse;


	}(window.jQuery);


/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(jQuery) {/* jshint -W071, -W074 */
	/* global jQuery:false */

	/* Disabled options are:
	 * W071: This function has too many statements
	 * W074: This function's cyclomatic complexity is too high
	 */

	/*
	 *	jQuery ezPlus 1.1.11
	 *	Demo's and documentation:
	 *	http://igorlino.github.io/elevatezoom-plus/
	 *
	 *	licensed under MIT license.
	 *	http://en.wikipedia.org/wiki/MIT_License
	 *
	 */

	if (typeof Object.create !== 'function') {
	    Object.create = function (obj) {
	        function F() {
	        }

	        F.prototype = obj;
	        return new F();
	    };
	}

	(function ($, window, document, undefined) {
	    var EZP = {
	        init: function (options, elem) {
	            var self = this;
	            var $galleries;

	            self.elem = elem;
	            self.$elem = $(elem);

	            self.options = $.extend({}, $.fn.ezPlus.options, self.responsiveConfig(options || {}));

	            self.imageSrc = self.$elem.data(self.options.attrImageZoomSrc) ? self.$elem.data(self.options.attrImageZoomSrc) : self.$elem.attr('src');

	            if (!self.options.enabled) {
	                return;
	            }

	            //TINT OVERRIDE SETTINGS
	            if (self.options.tint) {
	                self.options.lensColour = 'none'; //colour of the lens background
	                self.options.lensOpacity = '1'; //opacity of the lens
	            }
	            //INNER OVERRIDE SETTINGS
	            if (self.options.zoomType === 'inner') {
	                self.options.showLens = false;
	            }

	            //UUID WHEN MISSING IDENTIFIER
	            if (self.options.zoomId === -1) {
	                self.options.zoomId = generateUUID();
	            }

	            //Remove alt on hover

	            self.$elem.parent().removeAttr('title').removeAttr('alt');

	            self.zoomImage = self.imageSrc;

	            self.refresh(1);

	            //Create the image swap from the gallery
	            $galleries = $(self.options.gallery ? ('#' + self.options.gallery) : self.options.gallerySelector);
	            $galleries.on('click.zoom', self.options.galleryItem, function (e) {

	                //Set a class on the currently active gallery image
	                if (self.options.galleryActiveClass) {
	                    $(self.options.galleryItem, $galleries).removeClass(self.options.galleryActiveClass);
	                    $(this).addClass(self.options.galleryActiveClass);
	                }
	                //stop any link on the a tag from working
	                if (this.tagName === 'A') {
	                    e.preventDefault();
	                }

	                //call the swap image function
	                if ($(this).data(self.options.attrImageZoomSrc)) {
	                    self.zoomImagePre = $(this).data(self.options.attrImageZoomSrc);
	                }
	                else {
	                    self.zoomImagePre = $(this).data('image');
	                }
	                self.swaptheimage($(this).data('image'), self.zoomImagePre);
	                if (this.tagName === 'A') {
	                    return false;
	                }
	            });

	            function generateUUID() {
	                var d = new Date().getTime();
	                var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
	                    var r = (d + Math.random() * 16) % 16 | 0;
	                    d = Math.floor(d / 16);
	                    return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
	                });
	                return uuid;
	            }
	        },
	        refresh: function (length) {
	            var self = this;

	            setTimeout(function () {
	                self.fetch(self.imageSrc, self.$elem, self.options.minZoomLevel);

	            }, length || self.options.refresh);
	        },
	        fetch: function (imgsrc, element, minZoom) {
	            //get the image
	            var self = this;
	            var newImg = new Image();
	            newImg.onload = function () {
	                //set the large image dimensions - used to calculte ratio's
	                if (newImg.width / element.width() <= minZoom) {
	                    self.largeWidth = element.width() * minZoom;
	                } else {
	                    self.largeWidth = newImg.width;
	                }
	                if (newImg.height / element.height() <= minZoom) {
	                    self.largeHeight = element.height() * minZoom;
	                } else {
	                    self.largeHeight = newImg.height;
	                }
	                //once image is loaded start the calls
	                self.startZoom();
	                self.currentImage = self.imageSrc;
	                //let caller know image has been loaded
	                self.options.onZoomedImageLoaded(self.$elem);
	            };
	            self.setImageSource(newImg, imgsrc); // this must be done AFTER setting onload

	            return;
	        },
	        setImageSource: function (image, src) {
	            //sets an image's source.
	            image.src = src;
	        },
	        startZoom: function () {
	            var self = this;
	            //get dimensions of the non zoomed image
	            self.nzWidth = self.$elem.width();
	            self.nzHeight = self.$elem.height();

	            //activated elements
	            self.isWindowActive = false;
	            self.isLensActive = false;
	            self.isTintActive = false;
	            self.overWindow = false;

	            //CrossFade Wrapper
	            if (self.options.imageCrossfade) {
	                self.zoomWrap = self.$elem.wrap('<div style="height:' + self.nzHeight + 'px;width:' + self.nzWidth + 'px;" class="zoomWrapper" />');
	                self.$elem.css('position', 'absolute');
	            }

	            self.zoomLock = 1;
	            self.scrollingLock = false;
	            self.changeBgSize = false;
	            self.currentZoomLevel = self.options.zoomLevel;

	            //get offset of the non zoomed image
	            self.nzOffset = self.$elem.offset();
	            //calculate the width ratio of the large/small image
	            self.widthRatio = (self.largeWidth / self.currentZoomLevel) / self.nzWidth;
	            self.heightRatio = (self.largeHeight / self.currentZoomLevel) / self.nzHeight;

	            function getWindowZoomStyle() {
	                return 'overflow: hidden;' +
	                    'background-position: 0px 0px;text-align:center;' +
	                    'background-color: ' + String(self.options.zoomWindowBgColour) + ';' +
	                    'width: ' + String(self.options.zoomWindowWidth) + 'px;' +
	                    'height: ' + String(self.options.zoomWindowHeight) + 'px;' +
	                    'float: left;' +
	                    'background-size: ' + self.largeWidth / self.currentZoomLevel + 'px ' + self.largeHeight / self.currentZoomLevel + 'px;' +
	                    'display: none;z-index:100;' +
	                    'border: ' + String(self.options.borderSize) + 'px solid ' + self.options.borderColour + ';' +
	                    'background-repeat: no-repeat;' +
	                    'position: absolute;';
	            }

	            //if window zoom
	            if (self.options.zoomType === 'window') {
	                self.zoomWindowStyle = getWindowZoomStyle();
	            }

	            function getInnerZoomStyle() {
	                //has a border been put on the image? Lets cater for this
	                var borderWidth = self.$elem.css('border-left-width');

	                return 'overflow: hidden;' +
	                    'margin-left: ' + String(borderWidth) + ';' +
	                    'margin-top: ' + String(borderWidth) + ';' +
	                    'background-position: 0px 0px;' +
	                    'width: ' + String(self.nzWidth) + 'px;' +
	                    'height: ' + String(self.nzHeight) + 'px;' +
	                    'float: left;' +
	                    'display: none;' +
	                    'cursor:' + (self.options.cursor) + ';' +
	                    'border: ' + String(self.options.borderSize) + 'px solid ' + self.options.borderColour + ';' +
	                    'background-repeat: no-repeat;' +
	                    'position: absolute;';
	            }

	            //if inner  zoom
	            if (self.options.zoomType === 'inner') {
	                self.zoomWindowStyle = getInnerZoomStyle();
	            }

	            function getWindowLensStyle() {
	                // adjust images less than the window height

	                if (self.nzHeight < self.options.zoomWindowHeight / self.heightRatio) {
	                    self.lensHeight = self.nzHeight;
	                }
	                else {
	                    self.lensHeight = String(self.options.zoomWindowHeight / self.heightRatio);
	                }
	                if (self.largeWidth < self.options.zoomWindowWidth) {
	                    self.lensWidth = self.nzWidth;
	                }
	                else {
	                    self.lensWidth = String(self.options.zoomWindowWidth / self.widthRatio);
	                }

	                return 'background-position: 0px 0px;width: ' + String((self.options.zoomWindowWidth) / self.widthRatio) + 'px;' +
	                    'height: ' + String((self.options.zoomWindowHeight) / self.heightRatio) +
	                    'px;float: right;display: none;' +
	                    'overflow: hidden;' +
	                    'z-index: 999;' +
	                    'opacity:' + (self.options.lensOpacity) + ';filter: alpha(opacity = ' + (self.options.lensOpacity * 100) + '); zoom:1;' +
	                    'width:' + self.lensWidth + 'px;' +
	                    'height:' + self.lensHeight + 'px;' +
	                    'background-color:' + (self.options.lensColour) + ';' +
	                    'cursor:' + (self.options.cursor) + ';' +
	                    'border: ' + (self.options.lensBorderSize) + 'px' +
	                    ' solid ' + (self.options.lensBorderColour) + ';background-repeat: no-repeat;position: absolute;';
	            }

	            //lens style for window zoom
	            if (self.options.zoomType === 'window') {
	                self.lensStyle = getWindowLensStyle();
	            }

	            //tint style
	            self.tintStyle = 'display: block;' +
	                'position: absolute;' +
	                'background-color: ' + self.options.tintColour + ';' +
	                'filter:alpha(opacity=0);' +
	                'opacity: 0;' +
	                'width: ' + self.nzWidth + 'px;' +
	                'height: ' + self.nzHeight + 'px;';

	            //lens style for lens zoom with optional round for modern browsers
	            self.lensRound = '';

	            if (self.options.zoomType === 'lens') {
	                self.lensStyle = 'background-position: 0px 0px;' +
	                    'float: left;display: none;' +
	                    'border: ' + String(self.options.borderSize) + 'px solid ' + self.options.borderColour + ';' +
	                    'width:' + String(self.options.lensSize) + 'px;' +
	                    'height:' + String(self.options.lensSize) + 'px;' +
	                    'background-repeat: no-repeat;position: absolute;';
	            }

	            //does not round in all browsers
	            if (self.options.lensShape === 'round') {
	                self.lensRound = 'border-top-left-radius: ' + String(self.options.lensSize / 2 + self.options.borderSize) + 'px;' +
	                    'border-top-right-radius: ' + String(self.options.lensSize / 2 + self.options.borderSize) + 'px;' +
	                    'border-bottom-left-radius: ' + String(self.options.lensSize / 2 + self.options.borderSize) + 'px;' +
	                    'border-bottom-right-radius: ' + String(self.options.lensSize / 2 + self.options.borderSize) + 'px;';
	            }

	            //create the div's                                                + ""
	            //self.zoomContainer = $('<div/>').addClass('zoomContainer').css({"position":"relative", "height":self.nzHeight, "width":self.nzWidth});

	            self.zoomContainer =
	                $('<div class="zoomContainer" ' +
	                    'uuid="' + self.options.zoomId + '"' +
	                    'style="' +
	                    'position:absolute;' +
	                    'left:' + self.nzOffset.left + 'px;' +
	                    'top:' + self.nzOffset.top + 'px;' +
	                    'height:' + self.nzHeight + 'px;' + '' +
	                    'width:' + self.nzWidth + 'px;' +
	                    'z-index:' + self.options.zIndex + '"></div>');
	            if (self.$elem.attr('id')) {
	                self.zoomContainer.attr('id', self.$elem.attr('id') + '-zoomContainer');
	            }
	            $(self.options.zoomContainerAppendTo).append(self.zoomContainer);

	            //this will add overflow hidden and contrain the lens on lens mode
	            if (self.options.containLensZoom && self.options.zoomType === 'lens') {
	                self.zoomContainer.css('overflow', 'hidden');
	            }
	            if (self.options.zoomType !== 'inner') {
	                self.zoomLens = $('<div class="zoomLens" style="' + self.lensStyle + self.lensRound + '">&nbsp;</div>')
	                    .appendTo(self.zoomContainer)
	                    .click(function () {
	                        self.$elem.trigger('click');
	                    });

	                if (self.options.tint) {
	                    self.tintContainer = $('<div/>').addClass('tintContainer');
	                    self.zoomTint = $('<div class="zoomTint" style="' + self.tintStyle + '"></div>');

	                    self.zoomLens.wrap(self.tintContainer);

	                    self.zoomTintcss = self.zoomLens.after(self.zoomTint);

	                    //if tint enabled - set an image to show over the tint

	                    self.zoomTintImage = $('<img style="' +
	                        'position: absolute; left: 0px; top: 0px; max-width: none; ' +
	                        'width: ' + self.nzWidth + 'px; ' +
	                        'height: ' + self.nzHeight + 'px;" ' +
	                        'src="' + self.imageSrc + '">')
	                        .appendTo(self.zoomLens)
	                        .click(function () {

	                            self.$elem.trigger('click');
	                        });
	                }
	            }

	            var targetZoomContainer = isNaN(self.options.zoomWindowPosition) ? 'body' : self.zoomContainer;
	            //create zoom window
	            self.zoomWindow = $('<div style="z-index:999;' +
	                'left:' + (self.windowOffsetLeft) + 'px;' +
	                'top:' + (self.windowOffsetTop) + 'px;' + self.zoomWindowStyle + '" class="zoomWindow">&nbsp;</div>')
	                .appendTo(targetZoomContainer).click(function () {
	                    self.$elem.trigger('click');
	                });
	            self.zoomWindowContainer = $('<div/>').addClass('zoomWindowContainer').css('width', self.options.zoomWindowWidth);
	            self.zoomWindow.wrap(self.zoomWindowContainer);

	            //  self.captionStyle = "text-align: left;background-color: black;'+
	            // 'color: white;font-weight: bold;padding: 10px;font-family: sans-serif;font-size: 11px";
	            // self.zoomCaption = $('<div class="ezplus-caption" '+
	            // 'style="'+self.captionStyle+'display: block; width: 280px;">INSERT ALT TAG</div>').appendTo(self.zoomWindow.parent());

	            if (self.options.zoomType === 'lens') {
	                self.zoomLens.css('background-image', 'url("' + self.imageSrc + '")');
	            }
	            if (self.options.zoomType === 'window') {
	                self.zoomWindow.css('background-image', 'url("' + self.imageSrc + '")');
	            }
	            if (self.options.zoomType === 'inner') {
	                self.zoomWindow.css('background-image', 'url("' + self.imageSrc + '")');
	            }

	            /*-------------------END THE ZOOM WINDOW AND LENS----------------------------------*/
	            if (self.options.touchEnabled) {
	                //touch events
	                self.$elem.bind('touchmove.ezpspace', function (e) {
	                    e.preventDefault();
	                    var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
	                    self.setPosition(touch);
	                });
	                self.zoomContainer.bind('touchmove.ezpspace', function (e) {
	                    if (self.options.zoomType === 'inner') {
	                        self.showHideWindow('show');

	                    }
	                    e.preventDefault();
	                    var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
	                    self.setPosition(touch);

	                });
	                self.zoomContainer.bind('touchend.ezpspace', function (e) {
	                    self.showHideWindow('hide');
	                    if (self.options.showLens) {
	                        self.showHideLens('hide');
	                    }
	                    if (self.options.tint && self.options.zoomType !== 'inner') {
	                        self.showHideTint('hide');
	                    }
	                });

	                self.$elem.bind('touchend.ezpspace', function (e) {
	                    self.showHideWindow('hide');
	                    if (self.options.showLens) {
	                        self.showHideLens('hide');
	                    }
	                    if (self.options.tint && self.options.zoomType !== 'inner') {
	                        self.showHideTint('hide');
	                    }
	                });
	                if (self.options.showLens) {
	                    self.zoomLens.bind('touchmove.ezpspace', function (e) {

	                        e.preventDefault();
	                        var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
	                        self.setPosition(touch);
	                    });

	                    self.zoomLens.bind('touchend.ezpspace', function (e) {
	                        self.showHideWindow('hide');
	                        if (self.options.showLens) {
	                            self.showHideLens('hide');
	                        }
	                        if (self.options.tint && self.options.zoomType !== 'inner') {
	                            self.showHideTint('hide');
	                        }
	                    });
	                }
	            }
	            //Needed to work in IE
	            self.$elem.bind('mousemove.ezpspace', function (e) {
	                if (self.overWindow === false) {
	                    self.setElements('show');
	                }
	                //make sure on orientation change the setposition is not fired
	                if (self.lastX !== e.clientX || self.lastY !== e.clientY) {
	                    self.setPosition(e);
	                    self.currentLoc = e;
	                }
	                self.lastX = e.clientX;
	                self.lastY = e.clientY;

	            });

	            self.zoomContainer.bind('click.ezpspace touchstart.ezpspace', self.options.onImageClick);

	            self.zoomContainer.bind('mousemove.ezpspace', function (e) {
	                if (self.overWindow === false) {
	                    self.setElements('show');
	                }
	                mouseMoveZoomHandler(e);
	            });

	            function mouseMoveZoomHandler(e) {
	                //self.overWindow = true;
	                //make sure on orientation change the setposition is not fired
	                if (self.lastX !== e.clientX || self.lastY !== e.clientY) {
	                    self.setPosition(e);
	                    self.currentLoc = e;
	                }
	                self.lastX = e.clientX;
	                self.lastY = e.clientY;
	            }

	            var elementToTrack = null;
	            if (self.options.zoomType !== 'inner') {
	                elementToTrack = self.zoomLens;
	            }
	            if (self.options.tint && self.options.zoomType !== 'inner') {
	                elementToTrack = self.zoomTint;
	            }
	            if (self.options.zoomType === 'inner') {
	                elementToTrack = self.zoomWindow;
	            }

	            //register the mouse tracking
	            if (elementToTrack) {
	                elementToTrack.bind('mousemove.ezpspace', mouseMoveZoomHandler);
	            }

	            //  lensFadeOut: 500,  zoomTintFadeIn
	            self.zoomContainer.add(self.$elem).mouseenter(function () {
	                if (self.overWindow === false) {
	                    self.setElements('show');
	                }
	            }).mouseleave(function () {
	                if (!self.scrollLock) {
	                    self.setElements('hide');
	                    self.options.onDestroy(self.$elem);
	                }
	            });
	            //end ove image

	            if (self.options.zoomType !== 'inner') {
	                self.zoomWindow.mouseenter(function () {
	                    self.overWindow = true;
	                    self.setElements('hide');
	                }).mouseleave(function () {
	                    self.overWindow = false;
	                });
	            }
	            //end ove image

	            // var delta = parseInt(e.originalEvent.wheelDelta || -e.originalEvent.detail);

	            //      $(this).empty();
	            //    return false;

	            //fix for initial zoom setting
	            //if (self.options.zoomLevel !== 1) {
	            //    	self.changeZoomLevel(self.currentZoomLevel);
	            //}
	            //set the min zoomlevel
	            if (self.options.minZoomLevel) {
	                self.minZoomLevel = self.options.minZoomLevel;
	            }
	            else {
	                self.minZoomLevel = self.options.scrollZoomIncrement * 2;
	            }

	            if (self.options.scrollZoom) {
	                //see compatibility of mouse events at https://developer.mozilla.org/en-US/docs/Web/Events/mousewheel
	                self.zoomContainer.add(self.$elem).bind('wheel DOMMouseScroll MozMousePixelScroll', function (e) {
	                    // in IE there is issue with firing of mouseleave - So check whether still scrolling
	                    // and on mouseleave check if scrolllock
	                    self.scrollLock = true;
	                    clearTimeout($.data(this, 'timer'));
	                    $.data(this, 'timer', setTimeout(function () {
	                        self.scrollLock = false;
	                        //do something
	                    }, 250));

	                    var theEvent = e.originalEvent.deltaY || e.originalEvent.detail * -1;

	                    //this.scrollTop += ( delta < 0 ? 1 : -1 ) * 30;
	                    //   e.preventDefault();

	                    e.stopImmediatePropagation();
	                    e.stopPropagation();
	                    e.preventDefault();

	                    if (theEvent == 0) {
	                        // fixes last event inversion bug
	                        return false;
	                    }

	                    if (theEvent / 120 > 0) {
	                        var nextZoomLevel = parseFloat(self.currentZoomLevel) - self.options.scrollZoomIncrement;
	                        //scrolling up
	                        if (nextZoomLevel >= parseFloat(self.minZoomLevel)) {
	                            self.changeZoomLevel(nextZoomLevel);
	                        }
	                    }
	                    else {
	                        //scrolling down

	                        //Check if it has to maintain original zoom window aspect ratio or not
	                        if ((!self.fullheight && !self.fullwidth) || !self.options.mantainZoomAspectRatio) {
	                            var nextZoomLevel = parseFloat(self.currentZoomLevel) + self.options.scrollZoomIncrement;

	                            if (self.options.maxZoomLevel) {
	                                if (nextZoomLevel <= self.options.maxZoomLevel) {
	                                    self.changeZoomLevel(nextZoomLevel);
	                                }
	                            }
	                            else {
	                                //andy
	                                self.changeZoomLevel(nextZoomLevel);
	                            }
	                        }
	                    }
	                    return false;
	                });
	            }
	        },
	        destroy: function () {
	            var self = this;
	            self.$elem.unbind('ezpspace');
	            $(self.zoomContainer).remove();
	            if (self.options.loadingIcon && !!self.spinner && !!self.spinner.length) {
	                self.spinner.remove();
	                delete self.spinner;
	            }
	        },
	        getIdentifier: function () {
	            var self = this;
	            return self.options.zoomId;
	        },
	        setElements: function (type) {
	            var self = this;
	            if (!self.options.zoomEnabled) {
	                return false;
	            }
	            if (type === 'show') {
	                if (self.isWindowSet) {
	                    if (self.options.zoomType === 'inner') {
	                        self.showHideWindow('show');
	                    }
	                    if (self.options.zoomType === 'window') {
	                        self.showHideWindow('show');
	                    }
	                    if (self.options.showLens) {
	                        self.showHideLens('show');
	                    }
	                    if (self.options.tint && self.options.zoomType !== 'inner') {
	                        self.showHideTint('show');
	                    }
	                }
	            }

	            if (type === 'hide') {
	                if (self.options.zoomType === 'window') {
	                    self.showHideWindow('hide');
	                }
	                if (!self.options.tint) {
	                    self.showHideWindow('hide');
	                }
	                if (self.options.showLens) {
	                    self.showHideLens('hide');
	                }
	                if (self.options.tint) {
	                    self.showHideTint('hide');
	                }
	            }
	        },
	        setPosition: function (e) {

	            var self = this;

	            if (!self.options.zoomEnabled) {
	                return false;
	            }

	            //recaclc offset each time in case the image moves
	            //this can be caused by other on page elements
	            self.nzHeight = self.$elem.height();
	            self.nzWidth = self.$elem.width();
	            self.nzOffset = self.$elem.offset();

	            if (self.options.tint && self.options.zoomType !== 'inner') {
	                self.zoomTint.css({
	                    top: 0,
	                    left: 0
	                });
	            }
	            //set responsive
	            //will checking if the image needs changing before running this code work faster?
	            if (self.options.responsive && !self.options.scrollZoom) {
	                if (self.options.showLens) {
	                    var lensHeight, lensWidth;
	                    if (self.nzHeight < self.options.zoomWindowWidth / self.widthRatio) {
	                        self.lensHeight = self.nzHeight;
	                    }
	                    else {
	                        self.lensHeight = String((self.options.zoomWindowHeight / self.heightRatio));
	                    }
	                    if (self.largeWidth < self.options.zoomWindowWidth) {
	                        self.lensWidth = self.nzWidth;
	                    }
	                    else {
	                        self.lensWidth = (self.options.zoomWindowWidth / self.widthRatio);
	                    }
	                    self.widthRatio = self.largeWidth / self.nzWidth;
	                    self.heightRatio = self.largeHeight / self.nzHeight;
	                    if (self.options.zoomType !== 'lens') {
	                        //possibly dont need to keep recalcalculating
	                        //if the lens is heigher than the image, then set lens size to image size
	                        if (self.nzHeight < self.options.zoomWindowWidth / self.widthRatio) {
	                            self.lensHeight = self.nzHeight;

	                        }
	                        else {
	                            self.lensHeight = String((self.options.zoomWindowHeight / self.heightRatio));
	                        }

	                        if (self.nzWidth < self.options.zoomWindowHeight / self.heightRatio) {
	                            self.lensWidth = self.nzWidth;
	                        }
	                        else {
	                            self.lensWidth = String((self.options.zoomWindowWidth / self.widthRatio));
	                        }

	                        self.zoomLens.css({
	                            'width': self.lensWidth,
	                            'height': self.lensHeight
	                        });

	                        if (self.options.tint) {
	                            self.zoomTintImage.css({
	                                'width': self.nzWidth,
	                                'height': self.nzHeight
	                            });
	                        }

	                    }
	                    if (self.options.zoomType === 'lens') {
	                        self.zoomLens.css({
	                            width: String(self.options.lensSize) + 'px',
	                            height: String(self.options.lensSize) + 'px'
	                        });
	                    }
	                    //end responsive image change
	                }
	            }

	            //container fix
	            self.zoomContainer.css({
	                top: self.nzOffset.top,
	                left: self.nzOffset.left,
	                width: self.nzWidth,  // new code
	                height: self.nzHeight // new code
	            });
	            self.mouseLeft = parseInt(e.pageX - self.nzOffset.left);
	            self.mouseTop = parseInt(e.pageY - self.nzOffset.top);
	            //calculate the Location of the Lens

	            //calculate the bound regions - but only if zoom window
	            if (self.options.zoomType === 'window') {
	                var zoomLensHeight = self.zoomLens.height() / 2;
	                var zoomLensWidth = self.zoomLens.width() / 2;
	                self.Etoppos = (self.mouseTop < 0 + zoomLensHeight);
	                self.Eboppos = (self.mouseTop > self.nzHeight - zoomLensHeight - (self.options.lensBorderSize * 2));
	                self.Eloppos = (self.mouseLeft < 0 + zoomLensWidth);
	                self.Eroppos = (self.mouseLeft > (self.nzWidth - zoomLensWidth - (self.options.lensBorderSize * 2)));
	            }
	            //calculate the bound regions - but only for inner zoom
	            if (self.options.zoomType === 'inner') {
	                self.Etoppos = (self.mouseTop < ((self.nzHeight / 2) / self.heightRatio));
	                self.Eboppos = (self.mouseTop > (self.nzHeight - ((self.nzHeight / 2) / self.heightRatio)));
	                self.Eloppos = (self.mouseLeft < 0 + (((self.nzWidth / 2) / self.widthRatio)));
	                self.Eroppos = (self.mouseLeft > (self.nzWidth - (self.nzWidth / 2) / self.widthRatio - (self.options.lensBorderSize * 2)));
	            }

	            // if the mouse position of the slider is one of the outerbounds, then hide  window and lens
	            if (self.mouseLeft < 0 || self.mouseTop < 0 || self.mouseLeft > self.nzWidth || self.mouseTop > self.nzHeight) {
	                self.setElements('hide');
	                return;
	            }
	            //else continue with operations
	            else {
	                //lens options
	                if (self.options.showLens) {
	                    //		self.showHideLens('show');
	                    //set background position of lens
	                    self.lensLeftPos = String(Math.floor(self.mouseLeft - self.zoomLens.width() / 2));
	                    self.lensTopPos = String(Math.floor(self.mouseTop - self.zoomLens.height() / 2));
	                }
	                //adjust the background position if the mouse is in one of the outer regions

	                //Top region
	                if (self.Etoppos) {
	                    self.lensTopPos = 0;
	                }
	                //Left Region
	                if (self.Eloppos) {
	                    self.windowLeftPos = 0;
	                    self.lensLeftPos = 0;
	                    self.tintpos = 0;
	                }
	                //Set bottom and right region for window mode
	                if (self.options.zoomType === 'window') {
	                    if (self.Eboppos) {
	                        self.lensTopPos = Math.max((self.nzHeight) - self.zoomLens.height() - (self.options.lensBorderSize * 2), 0);
	                    }
	                    if (self.Eroppos) {
	                        self.lensLeftPos = (self.nzWidth - (self.zoomLens.width()) - (self.options.lensBorderSize * 2));
	                    }
	                }
	                //Set bottom and right region for inner mode
	                if (self.options.zoomType === 'inner') {
	                    if (self.Eboppos) {
	                        self.lensTopPos = Math.max(((self.nzHeight) - (self.options.lensBorderSize * 2)), 0);
	                    }
	                    if (self.Eroppos) {
	                        self.lensLeftPos = (self.nzWidth - (self.nzWidth) - (self.options.lensBorderSize * 2));
	                    }
	                }
	                //if lens zoom
	                if (self.options.zoomType === 'lens') {

	                    self.windowLeftPos = String(((e.pageX - self.nzOffset.left) * self.widthRatio - self.zoomLens.width() / 2) * (-1));
	                    self.windowTopPos = String(((e.pageY - self.nzOffset.top) * self.heightRatio - self.zoomLens.height() / 2) * (-1));
	                    self.zoomLens.css('background-position', self.windowLeftPos + 'px ' + self.windowTopPos + 'px');

	                    if (self.changeBgSize) {
	                        if (self.nzHeight > self.nzWidth) {
	                            if (self.options.zoomType === 'lens') {
	                                self.zoomLens.css('background-size',
	                                    self.largeWidth / self.newvalueheight + 'px ' +
	                                    self.largeHeight / self.newvalueheight + 'px');
	                            }

	                            self.zoomWindow.css('background-size',
	                                self.largeWidth / self.newvalueheight + 'px ' +
	                                self.largeHeight / self.newvalueheight + 'px');
	                        }
	                        else {
	                            if (self.options.zoomType === 'lens') {
	                                self.zoomLens.css('background-size',
	                                    self.largeWidth / self.newvaluewidth + 'px ' +
	                                    self.largeHeight / self.newvaluewidth + 'px');
	                            }
	                            self.zoomWindow.css('background-size',
	                                self.largeWidth / self.newvaluewidth + 'px ' +
	                                self.largeHeight / self.newvaluewidth + 'px');
	                        }
	                        self.changeBgSize = false;
	                    }

	                    self.setWindowPosition(e);
	                }
	                //if tint zoom
	                if (self.options.tint && self.options.zoomType !== 'inner') {
	                    self.setTintPosition(e);
	                }
	                //set the css background position
	                if (self.options.zoomType === 'window') {
	                    self.setWindowPosition(e);
	                }
	                if (self.options.zoomType === 'inner') {
	                    self.setWindowPosition(e);
	                }
	                if (self.options.showLens) {
	                    if (self.fullwidth && self.options.zoomType !== 'lens') {
	                        self.lensLeftPos = 0;
	                    }
	                    self.zoomLens.css({
	                        left: self.lensLeftPos + 'px',
	                        top: self.lensTopPos + 'px'
	                    });
	                }

	            } //end else
	        },
	        showHideZoomContainer: function (change) {
	            var self = this;
	            if (change === 'show') {
	                if (self.zoomContainer) {
	                    self.zoomContainer.show();
	                }
	            }
	            if (change === 'hide') {
	                if (self.zoomContainer) {
	                    self.zoomContainer.hide();
	                }
	            }
	        },
	        showHideWindow: function (change) {
	            var self = this;
	            if (change === 'show') {
	                if (!self.isWindowActive && self.zoomWindow) {
	                    self.options.onShow(self);
	                    if (self.options.zoomWindowFadeIn) {
	                        self.zoomWindow.stop(true, true, false).fadeIn(self.options.zoomWindowFadeIn);
	                    }
	                    else {
	                        self.zoomWindow.show();
	                    }
	                    self.isWindowActive = true;
	                }
	            }
	            if (change === 'hide') {
	                if (self.isWindowActive) {
	                    if (self.options.zoomWindowFadeOut) {
	                        self.zoomWindow.stop(true, true).fadeOut(self.options.zoomWindowFadeOut, function () {
	                            if (self.loop) {
	                                //stop moving the zoom window when zoom window is faded out
	                                clearInterval(self.loop);
	                                self.loop = false;
	                            }
	                        });
	                    }
	                    else {
	                        self.zoomWindow.hide();
	                    }
	                    self.isWindowActive = false;
	                }
	            }
	        },
	        showHideLens: function (change) {
	            var self = this;
	            if (change === 'show') {
	                if (!self.isLensActive) {
	                    if (self.zoomLens) {
	                        if (self.options.lensFadeIn) {
	                            self.zoomLens.stop(true, true, false).fadeIn(self.options.lensFadeIn);
	                        }
	                        else {
	                            self.zoomLens.show();
	                        }
	                    }
	                    self.isLensActive = true;
	                }
	            }
	            if (change === 'hide') {
	                if (self.isLensActive) {
	                    if (self.zoomLens) {
	                        if (self.options.lensFadeOut) {
	                            self.zoomLens.stop(true, true).fadeOut(self.options.lensFadeOut);
	                        }
	                        else {
	                            self.zoomLens.hide();
	                        }
	                    }
	                    self.isLensActive = false;
	                }
	            }
	        },
	        showHideTint: function (change) {
	            var self = this;
	            if (change === 'show') {
	                if (!self.isTintActive && self.zoomTint) {

	                    if (self.options.zoomTintFadeIn) {
	                        self.zoomTint.css('opacity', self.options.tintOpacity).animate().stop(true, true).fadeIn('slow');
	                    }
	                    else {
	                        self.zoomTint.css('opacity', self.options.tintOpacity).animate();
	                        self.zoomTint.show();
	                    }
	                    self.isTintActive = true;
	                }
	            }
	            if (change === 'hide') {
	                if (self.isTintActive) {

	                    if (self.options.zoomTintFadeOut) {
	                        self.zoomTint.stop(true, true).fadeOut(self.options.zoomTintFadeOut);
	                    }
	                    else {
	                        self.zoomTint.hide();
	                    }
	                    self.isTintActive = false;
	                }
	            }
	        },

	        setLensPosition: function (e) {
	        },

	        setWindowPosition: function (e) {
	            //return obj.slice( 0, count );
	            var self = this;

	            if (!isNaN(self.options.zoomWindowPosition)) {

	                switch (self.options.zoomWindowPosition) {
	                    case 1: //done
	                        self.windowOffsetTop = (self.options.zoomWindowOffsetY);//DONE - 1
	                        self.windowOffsetLeft = (+self.nzWidth); //DONE 1, 2, 3, 4, 16
	                        break;
	                    case 2:
	                        if (self.options.zoomWindowHeight > self.nzHeight) { //positive margin

	                            self.windowOffsetTop = ((self.options.zoomWindowHeight / 2) - (self.nzHeight / 2)) * (-1);
	                            self.windowOffsetLeft = (self.nzWidth); //DONE 1, 2, 3, 4, 16
	                        }
	                        else { //negative margin
	                            $.noop();
	                        }
	                        break;
	                    case 3: //done
	                        self.windowOffsetTop = (self.nzHeight - self.zoomWindow.height() - (self.options.borderSize * 2)); //DONE 3,9
	                        self.windowOffsetLeft = (self.nzWidth); //DONE 1, 2, 3, 4, 16
	                        break;
	                    case 4: //done
	                        self.windowOffsetTop = (self.nzHeight); //DONE - 4,5,6,7,8
	                        self.windowOffsetLeft = (self.nzWidth); //DONE 1, 2, 3, 4, 16
	                        break;
	                    case 5: //done
	                        self.windowOffsetTop = (self.nzHeight); //DONE - 4,5,6,7,8
	                        self.windowOffsetLeft = (self.nzWidth - self.zoomWindow.width() - (self.options.borderSize * 2)); //DONE - 5,15
	                        break;
	                    case 6:
	                        if (self.options.zoomWindowHeight > self.nzHeight) { //positive margin
	                            self.windowOffsetTop = (self.nzHeight);  //DONE - 4,5,6,7,8

	                            self.windowOffsetLeft = ((self.options.zoomWindowWidth / 2) - (self.nzWidth / 2) + (self.options.borderSize * 2)) * (-1);
	                        }
	                        else { //negative margin
	                            $.noop();
	                        }

	                        break;
	                    case 7: //done
	                        self.windowOffsetTop = (self.nzHeight);  //DONE - 4,5,6,7,8
	                        self.windowOffsetLeft = 0; //DONE 7, 13
	                        break;
	                    case 8: //done
	                        self.windowOffsetTop = (self.nzHeight); //DONE - 4,5,6,7,8
	                        self.windowOffsetLeft = (self.zoomWindow.width() + (self.options.borderSize * 2)) * (-1);  //DONE 8,9,10,11,12
	                        break;
	                    case 9:  //done
	                        self.windowOffsetTop = (self.nzHeight - self.zoomWindow.height() - (self.options.borderSize * 2)); //DONE 3,9
	                        self.windowOffsetLeft = (self.zoomWindow.width() + (self.options.borderSize * 2)) * (-1);  //DONE 8,9,10,11,12
	                        break;
	                    case 10:
	                        if (self.options.zoomWindowHeight > self.nzHeight) { //positive margin

	                            self.windowOffsetTop = ((self.options.zoomWindowHeight / 2) - (self.nzHeight / 2)) * (-1);
	                            self.windowOffsetLeft = (self.zoomWindow.width() + (self.options.borderSize * 2)) * (-1);  //DONE 8,9,10,11,12
	                        }
	                        else { //negative margin
	                            $.noop();
	                        }
	                        break;
	                    case 11:
	                        self.windowOffsetTop = (self.options.zoomWindowOffsetY);
	                        self.windowOffsetLeft = (self.zoomWindow.width() + (self.options.borderSize * 2)) * (-1);  //DONE 8,9,10,11,12
	                        break;
	                    case 12: //done
	                        self.windowOffsetTop = (self.zoomWindow.height() + (self.options.borderSize * 2)) * (-1); //DONE 12,13,14,15,16
	                        self.windowOffsetLeft = (self.zoomWindow.width() + (self.options.borderSize * 2)) * (-1);  //DONE 8,9,10,11,12
	                        break;
	                    case 13: //done
	                        self.windowOffsetTop = (self.zoomWindow.height() + (self.options.borderSize * 2)) * (-1); //DONE 12,13,14,15,16
	                        self.windowOffsetLeft = (0); //DONE 7, 13
	                        break;
	                    case 14:
	                        if (self.options.zoomWindowHeight > self.nzHeight) { //positive margin
	                            self.windowOffsetTop = (self.zoomWindow.height() + (self.options.borderSize * 2)) * (-1); //DONE 12,13,14,15,16

	                            self.windowOffsetLeft = ((self.options.zoomWindowWidth / 2) - (self.nzWidth / 2) + (self.options.borderSize * 2)) * (-1);
	                        }
	                        else { //negative margin
	                            $.noop();
	                        }
	                        break;
	                    case 15://done
	                        self.windowOffsetTop = (self.zoomWindow.height() + (self.options.borderSize * 2)) * (-1); //DONE 12,13,14,15,16
	                        self.windowOffsetLeft = (self.nzWidth - self.zoomWindow.width() - (self.options.borderSize * 2)); //DONE - 5,15
	                        break;
	                    case 16:  //done
	                        self.windowOffsetTop = (self.zoomWindow.height() + (self.options.borderSize * 2)) * (-1); //DONE 12,13,14,15,16
	                        self.windowOffsetLeft = (self.nzWidth); //DONE 1, 2, 3, 4, 16
	                        break;
	                    default: //done
	                        self.windowOffsetTop = (self.options.zoomWindowOffsetY);//DONE - 1
	                        self.windowOffsetLeft = (self.nzWidth); //DONE 1, 2, 3, 4, 16
	                }
	            } //end isNAN
	            else {
	                // For BC purposes, treat passed element as ID if element not found
	                self.externalContainer = $(self.options.zoomWindowPosition);
	                if (!self.externalContainer.length) {
	                    self.externalContainer = $('#' + self.options.zoomWindowPosition);
	                }

	                self.externalContainerWidth = self.externalContainer.width();
	                self.externalContainerHeight = self.externalContainer.height();
	                self.externalContainerOffset = self.externalContainer.offset();

	                self.windowOffsetTop = self.externalContainerOffset.top;//DONE - 1
	                self.windowOffsetLeft = self.externalContainerOffset.left; //DONE 1, 2, 3, 4, 16

	            }
	            self.isWindowSet = true;
	            self.windowOffsetTop = self.windowOffsetTop + self.options.zoomWindowOffsetY;
	            self.windowOffsetLeft = self.windowOffsetLeft + self.options.zoomWindowOffsetX;

	            self.zoomWindow.css({
	                top: self.windowOffsetTop,
	                left: self.windowOffsetLeft
	            });

	            if (self.options.zoomType === 'inner') {
	                self.zoomWindow.css({
	                    top: 0,
	                    left: 0
	                });

	            }

	            self.windowLeftPos = String(((e.pageX - self.nzOffset.left) * self.widthRatio - self.zoomWindow.width() / 2) * (-1));
	            self.windowTopPos = String(((e.pageY - self.nzOffset.top) * self.heightRatio - self.zoomWindow.height() / 2) * (-1));
	            if (self.Etoppos) {
	                self.windowTopPos = 0;
	            }
	            if (self.Eloppos) {
	                self.windowLeftPos = 0;
	            }
	            if (self.Eboppos) {
	                self.windowTopPos = (self.largeHeight / self.currentZoomLevel - self.zoomWindow.height()) * (-1);
	            }
	            if (self.Eroppos) {
	                self.windowLeftPos = ((self.largeWidth / self.currentZoomLevel - self.zoomWindow.width()) * (-1));
	            }

	            //stops micro movements
	            if (self.fullheight) {
	                self.windowTopPos = 0;
	            }
	            if (self.fullwidth) {
	                self.windowLeftPos = 0;
	            }

	            //set the css background position
	            if (self.options.zoomType === 'window' || self.options.zoomType === 'inner') {

	                if (self.zoomLock === 1) {
	                    //overrides for images not zoomable
	                    if (self.widthRatio <= 1) {
	                        self.windowLeftPos = 0;
	                    }
	                    if (self.heightRatio <= 1) {
	                        self.windowTopPos = 0;
	                    }
	                }
	                // adjust images less than the window height

	                if (self.options.zoomType === 'window') {
	                    if (self.largeHeight < self.options.zoomWindowHeight) {
	                        self.windowTopPos = 0;
	                    }
	                    if (self.largeWidth < self.options.zoomWindowWidth) {
	                        self.windowLeftPos = 0;
	                    }
	                }
	                //set the zoomwindow background position
	                if (self.options.easing) {

	                    //     if(self.changeZoom){
	                    //           clearInterval(self.loop);
	                    //           self.changeZoom = false;
	                    //           self.loop = false;

	                    //            }
	                    //set the pos to 0 if not set
	                    if (!self.xp) {
	                        self.xp = 0;
	                    }
	                    if (!self.yp) {
	                        self.yp = 0;
	                    }
	                    var interval = 16;
	                    if (Number.isInteger(parseInt(self.options.easing))) {
	                        interval = parseInt(self.options.easing);
	                    }
	                    //if loop not already started, then run it
	                    if (!self.loop) {
	                        self.loop = setInterval(function () {
	                            //using zeno's paradox

	                            self.xp += (self.windowLeftPos - self.xp) / self.options.easingAmount;
	                            self.yp += (self.windowTopPos - self.yp) / self.options.easingAmount;
	                            if (self.scrollingLock) {

	                                clearInterval(self.loop);
	                                self.xp = self.windowLeftPos;
	                                self.yp = self.windowTopPos;

	                                self.xp = ((e.pageX - self.nzOffset.left) * self.widthRatio - self.zoomWindow.width() / 2) * (-1);
	                                self.yp = (((e.pageY - self.nzOffset.top) * self.heightRatio - self.zoomWindow.height() / 2) * (-1));

	                                if (self.changeBgSize) {
	                                    if (self.nzHeight > self.nzWidth) {
	                                        if (self.options.zoomType === 'lens') {
	                                            self.zoomLens.css('background-size',
	                                                self.largeWidth / self.newvalueheight + 'px ' +
	                                                self.largeHeight / self.newvalueheight + 'px');
	                                        }
	                                        self.zoomWindow.css('background-size',
	                                            self.largeWidth / self.newvalueheight + 'px ' +
	                                            self.largeHeight / self.newvalueheight + 'px');
	                                    }
	                                    else {
	                                        if (self.options.zoomType !== 'lens') {
	                                            self.zoomLens.css('background-size',
	                                                self.largeWidth / self.newvaluewidth + 'px ' +
	                                                self.largeHeight / self.newvalueheight + 'px');
	                                        }
	                                        self.zoomWindow.css('background-size',
	                                            self.largeWidth / self.newvaluewidth + 'px ' +
	                                            self.largeHeight / self.newvaluewidth + 'px');
	                                    }

	                                    /*
	                                     if(!self.bgxp){self.bgxp = self.largeWidth/self.newvalue;}
	                                     if(!self.bgyp){self.bgyp = self.largeHeight/self.newvalue ;}
	                                     if (!self.bgloop){
	                                     self.bgloop = setInterval(function(){

	                                     self.bgxp += (self.largeWidth/self.newvalue  - self.bgxp) / self.options.easingAmount;
	                                     self.bgyp += (self.largeHeight/self.newvalue  - self.bgyp) / self.options.easingAmount;

	                                     self.zoomWindow.css('background-size', self.bgxp + 'px ' + self.bgyp + 'px' );


	                                     }, 16);

	                                     }
	                                     */
	                                    self.changeBgSize = false;
	                                }

	                                self.zoomWindow.css('background-position', self.windowLeftPos + 'px ' + self.windowTopPos + 'px');
	                                self.scrollingLock = false;
	                                self.loop = false;

	                            }
	                            else if (Math.round(Math.abs(self.xp - self.windowLeftPos) + Math.abs(self.yp - self.windowTopPos)) < 1) {
	                                //stops micro movements
	                                clearInterval(self.loop);
	                                self.zoomWindow.css('background-position', self.windowLeftPos + 'px ' + self.windowTopPos + 'px');
	                                self.loop = false;
	                            }
	                            else {
	                                if (self.changeBgSize) {
	                                    if (self.nzHeight > self.nzWidth) {
	                                        if (self.options.zoomType === 'lens') {
	                                            self.zoomLens.css('background-size',
	                                                self.largeWidth / self.newvalueheight + 'px ' +
	                                                self.largeHeight / self.newvalueheight + 'px');
	                                        }
	                                        self.zoomWindow.css('background-size',
	                                            self.largeWidth / self.newvalueheight + 'px ' +
	                                            self.largeHeight / self.newvalueheight + 'px');
	                                    }
	                                    else {
	                                        if (self.options.zoomType !== 'lens') {
	                                            self.zoomLens.css('background-size',
	                                                self.largeWidth / self.newvaluewidth + 'px ' +
	                                                self.largeHeight / self.newvaluewidth + 'px');
	                                        }
	                                        self.zoomWindow.css('background-size',
	                                            self.largeWidth / self.newvaluewidth + 'px ' +
	                                            self.largeHeight / self.newvaluewidth + 'px');
	                                    }
	                                    self.changeBgSize = false;
	                                }

	                                self.zoomWindow.css('background-position', self.xp + 'px ' + self.yp + 'px');
	                            }
	                        }, interval);
	                    }
	                }
	                else {
	                    if (self.changeBgSize) {
	                        if (self.nzHeight > self.nzWidth) {
	                            if (self.options.zoomType === 'lens') {
	                                self.zoomLens.css('background-size',
	                                    self.largeWidth / self.newvalueheight + 'px ' +
	                                    self.largeHeight / self.newvalueheight + 'px');
	                            }

	                            self.zoomWindow.css('background-size',
	                                self.largeWidth / self.newvalueheight + 'px ' +
	                                self.largeHeight / self.newvalueheight + 'px');
	                        }
	                        else {
	                            if (self.options.zoomType === 'lens') {
	                                self.zoomLens.css('background-size',
	                                    self.largeWidth / self.newvaluewidth + 'px ' +
	                                    self.largeHeight / self.newvaluewidth + 'px');
	                            }
	                            if ((self.largeHeight / self.newvaluewidth) < self.options.zoomWindowHeight) {

	                                self.zoomWindow.css('background-size',
	                                    self.largeWidth / self.newvaluewidth + 'px ' +
	                                    self.largeHeight / self.newvaluewidth + 'px');
	                            }
	                            else {

	                                self.zoomWindow.css('background-size',
	                                    self.largeWidth / self.newvalueheight + 'px ' +
	                                    self.largeHeight / self.newvalueheight + 'px');
	                            }

	                        }
	                        self.changeBgSize = false;
	                    }

	                    self.zoomWindow.css('background-position',
	                        self.windowLeftPos + 'px ' +
	                        self.windowTopPos + 'px');
	                }
	            }
	        },

	        setTintPosition: function (e) {
	            var self = this;
	            var zoomLensWidth = self.zoomLens.width();
	            var zoomLensHeight = self.zoomLens.height();
	            self.nzOffset = self.$elem.offset();
	            self.tintpos = String(((e.pageX - self.nzOffset.left) - (zoomLensWidth / 2)) * (-1));
	            self.tintposy = String(((e.pageY - self.nzOffset.top) - zoomLensHeight / 2) * (-1));
	            if (self.Etoppos) {
	                self.tintposy = 0;
	            }
	            if (self.Eloppos) {
	                self.tintpos = 0;
	            }
	            if (self.Eboppos) {
	                self.tintposy = (self.nzHeight - zoomLensHeight - (self.options.lensBorderSize * 2)) * (-1);
	            }
	            if (self.Eroppos) {
	                self.tintpos = ((self.nzWidth - zoomLensWidth - (self.options.lensBorderSize * 2)) * (-1));
	            }
	            if (self.options.tint) {
	                //stops micro movements
	                if (self.fullheight) {
	                    self.tintposy = 0;

	                }
	                if (self.fullwidth) {
	                    self.tintpos = 0;

	                }
	                self.zoomTintImage.css({
	                    'left': self.tintpos + 'px',
	                    'top': self.tintposy + 'px'
	                });
	            }
	        },

	        swaptheimage: function (smallimage, largeimage) {
	            var self = this;
	            var newImg = new Image();

	            if (self.options.loadingIcon && !self.spinner) {
	                var styleAttr = 'background: url(\'' + self.options.loadingIcon + '\') no-repeat center;' +
	                    'height:' + self.nzHeight + 'px;' +
	                    'width:' + self.nzWidth + 'px;' +
	                    'z-index: 2000;' +
	                    'position: absolute; ' +
	                    'background-position: center center;';
	                if (self.options.zoomType === 'inner') {
	                    styleAttr += 'top: 0px;';
	                }
	                self.spinner = $('<div class="ezp-spinner" style="' + styleAttr + '"></div>');
	                self.$elem.after(self.spinner);
	            } else if (self.spinner) {
	                self.spinner.show();
	            }

	            self.options.onImageSwap(self.$elem);

	            newImg.onload = function () {
	                self.largeWidth = newImg.width;
	                self.largeHeight = newImg.height;
	                self.zoomImage = largeimage;
	                self.zoomWindow.css('background-size', self.largeWidth + 'px ' + self.largeHeight + 'px');

	                self.swapAction(smallimage, largeimage);
	                return;
	            };
	            self.setImageSource(newImg, largeimage);  // this must be done AFTER setting onload
	        },

	        swapAction: function (smallimage, largeimage) {
	            var self = this;
	            var elemWidth = self.$elem.width();
	            var elemHeight = self.$elem.height();
	            var newImg2 = new Image();
	            newImg2.onload = function () {
	                //re-calculate values
	                self.nzHeight = newImg2.height;
	                self.nzWidth = newImg2.width;
	                self.options.onImageSwapComplete(self.$elem);

	                self.doneCallback();
	                return;
	            };
	            self.setImageSource(newImg2, smallimage);

	            //reset the zoomlevel to that initially set in options
	            self.currentZoomLevel = self.options.zoomLevel;
	            self.options.maxZoomLevel = false;

	            //swaps the main image
	            //self.$elem.attr('src',smallimage);
	            //swaps the zoom image
	            if (self.options.zoomType === 'lens') {
	                self.zoomLens.css('background-image', 'url("' + largeimage + '")');
	            }
	            if (self.options.zoomType === 'window') {
	                self.zoomWindow.css('background-image', 'url("' + largeimage + '")');
	            }
	            if (self.options.zoomType === 'inner') {
	                self.zoomWindow.css('background-image', 'url("' + largeimage + '")');
	            }

	            self.currentImage = largeimage;

	            if (self.options.imageCrossfade) {
	                var oldImg = self.$elem;
	                var newImg = oldImg.clone();
	                self.$elem.attr('src', smallimage);
	                self.$elem.after(newImg);
	                newImg.stop(true).fadeOut(self.options.imageCrossfade, function () {
	                    $(this).remove();
	                });

	                // if(self.options.zoomType === 'inner'){
	                //remove any attributes on the cloned image so we can resize later
	                self.$elem.width('auto').removeAttr('width');
	                self.$elem.height('auto').removeAttr('height');
	                //   }

	                oldImg.fadeIn(self.options.imageCrossfade);

	                if (self.options.tint && self.options.zoomType !== 'inner') {

	                    var oldImgTint = self.zoomTintImage;
	                    var newImgTint = oldImgTint.clone();
	                    self.zoomTintImage.attr('src', largeimage);
	                    self.zoomTintImage.after(newImgTint);
	                    newImgTint.stop(true).fadeOut(self.options.imageCrossfade, function () {
	                        $(this).remove();
	                    });

	                    oldImgTint.fadeIn(self.options.imageCrossfade);

	                    //self.zoomTintImage.attr('width',elem.data('image'));

	                    //resize the tint window
	                    self.zoomTint.css({
	                        height: elemHeight,
	                        width: elemWidth
	                    });
	                }

	                self.zoomContainer.css({
	                    'height': elemHeight,
	                    'width': elemWidth
	                });

	                if (self.options.zoomType === 'inner') {
	                    if (!self.options.constrainType) {
	                        self.zoomWrap.parent().css({
	                            'height': elemHeight,
	                            'width': elemWidth
	                        });

	                        self.zoomWindow.css({
	                            'height': elemHeight,
	                            'width': elemWidth
	                        });
	                    }
	                }

	                if (self.options.imageCrossfade) {
	                    self.zoomWrap.css({
	                        'height': elemHeight,
	                        'width': elemWidth
	                    });
	                }
	            }
	            else {
	                self.$elem.attr('src', smallimage);
	                if (self.options.tint) {
	                    self.zoomTintImage.attr('src', largeimage);
	                    //self.zoomTintImage.attr('width',elem.data('image'));
	                    self.zoomTintImage.attr('height', elemHeight);
	                    //self.zoomTintImage.attr('src') = elem.data('image');
	                    self.zoomTintImage.css('height', elemHeight);
	                    self.zoomTint.css('height', elemHeight);

	                }
	                self.zoomContainer.css({
	                    'height': elemHeight,
	                    'width': elemWidth
	                });

	                if (self.options.imageCrossfade) {
	                    self.zoomWrap.css({
	                        'height': elemHeight,
	                        'width': elemWidth
	                    });
	                }
	            }
	            if (self.options.constrainType) {

	                //This will contrain the image proportions
	                if (self.options.constrainType === 'height') {

	                    var autoWDimension = {
	                        'height': self.options.constrainSize,
	                        'width': 'auto'
	                    };
	                    self.zoomContainer.css(autoWDimension);

	                    if (self.options.imageCrossfade) {
	                        self.zoomWrap.css(autoWDimension);
	                        self.constwidth = self.zoomWrap.width();
	                    }
	                    else {
	                        self.$elem.css(autoWDimension);
	                        self.constwidth = elemWidth;
	                    }

	                    var constWDim = {
	                        'height': self.options.constrainSize,
	                        'width': self.constwidth
	                    };
	                    if (self.options.zoomType === 'inner') {

	                        self.zoomWrap.parent().css(constWDim);
	                        self.zoomWindow.css(constWDim);
	                    }
	                    if (self.options.tint) {
	                        self.tintContainer.css(constWDim);
	                        self.zoomTint.css(constWDim);
	                        self.zoomTintImage.css(constWDim);
	                    }

	                }
	                if (self.options.constrainType === 'width') {
	                    var autoHDimension = {
	                        'height': 'auto',
	                        'width': self.options.constrainSize
	                    };
	                    self.zoomContainer.css(autoHDimension);

	                    if (self.options.imageCrossfade) {
	                        self.zoomWrap.css(autoHDimension);
	                        self.constheight = self.zoomWrap.height();
	                    }
	                    else {
	                        self.$elem.css(autoHDimension);
	                        self.constheight = elemHeight;
	                    }

	                    var constHDim = {
	                        'height': self.constheight,
	                        'width': self.options.constrainSize
	                    };
	                    if (self.options.zoomType === 'inner') {
	                        self.zoomWrap.parent().css(constHDim);
	                        self.zoomWindow.css(constHDim);
	                    }
	                    if (self.options.tint) {
	                        self.tintContainer.css(constHDim);
	                        self.zoomTint.css(constHDim);
	                        self.zoomTintImage.css(constHDim);
	                    }
	                }
	            }
	        },

	        doneCallback: function () {
	            var self = this;
	            if (self.options.loadingIcon && !!self.spinner && !!self.spinner.length) {
	                self.spinner.hide();
	            }

	            self.nzOffset = self.$elem.offset();
	            self.nzWidth = self.$elem.width();
	            self.nzHeight = self.$elem.height();

	            // reset the zoomlevel back to default
	            self.currentZoomLevel = self.options.zoomLevel;

	            //ratio of the large to small image
	            self.widthRatio = self.largeWidth / self.nzWidth;
	            self.heightRatio = self.largeHeight / self.nzHeight;

	            //NEED TO ADD THE LENS SIZE FOR ROUND
	            // adjust images less than the window height
	            if (self.options.zoomType === 'window') {

	                if (self.nzHeight < self.options.zoomWindowHeight / self.heightRatio) {
	                    self.lensHeight = self.nzHeight;

	                }
	                else {
	                    self.lensHeight = String((self.options.zoomWindowHeight / self.heightRatio));
	                }

	                if (self.nzWidth < self.options.zoomWindowWidth) {
	                    self.lensWidth = self.nzWidth;
	                }
	                else {
	                    self.lensWidth = (self.options.zoomWindowWidth / self.widthRatio);
	                }

	                if (self.zoomLens) {
	                    self.zoomLens.css({
	                        'width': self.lensWidth,
	                        'height': self.lensHeight
	                    });
	                }
	            }
	        },

	        getCurrentImage: function () {
	            var self = this;
	            return self.zoomImage;
	        },

	        getGalleryList: function () {
	            var self = this;
	            //loop through the gallery options and set them in list for fancybox
	            self.gallerylist = [];
	            if (self.options.gallery) {
	                $('#' + self.options.gallery + ' a').each(function () {

	                    var imgSrc = '';
	                    if ($(this).data(self.options.attrImageZoomSrc)) {
	                        imgSrc = $(this).data(self.options.attrImageZoomSrc);
	                    }
	                    else if ($(this).data('image')) {
	                        imgSrc = $(this).data('image');
	                    }
	                    //put the current image at the start
	                    if (imgSrc === self.zoomImage) {
	                        self.gallerylist.unshift({
	                            href: '' + imgSrc + '',
	                            title: $(this).find('img').attr('title')
	                        });
	                    }
	                    else {
	                        self.gallerylist.push({
	                            href: '' + imgSrc + '',
	                            title: $(this).find('img').attr('title')
	                        });
	                    }
	                });
	            }
	            //if no gallery - return current image
	            else {
	                self.gallerylist.push({
	                    href: '' + self.zoomImage + '',
	                    title: $(this).find('img').attr('title')
	                });
	            }
	            return self.gallerylist;
	        },

	        changeZoomLevel: function (value) {
	            var self = this;

	            //flag a zoom, so can adjust the easing during setPosition
	            self.scrollingLock = true;

	            //round to two decimal places
	            self.newvalue = parseFloat(value).toFixed(2);
	            var newvalue = self.newvalue;

	            //maxwidth & Maxheight of the image
	            var maxheightnewvalue = self.largeHeight / ((self.options.zoomWindowHeight / self.nzHeight) * self.nzHeight);
	            var maxwidthtnewvalue = self.largeWidth / ((self.options.zoomWindowWidth / self.nzWidth) * self.nzWidth);

	            //calculate new heightratio
	            if (self.options.zoomType !== 'inner') {
	                if (maxheightnewvalue <= newvalue) {
	                    self.heightRatio = (self.largeHeight / maxheightnewvalue) / self.nzHeight;
	                    self.newvalueheight = maxheightnewvalue;
	                    self.fullheight = true;
	                }
	                else {
	                    self.heightRatio = (self.largeHeight / newvalue) / self.nzHeight;
	                    self.newvalueheight = newvalue;
	                    self.fullheight = false;
	                }

	                // calculate new width ratio

	                if (maxwidthtnewvalue <= newvalue) {
	                    self.widthRatio = (self.largeWidth / maxwidthtnewvalue) / self.nzWidth;
	                    self.newvaluewidth = maxwidthtnewvalue;
	                    self.fullwidth = true;
	                }
	                else {
	                    self.widthRatio = (self.largeWidth / newvalue) / self.nzWidth;
	                    self.newvaluewidth = newvalue;
	                    self.fullwidth = false;
	                }
	                if (self.options.zoomType === 'lens') {
	                    if (maxheightnewvalue <= newvalue) {
	                        self.fullwidth = true;
	                        self.newvaluewidth = maxheightnewvalue;
	                    } else {
	                        self.widthRatio = (self.largeWidth / newvalue) / self.nzWidth;
	                        self.newvaluewidth = newvalue;

	                        self.fullwidth = false;
	                    }
	                }
	            }

	            if (self.options.zoomType === 'inner') {
	                maxheightnewvalue = parseFloat(self.largeHeight / self.nzHeight).toFixed(2);
	                maxwidthtnewvalue = parseFloat(self.largeWidth / self.nzWidth).toFixed(2);
	                if (newvalue > maxheightnewvalue) {
	                    newvalue = maxheightnewvalue;
	                }
	                if (newvalue > maxwidthtnewvalue) {
	                    newvalue = maxwidthtnewvalue;
	                }

	                if (maxheightnewvalue <= newvalue) {
	                    self.heightRatio = (self.largeHeight / newvalue) / self.nzHeight;
	                    if (newvalue > maxheightnewvalue) {
	                        self.newvalueheight = maxheightnewvalue;
	                    } else {
	                        self.newvalueheight = newvalue;
	                    }
	                    self.fullheight = true;
	                }
	                else {
	                    self.heightRatio = (self.largeHeight / newvalue) / self.nzHeight;

	                    if (newvalue > maxheightnewvalue) {

	                        self.newvalueheight = maxheightnewvalue;
	                    } else {
	                        self.newvalueheight = newvalue;
	                    }
	                    self.fullheight = false;
	                }

	                if (maxwidthtnewvalue <= newvalue) {

	                    self.widthRatio = (self.largeWidth / newvalue) / self.nzWidth;
	                    if (newvalue > maxwidthtnewvalue) {

	                        self.newvaluewidth = maxwidthtnewvalue;
	                    } else {
	                        self.newvaluewidth = newvalue;
	                    }

	                    self.fullwidth = true;
	                }
	                else {
	                    self.widthRatio = (self.largeWidth / newvalue) / self.nzWidth;
	                    self.newvaluewidth = newvalue;
	                    self.fullwidth = false;
	                }
	            } //end inner
	            var scrcontinue = false;

	            if (self.options.zoomType === 'inner') {
	                if (self.nzWidth >= self.nzHeight) {
	                    if (self.newvaluewidth <= maxwidthtnewvalue) {
	                        scrcontinue = true;
	                    }
	                    else {
	                        scrcontinue = false;
	                        self.fullheight = true;
	                        self.fullwidth = true;
	                    }
	                }
	                if (self.nzHeight > self.nzWidth) {
	                    if (self.newvaluewidth <= maxwidthtnewvalue) {
	                        scrcontinue = true;
	                    }
	                    else {
	                        scrcontinue = false;
	                        self.fullheight = true;
	                        self.fullwidth = true;
	                    }
	                }
	            }

	            if (self.options.zoomType !== 'inner') {
	                scrcontinue = true;
	            }

	            if (scrcontinue) {
	                self.zoomLock = 0;
	                self.changeZoom = true;

	                //if lens height is less than image height
	                if (((self.options.zoomWindowHeight) / self.heightRatio) <= self.nzHeight) {
	                    self.currentZoomLevel = self.newvalueheight;
	                    if (self.options.zoomType !== 'lens' && self.options.zoomType !== 'inner') {
	                        self.changeBgSize = true;
	                        self.zoomLens.css('height', String(self.options.zoomWindowHeight / self.heightRatio) + 'px');
	                    }
	                    if (self.options.zoomType === 'lens' || self.options.zoomType === 'inner') {
	                        self.changeBgSize = true;
	                    }
	                }

	                if ((self.options.zoomWindowWidth / self.widthRatio) <= self.nzWidth) {
	                    if (self.options.zoomType !== 'inner') {
	                        if (self.newvaluewidth > self.newvalueheight) {
	                            self.currentZoomLevel = self.newvaluewidth;
	                        }
	                    }

	                    if (self.options.zoomType !== 'lens' && self.options.zoomType !== 'inner') {
	                        self.changeBgSize = true;

	                        self.zoomLens.css('width', String(self.options.zoomWindowWidth / self.widthRatio) + 'px');
	                    }
	                    if (self.options.zoomType === 'lens' || self.options.zoomType === 'inner') {
	                        self.changeBgSize = true;
	                    }

	                }
	                if (self.options.zoomType === 'inner') {
	                    self.changeBgSize = true;

	                    if (self.nzWidth > self.nzHeight) {
	                        self.currentZoomLevel = self.newvaluewidth;
	                    }
	                    else if (self.nzHeight >= self.nzWidth) {
	                        self.currentZoomLevel = self.newvaluewidth;
	                    }
	                }
	            }      //under

	            //sets the boundry change, called in setWindowPos
	            self.setPosition(self.currentLoc);
	            //
	        },

	        closeAll: function () {
	            var self = this;
	            if (self.zoomWindow) {
	                self.zoomWindow.hide();
	            }
	            if (self.zoomLens) {
	                self.zoomLens.hide();
	            }
	            if (self.zoomTint) {
	                self.zoomTint.hide();
	            }
	        },

	        changeState: function (value) {
	            var self = this;
	            if (value === 'enable') {
	                self.options.zoomEnabled = true;
	            }
	            if (value === 'disable') {
	                self.options.zoomEnabled = false;
	            }
	        },

	        responsiveConfig: function (options) {
	            if (options.respond && options.respond.length > 0) {
	                return $.extend({}, options, this.configByScreenWidth(options));
	            }
	            return options;
	        },

	        configByScreenWidth: function (options) {
	            var screenWidth = $(window).width();

	            var config = $.grep(options.respond, function (item) {
	                var range = item.range.split('-');
	                return (screenWidth >= range[0]) && (screenWidth <= range[1]);
	            });

	            if (config.length > 0) {
	                return config[0];
	            } else {
	                return options;
	            }
	        }
	    };

	    $.fn.ezPlus = function (options) {
	        return this.each(function () {
	            var elevate = Object.create(EZP);

	            elevate.init(options, this);

	            $.data(this, 'ezPlus', elevate);

	        });
	    };

	    $.fn.ezPlus.options = {
	        attrImageZoomSrc: 'zoom-image', // attribute to plugin use for zoom
	        borderColour: '#888',
	        borderSize: 4,
	        constrainSize: false,  //in pixels the dimensions you want to constrain on
	        constrainType: false,  //width or height
	        containLensZoom: false,
	        cursor: 'inherit', // user should set to what they want the cursor as, if they have set a click function
	        debug: false,
	        easing: false,
	        easingAmount: 12,
	        enabled: true,

	        gallery: false,
	        galleryActiveClass: 'zoomGalleryActive',
	        gallerySelector: false,
	        galleryItem: 'a',

	        imageCrossfade: false,

	        lensBorderColour: '#000',
	        lensBorderSize: 1,
	        lensColour: 'white', //colour of the lens background
	        lensFadeIn: false,
	        lensFadeOut: false,
	        lensOpacity: 0.4, //opacity of the lens
	        lensShape: 'square', //can be 'round'
	        lensSize: 200,
	        lenszoom: false,

	        loadingIcon: false, //http://www.example.com/spinner.gif

	        // This change will allow to decide if you want to decrease
	        // zoom of one of the dimensions once the other reached it's top value,
	        // or keep the aspect ratio, default behaviour still being as always,
	        // allow to continue zooming out, so it keeps retrocompatibility.
	        mantainZoomAspectRatio: false,
	        maxZoomLevel: false,
	        minZoomLevel: 1.01,

	        onComplete: $.noop,
	        onDestroy: $.noop,
	        onImageClick: $.noop,
	        onImageSwap: $.noop,
	        onImageSwapComplete: $.noop,
	        onShow: $.noop,
	        onZoomedImageLoaded: $.noop,

	        preloading: 1, //by default, load all the images, if 0, then only load images after activated (PLACEHOLDER FOR NEXT VERSION)
	        respond: [],
	        responsive: true,
	        scrollZoom: false, //allow zoom on mousewheel, true to activate
	        scrollZoomIncrement: 0.1,  //steps of the scrollzoom
	        showLens: true,
	        tint: false, //enable the tinting
	        tintColour: '#333', //default tint color, can be anything, red, #ccc, rgb(0,0,0)
	        tintOpacity: 0.4, //opacity of the tint
	        touchEnabled: true,

	        zoomActivation: 'hover', // Can also be click (PLACEHOLDER FOR NEXT VERSION)
	        zoomContainerAppendTo: 'body', //zoom container parent selector
	        zoomId: -1, // identifier for the zoom container
	        zoomLevel: 1, //default zoom level of image
	        zoomTintFadeIn: false,
	        zoomTintFadeOut: false,
	        zoomType: 'window', //window is default,  also 'lens' available -
	        zoomWindowAlwaysShow: false,
	        zoomWindowBgColour: '#fff',
	        zoomWindowFadeIn: false,
	        zoomWindowFadeOut: false,
	        zoomWindowHeight: 400,
	        zoomWindowOffsetX: 0,
	        zoomWindowOffsetY: 0,
	        zoomWindowPosition: 1, //Possible values: 1-16, but we can also position with a selector string.
	        zoomWindowWidth: 400,
	        zoomEnabled: true, //false disables zoomwindow from showing
	        zIndex: 999
	    };

	})(jQuery, window, document);

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*
	     _ _      _       _
	 ___| (_) ___| | __  (_)___
	/ __| | |/ __| |/ /  | / __|
	\__ \ | | (__|   < _ | \__ \
	|___/_|_|\___|_|\_(_)/ |___/
	                   |__/

	 Version: 1.6.0
	  Author: Ken Wheeler
	 Website: http://kenwheeler.github.io
	    Docs: http://kenwheeler.github.io/slick
	    Repo: http://github.com/kenwheeler/slick
	  Issues: http://github.com/kenwheeler/slick/issues

	 */
	/* global window, document, define, jQuery, setInterval, clearInterval */
	(function(factory) {
	    'use strict';
	    if (true) {
	        !(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(1)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	    } else if (typeof exports !== 'undefined') {
	        module.exports = factory(require('jquery'));
	    } else {
	        factory(jQuery);
	    }

	}(function($) {
	    'use strict';
	    var Slick = window.Slick || {};

	    Slick = (function() {

	        var instanceUid = 0;

	        function Slick(element, settings) {

	            var _ = this, dataSettings;

	            _.defaults = {
	                accessibility: true,
	                adaptiveHeight: false,
	                appendArrows: $(element),
	                appendDots: $(element),
	                arrows: true,
	                asNavFor: null,
	                prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous</button>',
	                nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next</button>',
	                autoplay: false,
	                autoplaySpeed: 3000,
	                centerMode: false,
	                centerPadding: '50px',
	                cssEase: 'ease',
	                customPaging: function(slider, i) {
	                    return $('<button type="button" data-role="none" role="button" tabindex="0" />').text(i + 1);
	                },
	                dots: false,
	                dotsClass: 'slick-dots',
	                draggable: true,
	                easing: 'linear',
	                edgeFriction: 0.35,
	                fade: false,
	                focusOnSelect: false,
	                infinite: true,
	                initialSlide: 0,
	                lazyLoad: 'ondemand',
	                mobileFirst: false,
	                pauseOnHover: true,
	                pauseOnFocus: true,
	                pauseOnDotsHover: false,
	                respondTo: 'window',
	                responsive: null,
	                rows: 1,
	                rtl: false,
	                slide: '',
	                slidesPerRow: 1,
	                slidesToShow: 1,
	                slidesToScroll: 1,
	                speed: 500,
	                swipe: true,
	                swipeToSlide: false,
	                touchMove: true,
	                touchThreshold: 5,
	                useCSS: true,
	                useTransform: true,
	                variableWidth: false,
	                vertical: false,
	                verticalSwiping: false,
	                waitForAnimate: true,
	                zIndex: 1000
	            };

	            _.initials = {
	                animating: false,
	                dragging: false,
	                autoPlayTimer: null,
	                currentDirection: 0,
	                currentLeft: null,
	                currentSlide: 0,
	                direction: 1,
	                $dots: null,
	                listWidth: null,
	                listHeight: null,
	                loadIndex: 0,
	                $nextArrow: null,
	                $prevArrow: null,
	                slideCount: null,
	                slideWidth: null,
	                $slideTrack: null,
	                $slides: null,
	                sliding: false,
	                slideOffset: 0,
	                swipeLeft: null,
	                $list: null,
	                touchObject: {},
	                transformsEnabled: false,
	                unslicked: false
	            };

	            $.extend(_, _.initials);

	            _.activeBreakpoint = null;
	            _.animType = null;
	            _.animProp = null;
	            _.breakpoints = [];
	            _.breakpointSettings = [];
	            _.cssTransitions = false;
	            _.focussed = false;
	            _.interrupted = false;
	            _.hidden = 'hidden';
	            _.paused = true;
	            _.positionProp = null;
	            _.respondTo = null;
	            _.rowCount = 1;
	            _.shouldClick = true;
	            _.$slider = $(element);
	            _.$slidesCache = null;
	            _.transformType = null;
	            _.transitionType = null;
	            _.visibilityChange = 'visibilitychange';
	            _.windowWidth = 0;
	            _.windowTimer = null;

	            dataSettings = $(element).data('slick') || {};

	            _.options = $.extend({}, _.defaults, settings, dataSettings);

	            _.currentSlide = _.options.initialSlide;

	            _.originalSettings = _.options;

	            if (typeof document.mozHidden !== 'undefined') {
	                _.hidden = 'mozHidden';
	                _.visibilityChange = 'mozvisibilitychange';
	            } else if (typeof document.webkitHidden !== 'undefined') {
	                _.hidden = 'webkitHidden';
	                _.visibilityChange = 'webkitvisibilitychange';
	            }

	            _.autoPlay = $.proxy(_.autoPlay, _);
	            _.autoPlayClear = $.proxy(_.autoPlayClear, _);
	            _.autoPlayIterator = $.proxy(_.autoPlayIterator, _);
	            _.changeSlide = $.proxy(_.changeSlide, _);
	            _.clickHandler = $.proxy(_.clickHandler, _);
	            _.selectHandler = $.proxy(_.selectHandler, _);
	            _.setPosition = $.proxy(_.setPosition, _);
	            _.swipeHandler = $.proxy(_.swipeHandler, _);
	            _.dragHandler = $.proxy(_.dragHandler, _);
	            _.keyHandler = $.proxy(_.keyHandler, _);

	            _.instanceUid = instanceUid++;

	            // A simple way to check for HTML strings
	            // Strict HTML recognition (must start with <)
	            // Extracted from jQuery v1.11 source
	            _.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/;


	            _.registerBreakpoints();
	            _.init(true);

	        }

	        return Slick;

	    }());

	    Slick.prototype.activateADA = function() {
	        var _ = this;

	        _.$slideTrack.find('.slick-active').attr({
	            'aria-hidden': 'false'
	        }).find('a, input, button, select').attr({
	            'tabindex': '0'
	        });

	    };

	    Slick.prototype.addSlide = Slick.prototype.slickAdd = function(markup, index, addBefore) {

	        var _ = this;

	        if (typeof(index) === 'boolean') {
	            addBefore = index;
	            index = null;
	        } else if (index < 0 || (index >= _.slideCount)) {
	            return false;
	        }

	        _.unload();

	        if (typeof(index) === 'number') {
	            if (index === 0 && _.$slides.length === 0) {
	                $(markup).appendTo(_.$slideTrack);
	            } else if (addBefore) {
	                $(markup).insertBefore(_.$slides.eq(index));
	            } else {
	                $(markup).insertAfter(_.$slides.eq(index));
	            }
	        } else {
	            if (addBefore === true) {
	                $(markup).prependTo(_.$slideTrack);
	            } else {
	                $(markup).appendTo(_.$slideTrack);
	            }
	        }

	        _.$slides = _.$slideTrack.children(this.options.slide);

	        _.$slideTrack.children(this.options.slide).detach();

	        _.$slideTrack.append(_.$slides);

	        _.$slides.each(function(index, element) {
	            $(element).attr('data-slick-index', index);
	        });

	        _.$slidesCache = _.$slides;

	        _.reinit();

	    };

	    Slick.prototype.animateHeight = function() {
	        var _ = this;
	        if (_.options.slidesToShow === 1 && _.options.adaptiveHeight === true && _.options.vertical === false) {
	            var targetHeight = _.$slides.eq(_.currentSlide).outerHeight(true);
	            _.$list.animate({
	                height: targetHeight
	            }, _.options.speed);
	        }
	    };

	    Slick.prototype.animateSlide = function(targetLeft, callback) {

	        var animProps = {},
	            _ = this;

	        _.animateHeight();

	        if (_.options.rtl === true && _.options.vertical === false) {
	            targetLeft = -targetLeft;
	        }
	        if (_.transformsEnabled === false) {
	            if (_.options.vertical === false) {
	                _.$slideTrack.animate({
	                    left: targetLeft
	                }, _.options.speed, _.options.easing, callback);
	            } else {
	                _.$slideTrack.animate({
	                    top: targetLeft
	                }, _.options.speed, _.options.easing, callback);
	            }

	        } else {

	            if (_.cssTransitions === false) {
	                if (_.options.rtl === true) {
	                    _.currentLeft = -(_.currentLeft);
	                }
	                $({
	                    animStart: _.currentLeft
	                }).animate({
	                    animStart: targetLeft
	                }, {
	                    duration: _.options.speed,
	                    easing: _.options.easing,
	                    step: function(now) {
	                        now = Math.ceil(now);
	                        if (_.options.vertical === false) {
	                            animProps[_.animType] = 'translate(' +
	                                now + 'px, 0px)';
	                            _.$slideTrack.css(animProps);
	                        } else {
	                            animProps[_.animType] = 'translate(0px,' +
	                                now + 'px)';
	                            _.$slideTrack.css(animProps);
	                        }
	                    },
	                    complete: function() {
	                        if (callback) {
	                            callback.call();
	                        }
	                    }
	                });

	            } else {

	                _.applyTransition();
	                targetLeft = Math.ceil(targetLeft);

	                if (_.options.vertical === false) {
	                    animProps[_.animType] = 'translate3d(' + targetLeft + 'px, 0px, 0px)';
	                } else {
	                    animProps[_.animType] = 'translate3d(0px,' + targetLeft + 'px, 0px)';
	                }
	                _.$slideTrack.css(animProps);

	                if (callback) {
	                    setTimeout(function() {

	                        _.disableTransition();

	                        callback.call();
	                    }, _.options.speed);
	                }

	            }

	        }

	    };

	    Slick.prototype.getNavTarget = function() {

	        var _ = this,
	            asNavFor = _.options.asNavFor;

	        if ( asNavFor && asNavFor !== null ) {
	            asNavFor = $(asNavFor).not(_.$slider);
	        }

	        return asNavFor;

	    };

	    Slick.prototype.asNavFor = function(index) {

	        var _ = this,
	            asNavFor = _.getNavTarget();

	        if ( asNavFor !== null && typeof asNavFor === 'object' ) {
	            asNavFor.each(function() {
	                var target = $(this).slick('getSlick');
	                if(!target.unslicked) {
	                    target.slideHandler(index, true);
	                }
	            });
	        }

	    };

	    Slick.prototype.applyTransition = function(slide) {

	        var _ = this,
	            transition = {};

	        if (_.options.fade === false) {
	            transition[_.transitionType] = _.transformType + ' ' + _.options.speed + 'ms ' + _.options.cssEase;
	        } else {
	            transition[_.transitionType] = 'opacity ' + _.options.speed + 'ms ' + _.options.cssEase;
	        }

	        if (_.options.fade === false) {
	            _.$slideTrack.css(transition);
	        } else {
	            _.$slides.eq(slide).css(transition);
	        }

	    };

	    Slick.prototype.autoPlay = function() {

	        var _ = this;

	        _.autoPlayClear();

	        if ( _.slideCount > _.options.slidesToShow ) {
	            _.autoPlayTimer = setInterval( _.autoPlayIterator, _.options.autoplaySpeed );
	        }

	    };

	    Slick.prototype.autoPlayClear = function() {

	        var _ = this;

	        if (_.autoPlayTimer) {
	            clearInterval(_.autoPlayTimer);
	        }

	    };

	    Slick.prototype.autoPlayIterator = function() {

	        var _ = this,
	            slideTo = _.currentSlide + _.options.slidesToScroll;

	        if ( !_.paused && !_.interrupted && !_.focussed ) {

	            if ( _.options.infinite === false ) {

	                if ( _.direction === 1 && ( _.currentSlide + 1 ) === ( _.slideCount - 1 )) {
	                    _.direction = 0;
	                }

	                else if ( _.direction === 0 ) {

	                    slideTo = _.currentSlide - _.options.slidesToScroll;

	                    if ( _.currentSlide - 1 === 0 ) {
	                        _.direction = 1;
	                    }

	                }

	            }

	            _.slideHandler( slideTo );

	        }

	    };

	    Slick.prototype.buildArrows = function() {

	        var _ = this;

	        if (_.options.arrows === true ) {

	            _.$prevArrow = $(_.options.prevArrow).addClass('slick-arrow');
	            _.$nextArrow = $(_.options.nextArrow).addClass('slick-arrow');

	            if( _.slideCount > _.options.slidesToShow ) {

	                _.$prevArrow.removeClass('slick-hidden').removeAttr('aria-hidden tabindex');
	                _.$nextArrow.removeClass('slick-hidden').removeAttr('aria-hidden tabindex');

	                if (_.htmlExpr.test(_.options.prevArrow)) {
	                    _.$prevArrow.prependTo(_.options.appendArrows);
	                }

	                if (_.htmlExpr.test(_.options.nextArrow)) {
	                    _.$nextArrow.appendTo(_.options.appendArrows);
	                }

	                if (_.options.infinite !== true) {
	                    _.$prevArrow
	                        .addClass('slick-disabled')
	                        .attr('aria-disabled', 'true');
	                }

	            } else {

	                _.$prevArrow.add( _.$nextArrow )

	                    .addClass('slick-hidden')
	                    .attr({
	                        'aria-disabled': 'true',
	                        'tabindex': '-1'
	                    });

	            }

	        }

	    };

	    Slick.prototype.buildDots = function() {

	        var _ = this,
	            i, dot;

	        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

	            _.$slider.addClass('slick-dotted');

	            dot = $('<ul />').addClass(_.options.dotsClass);

	            for (i = 0; i <= _.getDotCount(); i += 1) {
	                dot.append($('<li />').append(_.options.customPaging.call(this, _, i)));
	            }

	            _.$dots = dot.appendTo(_.options.appendDots);

	            _.$dots.find('li').first().addClass('slick-active').attr('aria-hidden', 'false');

	        }

	    };

	    Slick.prototype.buildOut = function() {

	        var _ = this;

	        _.$slides =
	            _.$slider
	                .children( _.options.slide + ':not(.slick-cloned)')
	                .addClass('slick-slide');

	        _.slideCount = _.$slides.length;

	        _.$slides.each(function(index, element) {
	            $(element)
	                .attr('data-slick-index', index)
	                .data('originalStyling', $(element).attr('style') || '');
	        });

	        _.$slider.addClass('slick-slider');

	        _.$slideTrack = (_.slideCount === 0) ?
	            $('<div class="slick-track"/>').appendTo(_.$slider) :
	            _.$slides.wrapAll('<div class="slick-track"/>').parent();

	        _.$list = _.$slideTrack.wrap(
	            '<div aria-live="polite" class="slick-list"/>').parent();
	        _.$slideTrack.css('opacity', 0);

	        if (_.options.centerMode === true || _.options.swipeToSlide === true) {
	            _.options.slidesToScroll = 1;
	        }

	        $('img[data-lazy]', _.$slider).not('[src]').addClass('slick-loading');

	        _.setupInfinite();

	        _.buildArrows();

	        _.buildDots();

	        _.updateDots();


	        _.setSlideClasses(typeof _.currentSlide === 'number' ? _.currentSlide : 0);

	        if (_.options.draggable === true) {
	            _.$list.addClass('draggable');
	        }

	    };

	    Slick.prototype.buildRows = function() {

	        var _ = this, a, b, c, newSlides, numOfSlides, originalSlides,slidesPerSection;

	        newSlides = document.createDocumentFragment();
	        originalSlides = _.$slider.children();

	        if(_.options.rows > 1) {

	            slidesPerSection = _.options.slidesPerRow * _.options.rows;
	            numOfSlides = Math.ceil(
	                originalSlides.length / slidesPerSection
	            );

	            for(a = 0; a < numOfSlides; a++){
	                var slide = document.createElement('div');
	                for(b = 0; b < _.options.rows; b++) {
	                    var row = document.createElement('div');
	                    for(c = 0; c < _.options.slidesPerRow; c++) {
	                        var target = (a * slidesPerSection + ((b * _.options.slidesPerRow) + c));
	                        if (originalSlides.get(target)) {
	                            row.appendChild(originalSlides.get(target));
	                        }
	                    }
	                    slide.appendChild(row);
	                }
	                newSlides.appendChild(slide);
	            }

	            _.$slider.empty().append(newSlides);
	            _.$slider.children().children().children()
	                .css({
	                    'width':(100 / _.options.slidesPerRow) + '%',
	                    'display': 'inline-block'
	                });

	        }

	    };

	    Slick.prototype.checkResponsive = function(initial, forceUpdate) {

	        var _ = this,
	            breakpoint, targetBreakpoint, respondToWidth, triggerBreakpoint = false;
	        var sliderWidth = _.$slider.width();
	        var windowWidth = window.innerWidth || $(window).width();

	        if (_.respondTo === 'window') {
	            respondToWidth = windowWidth;
	        } else if (_.respondTo === 'slider') {
	            respondToWidth = sliderWidth;
	        } else if (_.respondTo === 'min') {
	            respondToWidth = Math.min(windowWidth, sliderWidth);
	        }

	        if ( _.options.responsive &&
	            _.options.responsive.length &&
	            _.options.responsive !== null) {

	            targetBreakpoint = null;

	            for (breakpoint in _.breakpoints) {
	                if (_.breakpoints.hasOwnProperty(breakpoint)) {
	                    if (_.originalSettings.mobileFirst === false) {
	                        if (respondToWidth < _.breakpoints[breakpoint]) {
	                            targetBreakpoint = _.breakpoints[breakpoint];
	                        }
	                    } else {
	                        if (respondToWidth > _.breakpoints[breakpoint]) {
	                            targetBreakpoint = _.breakpoints[breakpoint];
	                        }
	                    }
	                }
	            }

	            if (targetBreakpoint !== null) {
	                if (_.activeBreakpoint !== null) {
	                    if (targetBreakpoint !== _.activeBreakpoint || forceUpdate) {
	                        _.activeBreakpoint =
	                            targetBreakpoint;
	                        if (_.breakpointSettings[targetBreakpoint] === 'unslick') {
	                            _.unslick(targetBreakpoint);
	                        } else {
	                            _.options = $.extend({}, _.originalSettings,
	                                _.breakpointSettings[
	                                    targetBreakpoint]);
	                            if (initial === true) {
	                                _.currentSlide = _.options.initialSlide;
	                            }
	                            _.refresh(initial);
	                        }
	                        triggerBreakpoint = targetBreakpoint;
	                    }
	                } else {
	                    _.activeBreakpoint = targetBreakpoint;
	                    if (_.breakpointSettings[targetBreakpoint] === 'unslick') {
	                        _.unslick(targetBreakpoint);
	                    } else {
	                        _.options = $.extend({}, _.originalSettings,
	                            _.breakpointSettings[
	                                targetBreakpoint]);
	                        if (initial === true) {
	                            _.currentSlide = _.options.initialSlide;
	                        }
	                        _.refresh(initial);
	                    }
	                    triggerBreakpoint = targetBreakpoint;
	                }
	            } else {
	                if (_.activeBreakpoint !== null) {
	                    _.activeBreakpoint = null;
	                    _.options = _.originalSettings;
	                    if (initial === true) {
	                        _.currentSlide = _.options.initialSlide;
	                    }
	                    _.refresh(initial);
	                    triggerBreakpoint = targetBreakpoint;
	                }
	            }

	            // only trigger breakpoints during an actual break. not on initialize.
	            if( !initial && triggerBreakpoint !== false ) {
	                _.$slider.trigger('breakpoint', [_, triggerBreakpoint]);
	            }
	        }

	    };

	    Slick.prototype.changeSlide = function(event, dontAnimate) {

	        var _ = this,
	            $target = $(event.currentTarget),
	            indexOffset, slideOffset, unevenOffset;

	        // If target is a link, prevent default action.
	        if($target.is('a')) {
	            event.preventDefault();
	        }

	        // If target is not the <li> element (ie: a child), find the <li>.
	        if(!$target.is('li')) {
	            $target = $target.closest('li');
	        }

	        unevenOffset = (_.slideCount % _.options.slidesToScroll !== 0);
	        indexOffset = unevenOffset ? 0 : (_.slideCount - _.currentSlide) % _.options.slidesToScroll;

	        switch (event.data.message) {

	            case 'previous':
	                slideOffset = indexOffset === 0 ? _.options.slidesToScroll : _.options.slidesToShow - indexOffset;
	                if (_.slideCount > _.options.slidesToShow) {
	                    _.slideHandler(_.currentSlide - slideOffset, false, dontAnimate);
	                }
	                break;

	            case 'next':
	                slideOffset = indexOffset === 0 ? _.options.slidesToScroll : indexOffset;
	                if (_.slideCount > _.options.slidesToShow) {
	                    _.slideHandler(_.currentSlide + slideOffset, false, dontAnimate);
	                }
	                break;

	            case 'index':
	                var index = event.data.index === 0 ? 0 :
	                    event.data.index || $target.index() * _.options.slidesToScroll;

	                _.slideHandler(_.checkNavigable(index), false, dontAnimate);
	                $target.children().trigger('focus');
	                break;

	            default:
	                return;
	        }

	    };

	    Slick.prototype.checkNavigable = function(index) {

	        var _ = this,
	            navigables, prevNavigable;

	        navigables = _.getNavigableIndexes();
	        prevNavigable = 0;
	        if (index > navigables[navigables.length - 1]) {
	            index = navigables[navigables.length - 1];
	        } else {
	            for (var n in navigables) {
	                if (index < navigables[n]) {
	                    index = prevNavigable;
	                    break;
	                }
	                prevNavigable = navigables[n];
	            }
	        }

	        return index;
	    };

	    Slick.prototype.cleanUpEvents = function() {

	        var _ = this;

	        if (_.options.dots && _.$dots !== null) {

	            $('li', _.$dots)
	                .off('click.slick', _.changeSlide)
	                .off('mouseenter.slick', $.proxy(_.interrupt, _, true))
	                .off('mouseleave.slick', $.proxy(_.interrupt, _, false));

	        }

	        _.$slider.off('focus.slick blur.slick');

	        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {
	            _.$prevArrow && _.$prevArrow.off('click.slick', _.changeSlide);
	            _.$nextArrow && _.$nextArrow.off('click.slick', _.changeSlide);
	        }

	        _.$list.off('touchstart.slick mousedown.slick', _.swipeHandler);
	        _.$list.off('touchmove.slick mousemove.slick', _.swipeHandler);
	        _.$list.off('touchend.slick mouseup.slick', _.swipeHandler);
	        _.$list.off('touchcancel.slick mouseleave.slick', _.swipeHandler);

	        _.$list.off('click.slick', _.clickHandler);

	        $(document).off(_.visibilityChange, _.visibility);

	        _.cleanUpSlideEvents();

	        if (_.options.accessibility === true) {
	            _.$list.off('keydown.slick', _.keyHandler);
	        }

	        if (_.options.focusOnSelect === true) {
	            $(_.$slideTrack).children().off('click.slick', _.selectHandler);
	        }

	        $(window).off('orientationchange.slick.slick-' + _.instanceUid, _.orientationChange);

	        $(window).off('resize.slick.slick-' + _.instanceUid, _.resize);

	        $('[draggable!=true]', _.$slideTrack).off('dragstart', _.preventDefault);

	        $(window).off('load.slick.slick-' + _.instanceUid, _.setPosition);
	        $(document).off('ready.slick.slick-' + _.instanceUid, _.setPosition);

	    };

	    Slick.prototype.cleanUpSlideEvents = function() {

	        var _ = this;

	        _.$list.off('mouseenter.slick', $.proxy(_.interrupt, _, true));
	        _.$list.off('mouseleave.slick', $.proxy(_.interrupt, _, false));

	    };

	    Slick.prototype.cleanUpRows = function() {

	        var _ = this, originalSlides;

	        if(_.options.rows > 1) {
	            originalSlides = _.$slides.children().children();
	            originalSlides.removeAttr('style');
	            _.$slider.empty().append(originalSlides);
	        }

	    };

	    Slick.prototype.clickHandler = function(event) {

	        var _ = this;

	        if (_.shouldClick === false) {
	            event.stopImmediatePropagation();
	            event.stopPropagation();
	            event.preventDefault();
	        }

	    };

	    Slick.prototype.destroy = function(refresh) {

	        var _ = this;

	        _.autoPlayClear();

	        _.touchObject = {};

	        _.cleanUpEvents();

	        $('.slick-cloned', _.$slider).detach();

	        if (_.$dots) {
	            _.$dots.remove();
	        }


	        if ( _.$prevArrow && _.$prevArrow.length ) {

	            _.$prevArrow
	                .removeClass('slick-disabled slick-arrow slick-hidden')
	                .removeAttr('aria-hidden aria-disabled tabindex')
	                .css('display','');

	            if ( _.htmlExpr.test( _.options.prevArrow )) {
	                _.$prevArrow.remove();
	            }
	        }

	        if ( _.$nextArrow && _.$nextArrow.length ) {

	            _.$nextArrow
	                .removeClass('slick-disabled slick-arrow slick-hidden')
	                .removeAttr('aria-hidden aria-disabled tabindex')
	                .css('display','');

	            if ( _.htmlExpr.test( _.options.nextArrow )) {
	                _.$nextArrow.remove();
	            }

	        }


	        if (_.$slides) {

	            _.$slides
	                .removeClass('slick-slide slick-active slick-center slick-visible slick-current')
	                .removeAttr('aria-hidden')
	                .removeAttr('data-slick-index')
	                .each(function(){
	                    $(this).attr('style', $(this).data('originalStyling'));
	                });

	            _.$slideTrack.children(this.options.slide).detach();

	            _.$slideTrack.detach();

	            _.$list.detach();

	            _.$slider.append(_.$slides);
	        }

	        _.cleanUpRows();

	        _.$slider.removeClass('slick-slider');
	        _.$slider.removeClass('slick-initialized');
	        _.$slider.removeClass('slick-dotted');

	        _.unslicked = true;

	        if(!refresh) {
	            _.$slider.trigger('destroy', [_]);
	        }

	    };

	    Slick.prototype.disableTransition = function(slide) {

	        var _ = this,
	            transition = {};

	        transition[_.transitionType] = '';

	        if (_.options.fade === false) {
	            _.$slideTrack.css(transition);
	        } else {
	            _.$slides.eq(slide).css(transition);
	        }

	    };

	    Slick.prototype.fadeSlide = function(slideIndex, callback) {

	        var _ = this;

	        if (_.cssTransitions === false) {

	            _.$slides.eq(slideIndex).css({
	                zIndex: _.options.zIndex
	            });

	            _.$slides.eq(slideIndex).animate({
	                opacity: 1
	            }, _.options.speed, _.options.easing, callback);

	        } else {

	            _.applyTransition(slideIndex);

	            _.$slides.eq(slideIndex).css({
	                opacity: 1,
	                zIndex: _.options.zIndex
	            });

	            if (callback) {
	                setTimeout(function() {

	                    _.disableTransition(slideIndex);

	                    callback.call();
	                }, _.options.speed);
	            }

	        }

	    };

	    Slick.prototype.fadeSlideOut = function(slideIndex) {

	        var _ = this;

	        if (_.cssTransitions === false) {

	            _.$slides.eq(slideIndex).animate({
	                opacity: 0,
	                zIndex: _.options.zIndex - 2
	            }, _.options.speed, _.options.easing);

	        } else {

	            _.applyTransition(slideIndex);

	            _.$slides.eq(slideIndex).css({
	                opacity: 0,
	                zIndex: _.options.zIndex - 2
	            });

	        }

	    };

	    Slick.prototype.filterSlides = Slick.prototype.slickFilter = function(filter) {

	        var _ = this;

	        if (filter !== null) {

	            _.$slidesCache = _.$slides;

	            _.unload();

	            _.$slideTrack.children(this.options.slide).detach();

	            _.$slidesCache.filter(filter).appendTo(_.$slideTrack);

	            _.reinit();

	        }

	    };

	    Slick.prototype.focusHandler = function() {

	        var _ = this;

	        _.$slider
	            .off('focus.slick blur.slick')
	            .on('focus.slick blur.slick',
	                '*:not(.slick-arrow)', function(event) {

	            event.stopImmediatePropagation();
	            var $sf = $(this);

	            setTimeout(function() {

	                if( _.options.pauseOnFocus ) {
	                    _.focussed = $sf.is(':focus');
	                    _.autoPlay();
	                }

	            }, 0);

	        });
	    };

	    Slick.prototype.getCurrent = Slick.prototype.slickCurrentSlide = function() {

	        var _ = this;
	        return _.currentSlide;

	    };

	    Slick.prototype.getDotCount = function() {

	        var _ = this;

	        var breakPoint = 0;
	        var counter = 0;
	        var pagerQty = 0;

	        if (_.options.infinite === true) {
	            while (breakPoint < _.slideCount) {
	                ++pagerQty;
	                breakPoint = counter + _.options.slidesToScroll;
	                counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
	            }
	        } else if (_.options.centerMode === true) {
	            pagerQty = _.slideCount;
	        } else if(!_.options.asNavFor) {
	            pagerQty = 1 + Math.ceil((_.slideCount - _.options.slidesToShow) / _.options.slidesToScroll);
	        }else {
	            while (breakPoint < _.slideCount) {
	                ++pagerQty;
	                breakPoint = counter + _.options.slidesToScroll;
	                counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
	            }
	        }

	        return pagerQty - 1;

	    };

	    Slick.prototype.getLeft = function(slideIndex) {

	        var _ = this,
	            targetLeft,
	            verticalHeight,
	            verticalOffset = 0,
	            targetSlide;

	        _.slideOffset = 0;
	        verticalHeight = _.$slides.first().outerHeight(true);

	        if (_.options.infinite === true) {
	            if (_.slideCount > _.options.slidesToShow) {
	                _.slideOffset = (_.slideWidth * _.options.slidesToShow) * -1;
	                verticalOffset = (verticalHeight * _.options.slidesToShow) * -1;
	            }
	            if (_.slideCount % _.options.slidesToScroll !== 0) {
	                if (slideIndex + _.options.slidesToScroll > _.slideCount && _.slideCount > _.options.slidesToShow) {
	                    if (slideIndex > _.slideCount) {
	                        _.slideOffset = ((_.options.slidesToShow - (slideIndex - _.slideCount)) * _.slideWidth) * -1;
	                        verticalOffset = ((_.options.slidesToShow - (slideIndex - _.slideCount)) * verticalHeight) * -1;
	                    } else {
	                        _.slideOffset = ((_.slideCount % _.options.slidesToScroll) * _.slideWidth) * -1;
	                        verticalOffset = ((_.slideCount % _.options.slidesToScroll) * verticalHeight) * -1;
	                    }
	                }
	            }
	        } else {
	            if (slideIndex + _.options.slidesToShow > _.slideCount) {
	                _.slideOffset = ((slideIndex + _.options.slidesToShow) - _.slideCount) * _.slideWidth;
	                verticalOffset = ((slideIndex + _.options.slidesToShow) - _.slideCount) * verticalHeight;
	            }
	        }

	        if (_.slideCount <= _.options.slidesToShow) {
	            _.slideOffset = 0;
	            verticalOffset = 0;
	        }

	        if (_.options.centerMode === true && _.options.infinite === true) {
	            _.slideOffset += _.slideWidth * Math.floor(_.options.slidesToShow / 2) - _.slideWidth;
	        } else if (_.options.centerMode === true) {
	            _.slideOffset = 0;
	            _.slideOffset += _.slideWidth * Math.floor(_.options.slidesToShow / 2);
	        }

	        if (_.options.vertical === false) {
	            targetLeft = ((slideIndex * _.slideWidth) * -1) + _.slideOffset;
	        } else {
	            targetLeft = ((slideIndex * verticalHeight) * -1) + verticalOffset;
	        }

	        if (_.options.variableWidth === true) {

	            if (_.slideCount <= _.options.slidesToShow || _.options.infinite === false) {
	                targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex);
	            } else {
	                targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex + _.options.slidesToShow);
	            }

	            if (_.options.rtl === true) {
	                if (targetSlide[0]) {
	                    targetLeft = (_.$slideTrack.width() - targetSlide[0].offsetLeft - targetSlide.width()) * -1;
	                } else {
	                    targetLeft =  0;
	                }
	            } else {
	                targetLeft = targetSlide[0] ? targetSlide[0].offsetLeft * -1 : 0;
	            }

	            if (_.options.centerMode === true) {
	                if (_.slideCount <= _.options.slidesToShow || _.options.infinite === false) {
	                    targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex);
	                } else {
	                    targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex + _.options.slidesToShow + 1);
	                }

	                if (_.options.rtl === true) {
	                    if (targetSlide[0]) {
	                        targetLeft = (_.$slideTrack.width() - targetSlide[0].offsetLeft - targetSlide.width()) * -1;
	                    } else {
	                        targetLeft =  0;
	                    }
	                } else {
	                    targetLeft = targetSlide[0] ? targetSlide[0].offsetLeft * -1 : 0;
	                }

	                targetLeft += (_.$list.width() - targetSlide.outerWidth()) / 2;
	            }
	        }

	        return targetLeft;

	    };

	    Slick.prototype.getOption = Slick.prototype.slickGetOption = function(option) {

	        var _ = this;

	        return _.options[option];

	    };

	    Slick.prototype.getNavigableIndexes = function() {

	        var _ = this,
	            breakPoint = 0,
	            counter = 0,
	            indexes = [],
	            max;

	        if (_.options.infinite === false) {
	            max = _.slideCount;
	        } else {
	            breakPoint = _.options.slidesToScroll * -1;
	            counter = _.options.slidesToScroll * -1;
	            max = _.slideCount * 2;
	        }

	        while (breakPoint < max) {
	            indexes.push(breakPoint);
	            breakPoint = counter + _.options.slidesToScroll;
	            counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
	        }

	        return indexes;

	    };

	    Slick.prototype.getSlick = function() {

	        return this;

	    };

	    Slick.prototype.getSlideCount = function() {

	        var _ = this,
	            slidesTraversed, swipedSlide, centerOffset;

	        centerOffset = _.options.centerMode === true ? _.slideWidth * Math.floor(_.options.slidesToShow / 2) : 0;

	        if (_.options.swipeToSlide === true) {
	            _.$slideTrack.find('.slick-slide').each(function(index, slide) {
	                if (slide.offsetLeft - centerOffset + ($(slide).outerWidth() / 2) > (_.swipeLeft * -1)) {
	                    swipedSlide = slide;
	                    return false;
	                }
	            });

	            slidesTraversed = Math.abs($(swipedSlide).attr('data-slick-index') - _.currentSlide) || 1;

	            return slidesTraversed;

	        } else {
	            return _.options.slidesToScroll;
	        }

	    };

	    Slick.prototype.goTo = Slick.prototype.slickGoTo = function(slide, dontAnimate) {

	        var _ = this;

	        _.changeSlide({
	            data: {
	                message: 'index',
	                index: parseInt(slide)
	            }
	        }, dontAnimate);

	    };

	    Slick.prototype.init = function(creation) {

	        var _ = this;

	        if (!$(_.$slider).hasClass('slick-initialized')) {

	            $(_.$slider).addClass('slick-initialized');

	            _.buildRows();
	            _.buildOut();
	            _.setProps();
	            _.startLoad();
	            _.loadSlider();
	            _.initializeEvents();
	            _.updateArrows();
	            _.updateDots();
	            _.checkResponsive(true);
	            _.focusHandler();

	        }

	        if (creation) {
	            _.$slider.trigger('init', [_]);
	        }

	        if (_.options.accessibility === true) {
	            _.initADA();
	        }

	        if ( _.options.autoplay ) {

	            _.paused = false;
	            _.autoPlay();

	        }

	    };

	    Slick.prototype.initADA = function() {
	        var _ = this;
	        _.$slides.add(_.$slideTrack.find('.slick-cloned')).attr({
	            'aria-hidden': 'true',
	            'tabindex': '-1'
	        }).find('a, input, button, select').attr({
	            'tabindex': '-1'
	        });

	        _.$slideTrack.attr('role', 'listbox');

	        _.$slides.not(_.$slideTrack.find('.slick-cloned')).each(function(i) {
	            $(this).attr({
	                'role': 'option',
	                'aria-describedby': 'slick-slide' + _.instanceUid + i + ''
	            });
	        });

	        if (_.$dots !== null) {
	            _.$dots.attr('role', 'tablist').find('li').each(function(i) {
	                $(this).attr({
	                    'role': 'presentation',
	                    'aria-selected': 'false',
	                    'aria-controls': 'navigation' + _.instanceUid + i + '',
	                    'id': 'slick-slide' + _.instanceUid + i + ''
	                });
	            })
	                .first().attr('aria-selected', 'true').end()
	                .find('button').attr('role', 'button').end()
	                .closest('div').attr('role', 'toolbar');
	        }
	        _.activateADA();

	    };

	    Slick.prototype.initArrowEvents = function() {

	        var _ = this;

	        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {
	            _.$prevArrow
	               .off('click.slick')
	               .on('click.slick', {
	                    message: 'previous'
	               }, _.changeSlide);
	            _.$nextArrow
	               .off('click.slick')
	               .on('click.slick', {
	                    message: 'next'
	               }, _.changeSlide);
	        }

	    };

	    Slick.prototype.initDotEvents = function() {

	        var _ = this;

	        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {
	            $('li', _.$dots).on('click.slick', {
	                message: 'index'
	            }, _.changeSlide);
	        }

	        if ( _.options.dots === true && _.options.pauseOnDotsHover === true ) {

	            $('li', _.$dots)
	                .on('mouseenter.slick', $.proxy(_.interrupt, _, true))
	                .on('mouseleave.slick', $.proxy(_.interrupt, _, false));

	        }

	    };

	    Slick.prototype.initSlideEvents = function() {

	        var _ = this;

	        if ( _.options.pauseOnHover ) {

	            _.$list.on('mouseenter.slick', $.proxy(_.interrupt, _, true));
	            _.$list.on('mouseleave.slick', $.proxy(_.interrupt, _, false));

	        }

	    };

	    Slick.prototype.initializeEvents = function() {

	        var _ = this;

	        _.initArrowEvents();

	        _.initDotEvents();
	        _.initSlideEvents();

	        _.$list.on('touchstart.slick mousedown.slick', {
	            action: 'start'
	        }, _.swipeHandler);
	        _.$list.on('touchmove.slick mousemove.slick', {
	            action: 'move'
	        }, _.swipeHandler);
	        _.$list.on('touchend.slick mouseup.slick', {
	            action: 'end'
	        }, _.swipeHandler);
	        _.$list.on('touchcancel.slick mouseleave.slick', {
	            action: 'end'
	        }, _.swipeHandler);

	        _.$list.on('click.slick', _.clickHandler);

	        $(document).on(_.visibilityChange, $.proxy(_.visibility, _));

	        if (_.options.accessibility === true) {
	            _.$list.on('keydown.slick', _.keyHandler);
	        }

	        if (_.options.focusOnSelect === true) {
	            $(_.$slideTrack).children().on('click.slick', _.selectHandler);
	        }

	        $(window).on('orientationchange.slick.slick-' + _.instanceUid, $.proxy(_.orientationChange, _));

	        $(window).on('resize.slick.slick-' + _.instanceUid, $.proxy(_.resize, _));

	        $('[draggable!=true]', _.$slideTrack).on('dragstart', _.preventDefault);

	        $(window).on('load.slick.slick-' + _.instanceUid, _.setPosition);
	        $(document).on('ready.slick.slick-' + _.instanceUid, _.setPosition);

	    };

	    Slick.prototype.initUI = function() {

	        var _ = this;

	        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {

	            _.$prevArrow.show();
	            _.$nextArrow.show();

	        }

	        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

	            _.$dots.show();

	        }

	    };

	    Slick.prototype.keyHandler = function(event) {

	        var _ = this;
	         //Dont slide if the cursor is inside the form fields and arrow keys are pressed
	        if(!event.target.tagName.match('TEXTAREA|INPUT|SELECT')) {
	            if (event.keyCode === 37 && _.options.accessibility === true) {
	                _.changeSlide({
	                    data: {
	                        message: _.options.rtl === true ? 'next' :  'previous'
	                    }
	                });
	            } else if (event.keyCode === 39 && _.options.accessibility === true) {
	                _.changeSlide({
	                    data: {
	                        message: _.options.rtl === true ? 'previous' : 'next'
	                    }
	                });
	            }
	        }

	    };

	    Slick.prototype.lazyLoad = function() {

	        var _ = this,
	            loadRange, cloneRange, rangeStart, rangeEnd;

	        function loadImages(imagesScope) {

	            $('img[data-lazy]', imagesScope).each(function() {

	                var image = $(this),
	                    imageSource = $(this).attr('data-lazy'),
	                    imageToLoad = document.createElement('img');

	                imageToLoad.onload = function() {

	                    image
	                        .animate({ opacity: 0 }, 100, function() {
	                            image
	                                .attr('src', imageSource)
	                                .animate({ opacity: 1 }, 200, function() {
	                                    image
	                                        .removeAttr('data-lazy')
	                                        .removeClass('slick-loading');
	                                });
	                            _.$slider.trigger('lazyLoaded', [_, image, imageSource]);
	                        });

	                };

	                imageToLoad.onerror = function() {

	                    image
	                        .removeAttr( 'data-lazy' )
	                        .removeClass( 'slick-loading' )
	                        .addClass( 'slick-lazyload-error' );

	                    _.$slider.trigger('lazyLoadError', [ _, image, imageSource ]);

	                };

	                imageToLoad.src = imageSource;

	            });

	        }

	        if (_.options.centerMode === true) {
	            if (_.options.infinite === true) {
	                rangeStart = _.currentSlide + (_.options.slidesToShow / 2 + 1);
	                rangeEnd = rangeStart + _.options.slidesToShow + 2;
	            } else {
	                rangeStart = Math.max(0, _.currentSlide - (_.options.slidesToShow / 2 + 1));
	                rangeEnd = 2 + (_.options.slidesToShow / 2 + 1) + _.currentSlide;
	            }
	        } else {
	            rangeStart = _.options.infinite ? _.options.slidesToShow + _.currentSlide : _.currentSlide;
	            rangeEnd = Math.ceil(rangeStart + _.options.slidesToShow);
	            if (_.options.fade === true) {
	                if (rangeStart > 0) rangeStart--;
	                if (rangeEnd <= _.slideCount) rangeEnd++;
	            }
	        }

	        loadRange = _.$slider.find('.slick-slide').slice(rangeStart, rangeEnd);
	        loadImages(loadRange);

	        if (_.slideCount <= _.options.slidesToShow) {
	            cloneRange = _.$slider.find('.slick-slide');
	            loadImages(cloneRange);
	        } else
	        if (_.currentSlide >= _.slideCount - _.options.slidesToShow) {
	            cloneRange = _.$slider.find('.slick-cloned').slice(0, _.options.slidesToShow);
	            loadImages(cloneRange);
	        } else if (_.currentSlide === 0) {
	            cloneRange = _.$slider.find('.slick-cloned').slice(_.options.slidesToShow * -1);
	            loadImages(cloneRange);
	        }

	    };

	    Slick.prototype.loadSlider = function() {

	        var _ = this;

	        _.setPosition();

	        _.$slideTrack.css({
	            opacity: 1
	        });

	        _.$slider.removeClass('slick-loading');

	        _.initUI();

	        if (_.options.lazyLoad === 'progressive') {
	            _.progressiveLazyLoad();
	        }

	    };

	    Slick.prototype.next = Slick.prototype.slickNext = function() {

	        var _ = this;

	        _.changeSlide({
	            data: {
	                message: 'next'
	            }
	        });

	    };

	    Slick.prototype.orientationChange = function() {

	        var _ = this;

	        _.checkResponsive();
	        _.setPosition();

	    };

	    Slick.prototype.pause = Slick.prototype.slickPause = function() {

	        var _ = this;

	        _.autoPlayClear();
	        _.paused = true;

	    };

	    Slick.prototype.play = Slick.prototype.slickPlay = function() {

	        var _ = this;

	        _.autoPlay();
	        _.options.autoplay = true;
	        _.paused = false;
	        _.focussed = false;
	        _.interrupted = false;

	    };

	    Slick.prototype.postSlide = function(index) {

	        var _ = this;

	        if( !_.unslicked ) {

	            _.$slider.trigger('afterChange', [_, index]);

	            _.animating = false;

	            _.setPosition();

	            _.swipeLeft = null;

	            if ( _.options.autoplay ) {
	                _.autoPlay();
	            }

	            if (_.options.accessibility === true) {
	                _.initADA();
	            }

	        }

	    };

	    Slick.prototype.prev = Slick.prototype.slickPrev = function() {

	        var _ = this;

	        _.changeSlide({
	            data: {
	                message: 'previous'
	            }
	        });

	    };

	    Slick.prototype.preventDefault = function(event) {

	        event.preventDefault();

	    };

	    Slick.prototype.progressiveLazyLoad = function( tryCount ) {

	        tryCount = tryCount || 1;

	        var _ = this,
	            $imgsToLoad = $( 'img[data-lazy]', _.$slider ),
	            image,
	            imageSource,
	            imageToLoad;

	        if ( $imgsToLoad.length ) {

	            image = $imgsToLoad.first();
	            imageSource = image.attr('data-lazy');
	            imageToLoad = document.createElement('img');

	            imageToLoad.onload = function() {

	                image
	                    .attr( 'src', imageSource )
	                    .removeAttr('data-lazy')
	                    .removeClass('slick-loading');

	                if ( _.options.adaptiveHeight === true ) {
	                    _.setPosition();
	                }

	                _.$slider.trigger('lazyLoaded', [ _, image, imageSource ]);
	                _.progressiveLazyLoad();

	            };

	            imageToLoad.onerror = function() {

	                if ( tryCount < 3 ) {

	                    /**
	                     * try to load the image 3 times,
	                     * leave a slight delay so we don't get
	                     * servers blocking the request.
	                     */
	                    setTimeout( function() {
	                        _.progressiveLazyLoad( tryCount + 1 );
	                    }, 500 );

	                } else {

	                    image
	                        .removeAttr( 'data-lazy' )
	                        .removeClass( 'slick-loading' )
	                        .addClass( 'slick-lazyload-error' );

	                    _.$slider.trigger('lazyLoadError', [ _, image, imageSource ]);

	                    _.progressiveLazyLoad();

	                }

	            };

	            imageToLoad.src = imageSource;

	        } else {

	            _.$slider.trigger('allImagesLoaded', [ _ ]);

	        }

	    };

	    Slick.prototype.refresh = function( initializing ) {

	        var _ = this, currentSlide, lastVisibleIndex;

	        lastVisibleIndex = _.slideCount - _.options.slidesToShow;

	        // in non-infinite sliders, we don't want to go past the
	        // last visible index.
	        if( !_.options.infinite && ( _.currentSlide > lastVisibleIndex )) {
	            _.currentSlide = lastVisibleIndex;
	        }

	        // if less slides than to show, go to start.
	        if ( _.slideCount <= _.options.slidesToShow ) {
	            _.currentSlide = 0;

	        }

	        currentSlide = _.currentSlide;

	        _.destroy(true);

	        $.extend(_, _.initials, { currentSlide: currentSlide });

	        _.init();

	        if( !initializing ) {

	            _.changeSlide({
	                data: {
	                    message: 'index',
	                    index: currentSlide
	                }
	            }, false);

	        }

	    };

	    Slick.prototype.registerBreakpoints = function() {

	        var _ = this, breakpoint, currentBreakpoint, l,
	            responsiveSettings = _.options.responsive || null;

	        if ( $.type(responsiveSettings) === 'array' && responsiveSettings.length ) {

	            _.respondTo = _.options.respondTo || 'window';

	            for ( breakpoint in responsiveSettings ) {

	                l = _.breakpoints.length-1;
	                currentBreakpoint = responsiveSettings[breakpoint].breakpoint;

	                if (responsiveSettings.hasOwnProperty(breakpoint)) {

	                    // loop through the breakpoints and cut out any existing
	                    // ones with the same breakpoint number, we don't want dupes.
	                    while( l >= 0 ) {
	                        if( _.breakpoints[l] && _.breakpoints[l] === currentBreakpoint ) {
	                            _.breakpoints.splice(l,1);
	                        }
	                        l--;
	                    }

	                    _.breakpoints.push(currentBreakpoint);
	                    _.breakpointSettings[currentBreakpoint] = responsiveSettings[breakpoint].settings;

	                }

	            }

	            _.breakpoints.sort(function(a, b) {
	                return ( _.options.mobileFirst ) ? a-b : b-a;
	            });

	        }

	    };

	    Slick.prototype.reinit = function() {

	        var _ = this;

	        _.$slides =
	            _.$slideTrack
	                .children(_.options.slide)
	                .addClass('slick-slide');

	        _.slideCount = _.$slides.length;

	        if (_.currentSlide >= _.slideCount && _.currentSlide !== 0) {
	            _.currentSlide = _.currentSlide - _.options.slidesToScroll;
	        }

	        if (_.slideCount <= _.options.slidesToShow) {
	            _.currentSlide = 0;
	        }

	        _.registerBreakpoints();

	        _.setProps();
	        _.setupInfinite();
	        _.buildArrows();
	        _.updateArrows();
	        _.initArrowEvents();
	        _.buildDots();
	        _.updateDots();
	        _.initDotEvents();
	        _.cleanUpSlideEvents();
	        _.initSlideEvents();

	        _.checkResponsive(false, true);

	        if (_.options.focusOnSelect === true) {
	            $(_.$slideTrack).children().on('click.slick', _.selectHandler);
	        }

	        _.setSlideClasses(typeof _.currentSlide === 'number' ? _.currentSlide : 0);

	        _.setPosition();
	        _.focusHandler();

	        _.paused = !_.options.autoplay;
	        _.autoPlay();

	        _.$slider.trigger('reInit', [_]);

	    };

	    Slick.prototype.resize = function() {

	        var _ = this;

	        if ($(window).width() !== _.windowWidth) {
	            clearTimeout(_.windowDelay);
	            _.windowDelay = window.setTimeout(function() {
	                _.windowWidth = $(window).width();
	                _.checkResponsive();
	                if( !_.unslicked ) { _.setPosition(); }
	            }, 50);
	        }
	    };

	    Slick.prototype.removeSlide = Slick.prototype.slickRemove = function(index, removeBefore, removeAll) {

	        var _ = this;

	        if (typeof(index) === 'boolean') {
	            removeBefore = index;
	            index = removeBefore === true ? 0 : _.slideCount - 1;
	        } else {
	            index = removeBefore === true ? --index : index;
	        }

	        if (_.slideCount < 1 || index < 0 || index > _.slideCount - 1) {
	            return false;
	        }

	        _.unload();

	        if (removeAll === true) {
	            _.$slideTrack.children().remove();
	        } else {
	            _.$slideTrack.children(this.options.slide).eq(index).remove();
	        }

	        _.$slides = _.$slideTrack.children(this.options.slide);

	        _.$slideTrack.children(this.options.slide).detach();

	        _.$slideTrack.append(_.$slides);

	        _.$slidesCache = _.$slides;

	        _.reinit();

	    };

	    Slick.prototype.setCSS = function(position) {

	        var _ = this,
	            positionProps = {},
	            x, y;

	        if (_.options.rtl === true) {
	            position = -position;
	        }
	        x = _.positionProp == 'left' ? Math.ceil(position) + 'px' : '0px';
	        y = _.positionProp == 'top' ? Math.ceil(position) + 'px' : '0px';

	        positionProps[_.positionProp] = position;

	        if (_.transformsEnabled === false) {
	            _.$slideTrack.css(positionProps);
	        } else {
	            positionProps = {};
	            if (_.cssTransitions === false) {
	                positionProps[_.animType] = 'translate(' + x + ', ' + y + ')';
	                _.$slideTrack.css(positionProps);
	            } else {
	                positionProps[_.animType] = 'translate3d(' + x + ', ' + y + ', 0px)';
	                _.$slideTrack.css(positionProps);
	            }
	        }

	    };

	    Slick.prototype.setDimensions = function() {

	        var _ = this;

	        if (_.options.vertical === false) {
	            if (_.options.centerMode === true) {
	                _.$list.css({
	                    padding: ('0px ' + _.options.centerPadding)
	                });
	            }
	        } else {
	            _.$list.height(_.$slides.first().outerHeight(true) * _.options.slidesToShow);
	            if (_.options.centerMode === true) {
	                _.$list.css({
	                    padding: (_.options.centerPadding + ' 0px')
	                });
	            }
	        }

	        _.listWidth = _.$list.width();
	        _.listHeight = _.$list.height();


	        if (_.options.vertical === false && _.options.variableWidth === false) {
	            _.slideWidth = Math.ceil(_.listWidth / _.options.slidesToShow);
	            _.$slideTrack.width(Math.ceil((_.slideWidth * _.$slideTrack.children('.slick-slide').length)));

	        } else if (_.options.variableWidth === true) {
	            _.$slideTrack.width(5000 * _.slideCount);
	        } else {
	            _.slideWidth = Math.ceil(_.listWidth);
	            _.$slideTrack.height(Math.ceil((_.$slides.first().outerHeight(true) * _.$slideTrack.children('.slick-slide').length)));
	        }

	        var offset = _.$slides.first().outerWidth(true) - _.$slides.first().width();
	        if (_.options.variableWidth === false) _.$slideTrack.children('.slick-slide').width(_.slideWidth - offset);

	    };

	    Slick.prototype.setFade = function() {

	        var _ = this,
	            targetLeft;

	        _.$slides.each(function(index, element) {
	            targetLeft = (_.slideWidth * index) * -1;
	            if (_.options.rtl === true) {
	                $(element).css({
	                    position: 'relative',
	                    right: targetLeft,
	                    top: 0,
	                    zIndex: _.options.zIndex - 2,
	                    opacity: 0
	                });
	            } else {
	                $(element).css({
	                    position: 'relative',
	                    left: targetLeft,
	                    top: 0,
	                    zIndex: _.options.zIndex - 2,
	                    opacity: 0
	                });
	            }
	        });

	        _.$slides.eq(_.currentSlide).css({
	            zIndex: _.options.zIndex - 1,
	            opacity: 1
	        });

	    };

	    Slick.prototype.setHeight = function() {

	        var _ = this;

	        if (_.options.slidesToShow === 1 && _.options.adaptiveHeight === true && _.options.vertical === false) {
	            var targetHeight = _.$slides.eq(_.currentSlide).outerHeight(true);
	            _.$list.css('height', targetHeight);
	        }

	    };

	    Slick.prototype.setOption =
	    Slick.prototype.slickSetOption = function() {

	        /**
	         * accepts arguments in format of:
	         *
	         *  - for changing a single option's value:
	         *     .slick("setOption", option, value, refresh )
	         *
	         *  - for changing a set of responsive options:
	         *     .slick("setOption", 'responsive', [{}, ...], refresh )
	         *
	         *  - for updating multiple values at once (not responsive)
	         *     .slick("setOption", { 'option': value, ... }, refresh )
	         */

	        var _ = this, l, item, option, value, refresh = false, type;

	        if( $.type( arguments[0] ) === 'object' ) {

	            option =  arguments[0];
	            refresh = arguments[1];
	            type = 'multiple';

	        } else if ( $.type( arguments[0] ) === 'string' ) {

	            option =  arguments[0];
	            value = arguments[1];
	            refresh = arguments[2];

	            if ( arguments[0] === 'responsive' && $.type( arguments[1] ) === 'array' ) {

	                type = 'responsive';

	            } else if ( typeof arguments[1] !== 'undefined' ) {

	                type = 'single';

	            }

	        }

	        if ( type === 'single' ) {

	            _.options[option] = value;


	        } else if ( type === 'multiple' ) {

	            $.each( option , function( opt, val ) {

	                _.options[opt] = val;

	            });


	        } else if ( type === 'responsive' ) {

	            for ( item in value ) {

	                if( $.type( _.options.responsive ) !== 'array' ) {

	                    _.options.responsive = [ value[item] ];

	                } else {

	                    l = _.options.responsive.length-1;

	                    // loop through the responsive object and splice out duplicates.
	                    while( l >= 0 ) {

	                        if( _.options.responsive[l].breakpoint === value[item].breakpoint ) {

	                            _.options.responsive.splice(l,1);

	                        }

	                        l--;

	                    }

	                    _.options.responsive.push( value[item] );

	                }

	            }

	        }

	        if ( refresh ) {

	            _.unload();
	            _.reinit();

	        }

	    };

	    Slick.prototype.setPosition = function() {

	        var _ = this;

	        _.setDimensions();

	        _.setHeight();

	        if (_.options.fade === false) {
	            _.setCSS(_.getLeft(_.currentSlide));
	        } else {
	            _.setFade();
	        }

	        _.$slider.trigger('setPosition', [_]);

	    };

	    Slick.prototype.setProps = function() {

	        var _ = this,
	            bodyStyle = document.body.style;

	        _.positionProp = _.options.vertical === true ? 'top' : 'left';

	        if (_.positionProp === 'top') {
	            _.$slider.addClass('slick-vertical');
	        } else {
	            _.$slider.removeClass('slick-vertical');
	        }

	        if (bodyStyle.WebkitTransition !== undefined ||
	            bodyStyle.MozTransition !== undefined ||
	            bodyStyle.msTransition !== undefined) {
	            if (_.options.useCSS === true) {
	                _.cssTransitions = true;
	            }
	        }

	        if ( _.options.fade ) {
	            if ( typeof _.options.zIndex === 'number' ) {
	                if( _.options.zIndex < 3 ) {
	                    _.options.zIndex = 3;
	                }
	            } else {
	                _.options.zIndex = _.defaults.zIndex;
	            }
	        }

	        if (bodyStyle.OTransform !== undefined) {
	            _.animType = 'OTransform';
	            _.transformType = '-o-transform';
	            _.transitionType = 'OTransition';
	            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.webkitPerspective === undefined) _.animType = false;
	        }
	        if (bodyStyle.MozTransform !== undefined) {
	            _.animType = 'MozTransform';
	            _.transformType = '-moz-transform';
	            _.transitionType = 'MozTransition';
	            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.MozPerspective === undefined) _.animType = false;
	        }
	        if (bodyStyle.webkitTransform !== undefined) {
	            _.animType = 'webkitTransform';
	            _.transformType = '-webkit-transform';
	            _.transitionType = 'webkitTransition';
	            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.webkitPerspective === undefined) _.animType = false;
	        }
	        if (bodyStyle.msTransform !== undefined) {
	            _.animType = 'msTransform';
	            _.transformType = '-ms-transform';
	            _.transitionType = 'msTransition';
	            if (bodyStyle.msTransform === undefined) _.animType = false;
	        }
	        if (bodyStyle.transform !== undefined && _.animType !== false) {
	            _.animType = 'transform';
	            _.transformType = 'transform';
	            _.transitionType = 'transition';
	        }
	        _.transformsEnabled = _.options.useTransform && (_.animType !== null && _.animType !== false);
	    };


	    Slick.prototype.setSlideClasses = function(index) {

	        var _ = this,
	            centerOffset, allSlides, indexOffset, remainder;

	        allSlides = _.$slider
	            .find('.slick-slide')
	            .removeClass('slick-active slick-center slick-current')
	            .attr('aria-hidden', 'true');

	        _.$slides
	            .eq(index)
	            .addClass('slick-current');

	        if (_.options.centerMode === true) {

	            centerOffset = Math.floor(_.options.slidesToShow / 2);

	            if (_.options.infinite === true) {

	                if (index >= centerOffset && index <= (_.slideCount - 1) - centerOffset) {

	                    _.$slides
	                        .slice(index - centerOffset, index + centerOffset + 1)
	                        .addClass('slick-active')
	                        .attr('aria-hidden', 'false');

	                } else {

	                    indexOffset = _.options.slidesToShow + index;
	                    allSlides
	                        .slice(indexOffset - centerOffset + 1, indexOffset + centerOffset + 2)
	                        .addClass('slick-active')
	                        .attr('aria-hidden', 'false');

	                }

	                if (index === 0) {

	                    allSlides
	                        .eq(allSlides.length - 1 - _.options.slidesToShow)
	                        .addClass('slick-center');

	                } else if (index === _.slideCount - 1) {

	                    allSlides
	                        .eq(_.options.slidesToShow)
	                        .addClass('slick-center');

	                }

	            }

	            _.$slides
	                .eq(index)
	                .addClass('slick-center');

	        } else {

	            if (index >= 0 && index <= (_.slideCount - _.options.slidesToShow)) {

	                _.$slides
	                    .slice(index, index + _.options.slidesToShow)
	                    .addClass('slick-active')
	                    .attr('aria-hidden', 'false');

	            } else if (allSlides.length <= _.options.slidesToShow) {

	                allSlides
	                    .addClass('slick-active')
	                    .attr('aria-hidden', 'false');

	            } else {

	                remainder = _.slideCount % _.options.slidesToShow;
	                indexOffset = _.options.infinite === true ? _.options.slidesToShow + index : index;

	                if (_.options.slidesToShow == _.options.slidesToScroll && (_.slideCount - index) < _.options.slidesToShow) {

	                    allSlides
	                        .slice(indexOffset - (_.options.slidesToShow - remainder), indexOffset + remainder)
	                        .addClass('slick-active')
	                        .attr('aria-hidden', 'false');

	                } else {

	                    allSlides
	                        .slice(indexOffset, indexOffset + _.options.slidesToShow)
	                        .addClass('slick-active')
	                        .attr('aria-hidden', 'false');

	                }

	            }

	        }

	        if (_.options.lazyLoad === 'ondemand') {
	            _.lazyLoad();
	        }

	    };

	    Slick.prototype.setupInfinite = function() {

	        var _ = this,
	            i, slideIndex, infiniteCount;

	        if (_.options.fade === true) {
	            _.options.centerMode = false;
	        }

	        if (_.options.infinite === true && _.options.fade === false) {

	            slideIndex = null;

	            if (_.slideCount > _.options.slidesToShow) {

	                if (_.options.centerMode === true) {
	                    infiniteCount = _.options.slidesToShow + 1;
	                } else {
	                    infiniteCount = _.options.slidesToShow;
	                }

	                for (i = _.slideCount; i > (_.slideCount -
	                        infiniteCount); i -= 1) {
	                    slideIndex = i - 1;
	                    $(_.$slides[slideIndex]).clone(true).attr('id', '')
	                        .attr('data-slick-index', slideIndex - _.slideCount)
	                        .prependTo(_.$slideTrack).addClass('slick-cloned');
	                }
	                for (i = 0; i < infiniteCount; i += 1) {
	                    slideIndex = i;
	                    $(_.$slides[slideIndex]).clone(true).attr('id', '')
	                        .attr('data-slick-index', slideIndex + _.slideCount)
	                        .appendTo(_.$slideTrack).addClass('slick-cloned');
	                }
	                _.$slideTrack.find('.slick-cloned').find('[id]').each(function() {
	                    $(this).attr('id', '');
	                });

	            }

	        }

	    };

	    Slick.prototype.interrupt = function( toggle ) {

	        var _ = this;

	        if( !toggle ) {
	            _.autoPlay();
	        }
	        _.interrupted = toggle;

	    };

	    Slick.prototype.selectHandler = function(event) {

	        var _ = this;

	        var targetElement =
	            $(event.target).is('.slick-slide') ?
	                $(event.target) :
	                $(event.target).parents('.slick-slide');

	        var index = parseInt(targetElement.attr('data-slick-index'));

	        if (!index) index = 0;

	        if (_.slideCount <= _.options.slidesToShow) {

	            _.setSlideClasses(index);
	            _.asNavFor(index);
	            return;

	        }

	        _.slideHandler(index);

	    };

	    Slick.prototype.slideHandler = function(index, sync, dontAnimate) {

	        var targetSlide, animSlide, oldSlide, slideLeft, targetLeft = null,
	            _ = this, navTarget;

	        sync = sync || false;

	        if (_.animating === true && _.options.waitForAnimate === true) {
	            return;
	        }

	        if (_.options.fade === true && _.currentSlide === index) {
	            return;
	        }

	        if (_.slideCount <= _.options.slidesToShow) {
	            return;
	        }

	        if (sync === false) {
	            _.asNavFor(index);
	        }

	        targetSlide = index;
	        targetLeft = _.getLeft(targetSlide);
	        slideLeft = _.getLeft(_.currentSlide);

	        _.currentLeft = _.swipeLeft === null ? slideLeft : _.swipeLeft;

	        if (_.options.infinite === false && _.options.centerMode === false && (index < 0 || index > _.getDotCount() * _.options.slidesToScroll)) {
	            if (_.options.fade === false) {
	                targetSlide = _.currentSlide;
	                if (dontAnimate !== true) {
	                    _.animateSlide(slideLeft, function() {
	                        _.postSlide(targetSlide);
	                    });
	                } else {
	                    _.postSlide(targetSlide);
	                }
	            }
	            return;
	        } else if (_.options.infinite === false && _.options.centerMode === true && (index < 0 || index > (_.slideCount - _.options.slidesToScroll))) {
	            if (_.options.fade === false) {
	                targetSlide = _.currentSlide;
	                if (dontAnimate !== true) {
	                    _.animateSlide(slideLeft, function() {
	                        _.postSlide(targetSlide);
	                    });
	                } else {
	                    _.postSlide(targetSlide);
	                }
	            }
	            return;
	        }

	        if ( _.options.autoplay ) {
	            clearInterval(_.autoPlayTimer);
	        }

	        if (targetSlide < 0) {
	            if (_.slideCount % _.options.slidesToScroll !== 0) {
	                animSlide = _.slideCount - (_.slideCount % _.options.slidesToScroll);
	            } else {
	                animSlide = _.slideCount + targetSlide;
	            }
	        } else if (targetSlide >= _.slideCount) {
	            if (_.slideCount % _.options.slidesToScroll !== 0) {
	                animSlide = 0;
	            } else {
	                animSlide = targetSlide - _.slideCount;
	            }
	        } else {
	            animSlide = targetSlide;
	        }

	        _.animating = true;

	        _.$slider.trigger('beforeChange', [_, _.currentSlide, animSlide]);

	        oldSlide = _.currentSlide;
	        _.currentSlide = animSlide;

	        _.setSlideClasses(_.currentSlide);

	        if ( _.options.asNavFor ) {

	            navTarget = _.getNavTarget();
	            navTarget = navTarget.slick('getSlick');

	            if ( navTarget.slideCount <= navTarget.options.slidesToShow ) {
	                navTarget.setSlideClasses(_.currentSlide);
	            }

	        }

	        _.updateDots();
	        _.updateArrows();

	        if (_.options.fade === true) {
	            if (dontAnimate !== true) {

	                _.fadeSlideOut(oldSlide);

	                _.fadeSlide(animSlide, function() {
	                    _.postSlide(animSlide);
	                });

	            } else {
	                _.postSlide(animSlide);
	            }
	            _.animateHeight();
	            return;
	        }

	        if (dontAnimate !== true) {
	            _.animateSlide(targetLeft, function() {
	                _.postSlide(animSlide);
	            });
	        } else {
	            _.postSlide(animSlide);
	        }

	    };

	    Slick.prototype.startLoad = function() {

	        var _ = this;

	        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {

	            _.$prevArrow.hide();
	            _.$nextArrow.hide();

	        }

	        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

	            _.$dots.hide();

	        }

	        _.$slider.addClass('slick-loading');

	    };

	    Slick.prototype.swipeDirection = function() {

	        var xDist, yDist, r, swipeAngle, _ = this;

	        xDist = _.touchObject.startX - _.touchObject.curX;
	        yDist = _.touchObject.startY - _.touchObject.curY;
	        r = Math.atan2(yDist, xDist);

	        swipeAngle = Math.round(r * 180 / Math.PI);
	        if (swipeAngle < 0) {
	            swipeAngle = 360 - Math.abs(swipeAngle);
	        }

	        if ((swipeAngle <= 45) && (swipeAngle >= 0)) {
	            return (_.options.rtl === false ? 'left' : 'right');
	        }
	        if ((swipeAngle <= 360) && (swipeAngle >= 315)) {
	            return (_.options.rtl === false ? 'left' : 'right');
	        }
	        if ((swipeAngle >= 135) && (swipeAngle <= 225)) {
	            return (_.options.rtl === false ? 'right' : 'left');
	        }
	        if (_.options.verticalSwiping === true) {
	            if ((swipeAngle >= 35) && (swipeAngle <= 135)) {
	                return 'down';
	            } else {
	                return 'up';
	            }
	        }

	        return 'vertical';

	    };

	    Slick.prototype.swipeEnd = function(event) {

	        var _ = this,
	            slideCount,
	            direction;

	        _.dragging = false;
	        _.interrupted = false;
	        _.shouldClick = ( _.touchObject.swipeLength > 10 ) ? false : true;

	        if ( _.touchObject.curX === undefined ) {
	            return false;
	        }

	        if ( _.touchObject.edgeHit === true ) {
	            _.$slider.trigger('edge', [_, _.swipeDirection() ]);
	        }

	        if ( _.touchObject.swipeLength >= _.touchObject.minSwipe ) {

	            direction = _.swipeDirection();

	            switch ( direction ) {

	                case 'left':
	                case 'down':

	                    slideCount =
	                        _.options.swipeToSlide ?
	                            _.checkNavigable( _.currentSlide + _.getSlideCount() ) :
	                            _.currentSlide + _.getSlideCount();

	                    _.currentDirection = 0;

	                    break;

	                case 'right':
	                case 'up':

	                    slideCount =
	                        _.options.swipeToSlide ?
	                            _.checkNavigable( _.currentSlide - _.getSlideCount() ) :
	                            _.currentSlide - _.getSlideCount();

	                    _.currentDirection = 1;

	                    break;

	                default:


	            }

	            if( direction != 'vertical' ) {

	                _.slideHandler( slideCount );
	                _.touchObject = {};
	                _.$slider.trigger('swipe', [_, direction ]);

	            }

	        } else {

	            if ( _.touchObject.startX !== _.touchObject.curX ) {

	                _.slideHandler( _.currentSlide );
	                _.touchObject = {};

	            }

	        }

	    };

	    Slick.prototype.swipeHandler = function(event) {

	        var _ = this;

	        if ((_.options.swipe === false) || ('ontouchend' in document && _.options.swipe === false)) {
	            return;
	        } else if (_.options.draggable === false && event.type.indexOf('mouse') !== -1) {
	            return;
	        }

	        _.touchObject.fingerCount = event.originalEvent && event.originalEvent.touches !== undefined ?
	            event.originalEvent.touches.length : 1;

	        _.touchObject.minSwipe = _.listWidth / _.options
	            .touchThreshold;

	        if (_.options.verticalSwiping === true) {
	            _.touchObject.minSwipe = _.listHeight / _.options
	                .touchThreshold;
	        }

	        switch (event.data.action) {

	            case 'start':
	                _.swipeStart(event);
	                break;

	            case 'move':
	                _.swipeMove(event);
	                break;

	            case 'end':
	                _.swipeEnd(event);
	                break;

	        }

	    };

	    Slick.prototype.swipeMove = function(event) {

	        var _ = this,
	            edgeWasHit = false,
	            curLeft, swipeDirection, swipeLength, positionOffset, touches;

	        touches = event.originalEvent !== undefined ? event.originalEvent.touches : null;

	        if (!_.dragging || touches && touches.length !== 1) {
	            return false;
	        }

	        curLeft = _.getLeft(_.currentSlide);

	        _.touchObject.curX = touches !== undefined ? touches[0].pageX : event.clientX;
	        _.touchObject.curY = touches !== undefined ? touches[0].pageY : event.clientY;

	        _.touchObject.swipeLength = Math.round(Math.sqrt(
	            Math.pow(_.touchObject.curX - _.touchObject.startX, 2)));

	        if (_.options.verticalSwiping === true) {
	            _.touchObject.swipeLength = Math.round(Math.sqrt(
	                Math.pow(_.touchObject.curY - _.touchObject.startY, 2)));
	        }

	        swipeDirection = _.swipeDirection();

	        if (swipeDirection === 'vertical') {
	            return;
	        }

	        if (event.originalEvent !== undefined && _.touchObject.swipeLength > 4) {
	            event.preventDefault();
	        }

	        positionOffset = (_.options.rtl === false ? 1 : -1) * (_.touchObject.curX > _.touchObject.startX ? 1 : -1);
	        if (_.options.verticalSwiping === true) {
	            positionOffset = _.touchObject.curY > _.touchObject.startY ? 1 : -1;
	        }


	        swipeLength = _.touchObject.swipeLength;

	        _.touchObject.edgeHit = false;

	        if (_.options.infinite === false) {
	            if ((_.currentSlide === 0 && swipeDirection === 'right') || (_.currentSlide >= _.getDotCount() && swipeDirection === 'left')) {
	                swipeLength = _.touchObject.swipeLength * _.options.edgeFriction;
	                _.touchObject.edgeHit = true;
	            }
	        }

	        if (_.options.vertical === false) {
	            _.swipeLeft = curLeft + swipeLength * positionOffset;
	        } else {
	            _.swipeLeft = curLeft + (swipeLength * (_.$list.height() / _.listWidth)) * positionOffset;
	        }
	        if (_.options.verticalSwiping === true) {
	            _.swipeLeft = curLeft + swipeLength * positionOffset;
	        }

	        if (_.options.fade === true || _.options.touchMove === false) {
	            return false;
	        }

	        if (_.animating === true) {
	            _.swipeLeft = null;
	            return false;
	        }

	        _.setCSS(_.swipeLeft);

	    };

	    Slick.prototype.swipeStart = function(event) {

	        var _ = this,
	            touches;

	        _.interrupted = true;

	        if (_.touchObject.fingerCount !== 1 || _.slideCount <= _.options.slidesToShow) {
	            _.touchObject = {};
	            return false;
	        }

	        if (event.originalEvent !== undefined && event.originalEvent.touches !== undefined) {
	            touches = event.originalEvent.touches[0];
	        }

	        _.touchObject.startX = _.touchObject.curX = touches !== undefined ? touches.pageX : event.clientX;
	        _.touchObject.startY = _.touchObject.curY = touches !== undefined ? touches.pageY : event.clientY;

	        _.dragging = true;

	    };

	    Slick.prototype.unfilterSlides = Slick.prototype.slickUnfilter = function() {

	        var _ = this;

	        if (_.$slidesCache !== null) {

	            _.unload();

	            _.$slideTrack.children(this.options.slide).detach();

	            _.$slidesCache.appendTo(_.$slideTrack);

	            _.reinit();

	        }

	    };

	    Slick.prototype.unload = function() {

	        var _ = this;

	        $('.slick-cloned', _.$slider).remove();

	        if (_.$dots) {
	            _.$dots.remove();
	        }

	        if (_.$prevArrow && _.htmlExpr.test(_.options.prevArrow)) {
	            _.$prevArrow.remove();
	        }

	        if (_.$nextArrow && _.htmlExpr.test(_.options.nextArrow)) {
	            _.$nextArrow.remove();
	        }

	        _.$slides
	            .removeClass('slick-slide slick-active slick-visible slick-current')
	            .attr('aria-hidden', 'true')
	            .css('width', '');

	    };

	    Slick.prototype.unslick = function(fromBreakpoint) {

	        var _ = this;
	        _.$slider.trigger('unslick', [_, fromBreakpoint]);
	        _.destroy();

	    };

	    Slick.prototype.updateArrows = function() {

	        var _ = this,
	            centerOffset;

	        centerOffset = Math.floor(_.options.slidesToShow / 2);

	        if ( _.options.arrows === true &&
	            _.slideCount > _.options.slidesToShow &&
	            !_.options.infinite ) {

	            _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');
	            _.$nextArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

	            if (_.currentSlide === 0) {

	                _.$prevArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
	                _.$nextArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

	            } else if (_.currentSlide >= _.slideCount - _.options.slidesToShow && _.options.centerMode === false) {

	                _.$nextArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
	                _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

	            } else if (_.currentSlide >= _.slideCount - 1 && _.options.centerMode === true) {

	                _.$nextArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
	                _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

	            }

	        }

	    };

	    Slick.prototype.updateDots = function() {

	        var _ = this;

	        if (_.$dots !== null) {

	            _.$dots
	                .find('li')
	                .removeClass('slick-active')
	                .attr('aria-hidden', 'true');

	            _.$dots
	                .find('li')
	                .eq(Math.floor(_.currentSlide / _.options.slidesToScroll))
	                .addClass('slick-active')
	                .attr('aria-hidden', 'false');

	        }

	    };

	    Slick.prototype.visibility = function() {

	        var _ = this;

	        if ( _.options.autoplay ) {

	            if ( document[_.hidden] ) {

	                _.interrupted = true;

	            } else {

	                _.interrupted = false;

	            }

	        }

	    };

	    $.fn.slick = function() {
	        var _ = this,
	            opt = arguments[0],
	            args = Array.prototype.slice.call(arguments, 1),
	            l = _.length,
	            i,
	            ret;
	        for (i = 0; i < l; i++) {
	            if (typeof opt == 'object' || typeof opt == 'undefined')
	                _[i].slick = new Slick(_[i], opt);
	            else
	                ret = _[i].slick[opt].apply(_[i].slick, args);
	            if (typeof ret != 'undefined') return ret;
	        }
	        return _;
	    };

	}));


/***/ }
/******/ ]);