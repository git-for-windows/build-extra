<?php get_header() ?>

<!-- CONTACT-US -->

<div class="contact_us">
	<div class="container">
		<div class="col-sm-24 text-center">	
			<h1><?php _e('Contact US', 'delta');?></h1>
			<div class="head_text"><?php echo cz('tp_contactUs_text')?></div>
		</div>
		<div class="col-md-12 width_max_991_100">	
			<div class="form_review contact_us">
				<div class="contact_us_title">																				
				</div>								
				<form method="post">
					<?php mail_letter();?>		
					<input type="hidden" id="rate" name="rate" value="" />
					<div class="text"><span class="star">*</span><?php _e('Full name:', 'delta');?></div>
					<div class="field"><input type="text" required name="full_name" value="" /></div>
					<div class="text"><span class="star">*</span><?php _e('Your Email:', 'delta');?></div>
					<div class="field"><input type="text" required name="email_main" value="" /></div>
					<div class="text"><?php _e('Subject:', 'delta');?></div>
					<div class="field"><input type="text" name="subject" value="" /></div>
					<div class="text message_comment_title"><span class="star">*</span><?php _e('Your Message:', 'delta');?></div>
					<div class="field"><textarea name="message" required rows="5"></textarea></div>
					<div class="review_but">
						<input type="hidden" name="contact_us" value="2" />
						<input type="submit" name="send_letter" class="btn cont_btn" value="Send" />	
					</div>
				</form>
			</div>
		</div>
		<div class="col-md-12 width_max_991_100">
			<div class="map_container">
				<div id="map_contact_us">
					<img class="img-responsive" src="<?php echo cz('tp_contactUs_map');?>" alt="">
				</div>
				<div class="info_office">
					<div class="col-xs-14">
						<div class="footer_addr"><i class="icon-home" aria-hidden="true"></i><?php echo cz( 'tp_address' )?></div>
						<div class="footer_email"><i class="icon-mail" aria-hidden="true"></i><?php echo cz( 's_mail' )?></div>    
						<div class="footer_tel"><i class="icon-phone"></i><?php echo cz( 's_phone' )?></div>
					</div>	
					<div class="col-xs-10">
						<div class="soc">	
							<div class="soc_text"><?php _e('Follow Us', 'delta');?></div>					
							<noindex>
								<a data-social="facebook" href="<?php echo cz('s_link_fb') ?>" target="_blank"><i class="b-social-icon-facebook"></i></a>
								<a data-social="twitter" href="<?php echo cz('s_link_tw') ?>" target="_blank"><i class="b-social-icon-twitter"></i></a>
								<a data-social="gplus" href="<?php echo cz('s_link_gl') ?>" target="_blank"><i class="b-social-icon-gplus"></i></a>
								<a data-social="pinterest" href="<?php echo cz('s_link_pt') ?>" target="_blank">
									<i class="b-social-icon-pinterest"></i>
								</a>
							</noindex>	
						</div>	
					</div>
				</div>
			</div>	
		</div>
	</div>
</div>		
					</div>
				</div>
			</div>

		</div>
	</div>
	<?php get_footer() ?>
	
