</div></div>
<div class="footer">
    <div class="cell">
	<?php if (cz('show_partners') ) { ?>
        <div class="container-fluid b-footer-before">
            <div class="container">
                <ul class="g-partner-icons">
                    <li class="g-partner-icons_title"><?php _e('Our Preferred Partners:', 'delta'); ?></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph-3"></span></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph-2"></span></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph-5"></span></li>
                    <li class="g-partner-icons_other"><span class="b-social-icon-cc-visa"></span></li>
                    <li class="g-partner-icons_other"><span class="b-social-icon-cc-mastercard"></span></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph"></span></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph-1"></span></li>
                    <li class="g-partner-icons_item"><span class="b-social-icon-glyph-4"></span></li>
                </ul>
            </div>
        </div>
	<?php }?>
        <div class="container-fluid b-footer">
            <div class="container">
                <div
                    class="col-lg-5 col-md-5 col-sm-24 col-xs-24 b-footer__item">
					<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo cz('tp_logo_img_w') ?>"></a>
                </div>
                <div
                    class="col-lg-14 col-md-14 col-sm-24 col-xs-24 b-footer__item"><?php  wp_nav_menu(array('menu' => 'Footer', 'depth' => 2, 'container' => '', 'container_class' => '', 'menu_class' => 'nav nav-c-footer', 'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>')); ?></div>
                <div class="col-lg-5 col-md-5 col-sm-24 col-xs-24 b-footer__item">
                    <ul class="b-social b-social_big b-social_gray_light"><?php get_template_part('templates/social'); ?></ul>
                </div>
				<div class="col-lg-24 col-sm-24 b-subscribe col-xs-24">
				<?php if (cz('tp_subscribe')): ?>
					<?php echo cz('tp_subscribe')?>
				<?php endif; ?>
				</div>
            </div>
            <div class="container text-center">
				<?php $ssdma_copyright = cz( 'tp_copyright' ) ?>
				<?php if ($ssdma_copyright): ?>
					<?php echo $ssdma_copyright; ?>
                <?php else: ?>
					&copy;&nbsp;<?php _e('Copyright', 'delta'); ?>&nbsp;<?php echo date('Y'); ?>.&nbsp;<?php _e('Powered By', 'delta'); ?>&nbsp;
					<a href="<?php echo esc_url('http://www.alipartnership.com/'); ?>" target="_blank">AliPartnership.com</a>
				<?php endif; ?>
			</div>
        </div>
    </div>
</div>
<div class="header">
    <div class="cell">
        <div class="container-fluid b-top-menu">
            <div class="container">
                <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24"><?php  wp_nav_menu(array('menu' => 'Main Menu', 'depth' => 3, 'container' => false, 'container_class' => '', 'menu_class' => 'nav nav-c-top', 'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>')); ?></div>
                <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 text-right">
				<?php $email = cz( 's_mail' );
                    if ($email): ?>
						<span class="b-text-pad-base"><?php echo $email; ?></span>
					<?php endif; ?>
                    <ul class="b-social b-social_border b-social_gray_light"><?php get_template_part('templates/social'); ?></ul>
                    <div class="mobile_menu">
						<img src="<?php echo get_template_directory_uri(); ?>/public/images/mobilemenu_mini.png">&#9660;
					</div>
                </div>
            </div>
        </div>
        <div class="container-fluid b-header">
            <div class="container">
			
			<div class="col-lg-7 col-md-7 col-sm-24 col-xs-24 textcenter">
				<?php $header_logo = cz( 'tp_logo_img' );
					  if ($header_logo): ?>
						<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php  echo $header_logo; ?>"></a>
					<?php endif; ?>
            </div>
                <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24"><?php get_search_form(); ?></div>
                <div class="col-lg-4 col-md-4 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-24 col-xs-24 forsecmenu">
	                <div class="second_menu_button">
						<img src="<?php echo get_template_directory_uri(); ?>/public/images/mobilemenu.png">
					</div>
	                <?php
	                    if (cz('free_shipping') && cz('free_shipping') !='' ) {
		                    echo '<img src="'.cz('free_shipping').'">';
						}
	                ?>
                </div>
            </div>
        </div>
        <div class="container-fluid b-main-menu" id="secmenu" data-toggle="stickmenu">
            <div
                class="container"><?php wp_nav_menu(array('menu' => 'Top Menu', 'depth' => 2, 'container' => '', 'container_class' => '', 'menu_class' => 'nav nav-c-main-menu', 'fallback_cb' => 'wp_bootstrap_navwalker::fallback', 'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>', 'walker' => new wp_bootstrap_navwalker()));?></div>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
<?php echo cz( 'tp_footer_script' ); ?>
</body>
</html>


