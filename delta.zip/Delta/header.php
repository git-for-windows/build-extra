<html <?php language_attributes(); ?> class="no-js" xmlns="http://www.w3.org/1999/html">
<head>
	<title><?php mic_title() ?></title>
	<meta name="description" content="<?php mic_description() ?>"/>
	<meta name="keywords" content="<?php mic_keywords() ?>"/>
	<link rel="icon" href="<?php echo cz( 'tp_favicon' ); ?>" type="image/x-icon"/>
	<link rel="shortcut icon" href="<?php echo cz( 'tp_favicon' ); ?>" type="image/x-icon"/>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="apple-mobile-web-app-capable" content="yes"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<link href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&subset=cyrillic" rel="stylesheet">
	<link href="<?php echo get_template_directory_uri(); ?>/style.css?100" rel="stylesheet">
	<link href="<?php echo get_template_directory_uri(); ?>/inc/customization/css/custom_style.css?100" rel="stylesheet">
	<?php if ( cz( 'tp_head_ga' ) ): ?>
		<script>
			(function ( i, s, o, g, r, a, m ) {
				i[ 'GoogleAnalyticsObject' ] = r;
				i[ r ] = i[ r ] || function () {
						(i[ r ].q = i[ r ].q || []).push( arguments )
					}, i[ r ].l = 1 * new Date();
				a = s.createElement( o ),
					m = s.getElementsByTagName( o )[ 0 ];
				a.async = 1;
				a.src   = g;
				m.parentNode.insertBefore( a, m )
			})( window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga' );

			ga( 'create', '<?php echo cz( 'tp_head_ga' );?>', 'auto' );
			ga( 'send', 'pageview' );

		</script>
	<?php else: ?>
		<script>
			window.ga = window.ga || function(){};
		</script>
	<?php endif; ?>

	<style>
		<?php echo cz('tp_style');?>
	</style>
	<?php echo cz( 'tp_head' ); ?>
		<?php wp_head() ?>
</head>
<body <?php body_class(); ?>>
<div class="content">
    <div class="cell">
