<?php
/**
 * Author: Vitaly Kukin
 * Date: 21.09.2018
 * Time: 16:24
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div id="loader-all" class="d-none">
	<div class="loader-body">
	    <span>
			<span></span><span></span><span></span><span></span>
	    </span>
		<div class="loader-base"><span></span><div class="loader-face"></div></div>
	</div>
	<div class="longfazers"><span></span><span></span><span></span><span></span></div>
</div>