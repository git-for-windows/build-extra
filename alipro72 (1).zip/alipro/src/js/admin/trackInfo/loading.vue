<template>
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="ldi-3it84q" width="200px"
         height="200px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" style="background: none;">
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"
             x="0px" y="0px" viewBox="0 0 100 100" style="transform-origin: 50px 50px 0px;" xml:space="preserve"><g style="transform-origin: 50px 50px 0px;"><g style="transform-origin: 50px 50px 0px; transform: scale(0.6);"><g class="ld ld-rush-px-ltr" style="transform-origin: 50px 50px 0px; animation-duration: 1s; animation-delay: -1s; animation-direction: normal;"><g><g style="transform-origin: 50px 50px 0px;"><path class="st0" d="M66.714,28.708h-9.996v36.829h31.978V50.691c0-2.472-0.982-4.842-2.729-6.59L73.303,31.438 C71.556,29.69,69.185,28.708,66.714,28.708z" fill="#656a7a" style="fill: rgb(101, 106, 122);"/></g><g
                style="transform-origin: 50px 50px 0px;"><path class="st0" d="M89.4,70.851H10.6c-1.16,0-2.1-0.94-2.1-2.1v-5.346c0-1.16,0.94-2.1,2.1-2.1h78.8c1.16,0,2.1,0.94,2.1,2.1 v5.346C91.5,69.911,90.56,70.851,89.4,70.851z" fill="#656a7a" style="fill: rgb(101, 106, 122);"/></g><g
                style="transform-origin: 50px 50px 0px;"><path class="st22" d="M10.507,58.55h42.872V29.355c0-4.036-3.272-7.309-7.309-7.309H17.815c-4.036,0-7.309,3.272-7.309,7.309V58.55z " fill="#d64166" style="fill: rgb(214, 65, 102);"/></g><g
                style="transform-origin: 50px 50px 0px;"><circle class="st55" cx="26.332" cy="67.707" r="10.246" fill="rgb(255, 255, 255)" stroke="#656a7a" style="fill: rgb(255, 255, 255); stroke: rgb(101, 106, 122);"/></g><g
                style="transform-origin: 50px 50px 0px;"><circle class="st55" cx="72.707" cy="66.616" r="10.246" fill="rgb(255, 255, 255)" stroke="#656a7a" style="fill: rgb(255, 255, 255); stroke: rgb(101, 106, 122);"/></g></g></g></g></g></svg>
    </svg>
</template>

<script>
    export default {
        name: "loading"
    }
</script>

<style scoped>
    @keyframes ld-rush-px-ltr {
        0% {
            -webkit-transform: translate(-100px, 0) skewX(45deg);
            transform: translate(-100px, 0) skewX(45deg);
            animation-timing-function: cubic-bezier(0, 0.5, 0.5, 1);
        }
        30% {
            -webkit-transform: translate(20px, 0) skewX(-35deg);
            transform: translate(20px, 0) skewX(-35deg);
        }
        45% {
            -webkit-transform: translate(-10px, 0) skewX(15deg);
            transform: translate(-10px, 0) skewX(15deg);
        }
        60% {
            -webkit-transform: translate(5px, 0) skewX(-7deg);
            transform: translate(5px, 0) skewX(-7deg);
        }
        80% {
            -webkit-transform: translate(0, 0) skewX(0deg);
            transform: translate(0, 0) skewX(0deg);
        }
        100% {
            -webkit-transform: translate(150px, 0) skewX(45deg);
            transform: translate(150px, 0) skewX(45deg);
        }
    }

    @-webkit-keyframes ld-rush-px-ltr {
        0% {
            -webkit-transform: translate(-100px, 0) skewX(45deg);
            transform: translate(-100px, 0) skewX(45deg);
            animation-timing-function: cubic-bezier(0, 0.5, 0.5, 1);
        }
        30% {
            -webkit-transform: translate(20px, 0) skewX(-35deg);
            transform: translate(20px, 0) skewX(-35deg);
        }
        45% {
            -webkit-transform: translate(-10px, 0) skewX(15deg);
            transform: translate(-10px, 0) skewX(15deg);
        }
        60% {
            -webkit-transform: translate(5px, 0) skewX(-7deg);
            transform: translate(5px, 0) skewX(-7deg);
        }
        80% {
            -webkit-transform: translate(0, 0) skewX(0deg);
            transform: translate(0, 0) skewX(0deg);
        }
        100% {
            -webkit-transform: translate(150px, 0) skewX(45deg);
            transform: translate(150px, 0) skewX(45deg);
        }
    }

    .ld.ld-rush-px-ltr {
        -webkit-animation: ld-rush-px-ltr 1.5s infinite linear;
        animation: ld-rush-px-ltr 1.5s infinite linear;
    }
</style>