<?php

/**
 * Setup the plugin
 */
function ali_install() {

	require( ALI_PATH . 'core/sql.php' );

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	foreach( ali_sql_list() as $key ) {
		dbDelta($key);
    }
	
	ali_maybe_add_columns();


    update_option( 'comments_notify', '' );
    update_option( 'moderation_notify', '' );
	update_option( 'ads-version', ALI_VERSION  );

    adsSetFrontPage();

	add_rewrite_rule( '^oauth1/extension/?$','index.php?rest_oauth1=extension','top' );

	flush_rewrite_rules();
}

function adsSetFrontPage() {

    update_option( 'show_on_front', 'page' );

    $home = get_page_by_path( 'home' );

    if ( $home ) {
        $id = $home->ID;
    } else {
        $id = wp_insert_post( [
            'post_type'    => 'page',
            'post_title'   => __( 'Home', 'ads' ),
            'post_name'    => 'home',
            'post_content' => '',
            'post_status'  => 'publish',
            'post_author'  => 1,
        ] );
    }

    update_option( 'page_on_front', $id );

    $blog = get_page_by_path( 'blog' );

    if ( $blog ) {
        $id = $blog->ID;
    } else {
        $id = wp_insert_post( [
            'post_type'    => 'page',
            'post_title'   => __('Blog', 'ads'),
            'post_name'    => 'blog',
            'post_content' => '',
            'post_status'  => 'publish',
            'post_author'  => 1,
        ] );
    }

    update_option( 'page_for_posts', $id );
}

function ali_maybe_add_columns() {
	
	global $wpdb;

	$args = [
		'ali_products_meta' => [
			'links' => "ALTER TABLE `{$wpdb->prefix}ali_products_meta` ADD `links` TEXT DEFAULT NULL;",
			'sizeAttr' => "ALTER TABLE `{$wpdb->prefix}ali_products_meta` ADD `sizeAttr` LONGTEXT DEFAULT NULL;",
        
        ],
		'ali_ali_meta' => [
			'skuOriginal' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `skuOriginal` LONGTEXT DEFAULT NULL;"
		],
		'ali_activities' => [
			'hash' => "ALTER TABLE `{$wpdb->prefix}ali_activities` ADD hash VARCHAR(255) DEFAULT NULL",
			'trouble' => "ALTER TABLE `{$wpdb->prefix}ali_activities` ADD trouble VARCHAR(40) DEFAULT NULL"
		]
	];

	foreach( $args as $key => $val ) {
		
		$result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
			 	 FROM `information_schema`.`COLUMNS`
			 	 WHERE `TABLE_SCHEMA` = '%s' AND `TABLE_NAME` = '{$wpdb->prefix}{$key}'",
				DB_NAME
			)
		);
		
		$col = [];
		if( count($result) > 0 ) foreach( $result as $column ) {
			$col[] = $column->COLUMN_NAME;
		}
		
		if( count($col) > 0 ) foreach( $val as $k => $v ) {
			if( ! in_array( $k, $col ) )
				$wpdb->query( $v );
		}
	}
}


/**
 * Check installed plugin
 */
function ali_installed() {

	if( ! current_user_can( 'install_plugins' ) ) {
        return;
    }

	if ( get_option( 'ads-version', 0 ) < ALI_VERSION ) {
		ali_install();
    }
}
add_action( 'admin_init', 'ali_installed' );

/**
 * When activate plugin
 */
function ali_activate() {

	ali_installed();

	do_action( 'ali_activate' );
}

/**
 * When deactivate plugin
 */
function ali_deactivate() {

	do_action( 'ali_deactivate' );
}
