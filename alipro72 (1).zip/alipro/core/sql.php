<?php
/**
 * User: Vitaly Kukin
 * Date: 28.03.2016
 * Time: 15:55
 */

if( ! function_exists( 'ali_sql_list' ) ) {

	function ali_sql_list() {

	    global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

	    return [

	        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ali_products (
	            `id` BIGINT(20) unsigned NOT NULL AUTO_INCREMENT,
	            `post_id` BIGINT(20) unsigned NOT NULL,
	            `imageUrl` VARCHAR(255) DEFAULT NULL,
	            `price` DECIMAL(10,2) DEFAULT '0.00',
	            `priceMax` DECIMAL(10,2) DEFAULT '0.00',
	            `salePrice` DECIMAL(10,2) DEFAULT '0.00',
	            `salePriceMax` DECIMAL(10,2) DEFAULT '0.00',
	            `discount` INT(3) DEFAULT '0',
	            `countReview` INT(11) DEFAULT '0',
	            `packageType` ENUM('lot','piece') DEFAULT 'piece',
	            `evaluateScore` DECIMAL(2,1) DEFAULT '0',
				`quantity` INT(11) unsigned DEFAULT '0',
				`promotionVolume` INT(11) unsigned DEFAULT '0',
				`currency` CHAR(4) DEFAULT 'USD',
	            PRIMARY KEY (`id`),
	            KEY (`post_id`),
	            KEY (`evaluateScore`)
		    ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ali_products_meta (
	            `id` BIGINT(20) unsigned NOT NULL AUTO_INCREMENT,
	            `post_id` BIGINT(20) unsigned NOT NULL,
	            `gallery` TEXT DEFAULT NULL,
	            `shipping` VARCHAR(255) DEFAULT NULL,
	            `lotNum` INT(11) unsigned DEFAULT '0',
	            `pack` TEXT DEFAULT NULL,
	            `sku` TEXT DEFAULT NULL,
	            `skuAttr` LONGTEXT DEFAULT NULL,
	            `sizeAttr` LONGTEXT DEFAULT NULL,
	            `seo_keywords` VARCHAR(255) DEFAULT NULL,
	            `seo_description` VARCHAR(255) DEFAULT NULL,
	            `seo_title` VARCHAR(255) DEFAULT NULL,
	            `links` TEXT DEFAULT NULL,
	            PRIMARY KEY (`id`),
	            KEY (`post_id`)
		    ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ali_attributes (
	            `id` BIGINT(20) unsigned NOT NULL AUTO_INCREMENT,
	            `post_id` BIGINT(20) unsigned NOT NULL,
	            `attr_name` VARCHAR(40) DEFAULT NULL,
	            `attr_value` VARCHAR(255) DEFAULT NULL,
	            PRIMARY KEY (`id`),
	            KEY (`post_id`),
	            KEY (`attr_name`)
		    ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ali_ali_meta (
	            `id` BIGINT(20) unsigned NOT NULL AUTO_INCREMENT,
	            `post_id` BIGINT(20) unsigned NOT NULL,
	            `product_id` VARCHAR(20) NOT NULL,
	            `origPrice` DECIMAL(10,2) DEFAULT '0.00',
	            `origPriceMax` DECIMAL(10,2) DEFAULT '0.00',
	            `origSalePrice` DECIMAL(10,2) DEFAULT '0.00',
	            `origSalePriceMax` DECIMAL(10,2) DEFAULT '0.00',
	            `productUrl` VARCHAR(255) DEFAULT NULL,
	            `feedbackUrl` VARCHAR(255) DEFAULT NULL,
	            `storeUrl` VARCHAR(255) DEFAULT NULL,
	            `storeName` VARCHAR(255) DEFAULT NULL,
	            `storeRate` VARCHAR(255) DEFAULT NULL,
	            `adminDescription` TEXT DEFAULT NULL,
	            `skuOriginaAttr` LONGTEXT DEFAULT NULL,
	            `skuOriginal` LONGTEXT DEFAULT NULL,
	            `countries` TEXT DEFAULT NULL,
	            `currencyCode` CHAR(4) DEFAULT 'USD',
	            `needUpdate` TINYINT(1) DEFAULT 1,
	            `service` VARCHAR(20) DEFAULT 'aliexpress',
	            PRIMARY KEY (`id`),
	            KEY (`post_id`),
	            KEY (`product_id`)
		    ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ali_categories (
	            `id` BIGINT(20) unsigned NOT NULL AUTO_INCREMENT,
	            `term_id` BIGINT(20) unsigned NOT NULL,
	            `title` VARCHAR(255) DEFAULT NULL,
	            `seo_title` VARCHAR(255) DEFAULT NULL,
	            `seo_description` TEXT DEFAULT NULL,
	            `seo_keywords` TEXT DEFAULT NULL,
	            PRIMARY KEY (`id`),
	            KEY (`term_id`)
		    ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ali_activities` (
	            `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	            `post_id` BIGINT(20) unsigned NOT NULL,
	            `hash` VARCHAR(255) DEFAULT NULL,
	            `product_data` TEXT DEFAULT NULL,
	            `type` VARCHAR(20) DEFAULT NULL,
	            `date` DATETIME DEFAULT '0000-00-00 00:00:00',
	            `anonce` VARCHAR(255) DEFAULT NULL,
	            `trouble` VARCHAR(40) DEFAULT NULL,
	            `status` VARCHAR(20) DEFAULT NULL,
	            PRIMARY KEY (`id`)
	        ) {$charset_collate};",

	        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ali_search_analytics` (
	            `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	            `search` VARCHAR(255) NOT NULL,
	            `q` INT(10) DEFAULT 0,
	            `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
	            PRIMARY KEY (`id`),
	            KEY(`search`)
	        ) {$charset_collate};",

			"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}exp_review` (    
				    `id` bigint(20) NOT NULL AUTO_INCREMENT, 
					`post_id` bigint(20) unsigned NOT NULL,
					`title` VARCHAR(255) NOT NULL,
					`description` VARCHAR(255) NOT NULL,
					`img` VARCHAR(255) NOT NULL,
					`emblems` VARCHAR(255) NOT NULL,
					`basic_content` LONGTEXT NOT NULL,
					`summary` TEXT NOT NULL,
					`author` VARCHAR(255) NOT NULL,
					`overall_rating` VARCHAR(255) NOT NULL,
					`rating` VARCHAR(255) NOT NULL,
					PRIMARY KEY (`id`)
			) {$charset_collate};",

            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ali_task_upload_images` (	            
	            `post_id` BIGINT(20) UNSIGNED NOT NULL,
	            `product_id` VARCHAR(20) NOT NULL,
	            `links` TEXT DEFAULT NULL,
	            `count` SMALLINT(5) UNSIGNED DEFAULT NULL,	            
	            PRIMARY KEY (`post_id`),
	            KEY (`product_id`)
		    ) {$charset_collate};"
	    ];
	}
}
