<?php
/**
 *	Plugin Name: AliPlugin Pro
 *	Plugin URI: https://alipartnership.com/
 *	Description: AliPlugin Pro is a WordPress plugin created for AliExpress Affiliate programm
 *	Version: 1.3
 *	Text Domain: alipro
 *	Requires at least: WP 5.3.2
 *	Author: V. Kukin & Y. Nevskiy & P.Shishkin & G.Sypiev
 *	Author URI: https://yellowduck.me/
 *	License: SHAREWARE
 */

if ( ! defined( 'ALI_VERSION' ) ) define( 'ALI_VERSION', '1.3' );
if ( ! defined( 'ALI_PATH' ) )    define( 'ALI_PATH', plugin_dir_path( __FILE__ ) );
if ( ! defined( 'ALI_URL' ) )     define( 'ALI_URL', str_replace( [ 'https:', 'http:' ], '', plugins_url( 'alipro' ) ) );
if ( ! defined( 'ALI_CODE' ) )    define( 'ALI_CODE', 'ion72' );
if ( ! defined( 'ALI_ERROR' ) )   define( 'ALI_ERROR', ali_check_server() );

function ali_check_server() {

	if( version_compare( '7.1', PHP_VERSION, '>' ) )
		return sprintf(
		    'PHP Version is not suitable. You need version 7.1+.'
        );

	$ion_args = [ 'ion71' => '7.1', 'ion72' => '7.2' ];
	$ver      = explode( '.', PHP_VERSION );
	$version  = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION . '.' . PHP_RELEASE_VERSION;
	$ion_pref = 'ion' . $ver[ 0 ] . $ver[ 1 ];
    
    if( $ion_pref != ALI_CODE && $ver[ 0 ] . $ver[ 1 ] < 73 )
        return sprintf(
            'You installed AliPlugin Pro plugin for PHP %1$s, but your version of PHP is %2$s.' . ' ' .
            'Please <a href="%3$s" target="_blank">download</a> and install AliPlugin Pro plugin for PHP %2$s.',
            isset( $ion_args[ ALI_CODE ] ) ? $ion_args[ ALI_CODE ] : 'Unknown',
            $version,
            'https://alipartnership.com/'
        );
	
	$extensions = get_loaded_extensions();

	$key = 'ionCube Loader';

	if ( ! in_array( $key, $extensions ) )
        return sprintf(
            '%s Loader not found. AliPlugin Pro plugin can\'t be activated. %s', $key
        );
	
	$plugins_local = apply_filters( 'active_plugins', (array) get_option( 'active_plugins', [] ) );
	
	if( in_array( 'aliprow/aliprow.php', $plugins_local ) ) {
		
		return 'AliPlugin Pro plugin is not compatible with AliPlugin Pro Woo plugin. You need to deactivate and delete AliPlugin Pro Woo plugin.';
	}
	$theme = wp_get_theme( 'Alpha' );
	if($theme->Version < '1.0.7' && $theme->Version!=''){
		return 'Please update the theme Alpha';
	}
	$theme = wp_get_theme( 'Beta' );
	if($theme->Version < '1.0.9' && $theme->Version!=''){
		return 'Please update the theme Beta';
	}
	$theme = wp_get_theme( 'ALPRO-Single' );
	if($theme->Version < '1.2' && $theme->Version!=''){
		return 'Please update the theme ALPRO-Single';
	}
	$theme = wp_get_theme( 'Gamma' );
	if($theme->Version < '0.9.9' && $theme->Version!=''){
		return 'Please update the theme Gamma';
	}
	$theme = wp_get_theme( 'Delta' );
	if($theme->Version < '1.1'&& $theme->Version!=''){
		return 'Please update the theme Delta';
	}
	if( in_array( 'woocommerce/woocommerce.php', $plugins_local ) ) {
		
		return sprintf(
			'If you use WooCommerce please <a href="%1$s" target="_blank">download</a> and install AliPlugin Pro Woo plugin version for PHP %2$s',
			'https://alipartnership.com/updates-plugin/',
            $version
		);
	}
	
	return false;
}

function ali_admin_notice__error() {

	$check = ali_check_server();

	if( $check ) {

		$class = 'notice notice-error';
		$message = __( 'AliPlugin Pro plugin alert: Error!', 'ads' ) . ' ' . $check;

		printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
	}
	
}
add_action( 'admin_notices', 'ali_admin_notice__error' );

/**
 * Localization
 */
function ali_lang_init() {
	
	load_plugin_textdomain( 'ads' );
}
add_action( 'init', 'ali_lang_init' );

if( is_admin() ) :

	require( ALI_PATH . 'core/setup.php');

    register_activation_hook( __FILE__, 'ali_lang_init' );
	register_activation_hook( __FILE__, 'ali_install' );
	register_activation_hook( __FILE__, 'ali_activate' );

endif;

if( ! ALI_ERROR ) {
    
    require( ALI_PATH . 'core/filters.php' );
    require( ALI_PATH . 'core/core.php' );
    require( ALI_PATH . 'core/init.php' );
    require( ALI_PATH . 'admin/cron.php' );
    require( ALI_PATH . 'core/17track.php' );
    require( ALI_PATH . 'core/handlersFront.php' );
    require( ALI_PATH . 'core/handlersActions.php' );
    
    require( ALI_PATH . 'core/searchFront.php' );
    //require( ALI_PATH . 'core/customization/field.php' );
    //require( ALI_PATH . 'core/customization/old_cart.php' );
    //require( ALI_PATH . 'core/customization/old_thankyou.php' );
    //require( ALI_PATH . 'core/customization/old_blog.php' );
    //require( ALI_PATH . 'core/customization/old_acc.php' );
    
    function ali_init_customization()
    {
       // require( ALI_PATH . 'core/customization/cart.php' );
     //   require( ALI_PATH . 'core/customization.php' );
        
    }
    
    add_action( 'cz_menu_init', 'ali_init_customization' );
    
    //TODO Удалить после замены старой кастомизации в темах
    if ( ! function_exists( 'cz' ) ) {
        function cz( $name ) {
            global $cz_data;
            
            return isset( $cz_data[ $name ] ) ? $cz_data[ $name ] : '';
        }
        
    }

	if ( is_admin() ) :
		require( ALI_PATH . 'core/controller.php' );
	endif;

	require( ALI_PATH . 'core/front/breadcrumbs.php' );
}